"""Application factory — modular AMS ERP."""
from __future__ import annotations

import os
import secrets
import logging
import traceback
from logging.handlers import RotatingFileHandler
from datetime import timedelta
from pathlib import Path

from flask import Flask
from flask_login import LoginManager
from sqlalchemy import event

from models import db
from utils.module_loader import load_modules


def create_app(test_config: dict | None = None) -> Flask:
    root = Path(__file__).resolve().parent.parent
    app = Flask(
        __name__,
        template_folder=str(root / "templates"),
        static_folder=str(root / "static"),
        instance_path=str(root / "instance"),
        instance_relative_config=True,
    )

    instance_dir = root / "instance"
    instance_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = instance_dir / ".tmp"
    (tmp_dir / "import_uploads").mkdir(parents=True, exist_ok=True)
    (tmp_dir / "import_reports").mkdir(parents=True, exist_ok=True)

    schema_version = (os.environ.get("AMS_SCHEMA_VERSION") or "v44").strip().lower()
    if schema_version in {"legacy", "v3", "live"}:
        default_db_name = "ahmed_cement.db"
    else:
        # v4.4 is the only supported runtime schema.
        default_db_name = "ahmed_cement_v44_fresh.db"
        schema_version = "v44"
    db_path = os.environ.get("APP_DB_PATH") or str(instance_dir / default_db_name)
    # Never silently reopen the retired live/migrated databases.
    if Path(db_path).name in {"ahmed_cement.db", "ahmed_cement_v44.db"} and schema_version == "v44":
        db_path = str(instance_dir / default_db_name)
    os.environ["AMS_SCHEMA_VERSION"] = schema_version
    os.environ["APP_DB_PATH"] = db_path
    app_schema_version = schema_version
    # SQLite creates the database file on first connection, but it does not
    # create a missing custom parent directory.  Make a configured database
    # path just as safe as the default instance path on a fresh installation.
    db_parent = Path(db_path).expanduser().parent
    db_parent.mkdir(parents=True, exist_ok=True)
    # AUDIT-114/R17: the free tier cannot safely chew a 256 MB upload plus
    # a full-database verification pass; default to 64 MB (the largest real
    # full-DB import in this deployment is ~4 MB). Raise MAX_UPLOAD_MB only
    # if a legitimately larger import is actually needed.
    max_upload_mb = int(os.environ.get("MAX_UPLOAD_MB", "64") or "64")
    journal_mode = _resolve_sqlite_journal_mode(db_path)

    # Empty instance / deleted database → create a fresh empty SQLite file.
    # Existing database → leave it alone (no wipe, no replace, no extra locks).
    from app.services.instance_files import ensure_instance_runtime

    runtime_status = ensure_instance_runtime(
        instance_dir=instance_dir,
        db_path=Path(db_path),
        journal_mode=journal_mode,
    )
    snapshot_path = Path(
        os.environ.get("DB_HEALTH_SNAPSHOT_PATH")
        or str(Path(db_path).parent / "health_snapshot.json")
    )

    secret_file = instance_dir / "secret_key"
    secret = os.environ.get("SECRET_KEY")
    if not secret:
        if secret_file.exists():
            secret = secret_file.read_text(encoding="utf-8").strip()
        if not secret:
            secret = secrets.token_hex(32)
            secret_file.write_text(secret, encoding="utf-8")

    # Yard PCs use plain HTTP (http://192.168.x.x:5000). Secure + SameSite=None
    # cookies are dropped on HTTP, so POST /login 302 then GET / bounces to login.
    # For HTTPS/iframe set AMS_HTTPS=1 (or SESSION_COOKIE_SECURE=1 + SAMESITE=None).
    env_secure = os.environ.get("SESSION_COOKIE_SECURE")
    env_samesite = os.environ.get("SESSION_COOKIE_SAMESITE")
    use_https = (os.environ.get("AMS_HTTPS") or "").strip() == "1"
    if env_secure is None:
        cookie_secure = bool(use_https)
    else:
        cookie_secure = env_secure.strip() not in ("0", "false", "False", "")
    cookie_samesite = (env_samesite or ("None" if cookie_secure else "Lax")).strip() or "Lax"
    if str(cookie_samesite).lower() == "none" and not cookie_secure:
        cookie_samesite = "Lax"

    # Single-language bill filters (English / Urdu). Registered before the
    # template warm-up so receipts can render either language without mixing.
    from app.services.bilingual import bill_date, bill_label
    app.jinja_env.filters.setdefault('bill_label', bill_label)
    app.jinja_env.filters.setdefault('bill_date', bill_date)

    app.config.update(
        SECRET_KEY=secret,
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{db_path}",
        AMS_SCHEMA_VERSION=app_schema_version,
        APP_DB_PATH=db_path,
        AMS_V44_SCHEMA_PATH=str(root / "v44" / "SCHEMA_v4_4.sql"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SQLALCHEMY_ENGINE_OPTIONS={
            "connect_args": {"timeout": 30, "check_same_thread": False},
            # A pooled connection can be dead even though the file is fine:
            # a backup/copy job replaced the file, a laptop resumed, or a
            # network-mounted /home dropped the handle.  Without a pre-ping the
            # first request that checks out that connection fails, and the
            # failure repeats until the process restarts.  Recycling also caps
            # how long a connection can live.
            "pool_pre_ping": True,
            "pool_recycle": int(os.environ.get("DB_POOL_RECYCLE_SECONDS", "1800") or "1800"),
            "pool_timeout": 30,
        },
        SQLITE_JOURNAL_MODE=journal_mode,
        AMS_RUNTIME_DB_CREATED=bool(runtime_status.created),
        DB_HEALTH_SNAPSHOT_PATH=str(snapshot_path),
        MAX_CONTENT_LENGTH=max_upload_mb * 1024 * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(days=7),
        REMEMBER_COOKIE_DURATION=timedelta(days=7),
        SESSION_COOKIE_NAME="ams_session",
        SESSION_COOKIE_PATH="/",
        SESSION_COOKIE_DOMAIN=None,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE=cookie_samesite,
        SESSION_COOKIE_SECURE=cookie_secure,
        SESSION_REFRESH_EACH_REQUEST=True,
        REMEMBER_COOKIE_HTTPONLY=True,
        REMEMBER_COOKIE_SAMESITE=cookie_samesite,
        REMEMBER_COOKIE_SECURE=cookie_secure,
        PREFERRED_URL_SCHEME="https" if cookie_secure else "http",
        FULL_RAW_IMPORT_ENABLED="1",
        IMPORT_TMP_DIR=str(tmp_dir),
        IMPORT_UPLOADS_DIR=str(tmp_dir / "import_uploads"),
        IMPORT_REPORTS_DIR=str(tmp_dir / "import_reports"),
        IMPORT_ARTIFACT_RETENTION_SECONDS=int(
            os.environ.get("IMPORT_ARTIFACT_RETENTION_SECONDS", str(7 * 24 * 3600)) or "0"
        ),
        # Origin printed into the QR code on an Urdu receipt or client ledger.
        # Empty means "use Settings or the active request address". Set it
        # when the app sits behind a Cloudflare Worker or proxy:
        #   PUBLIC_BASE_URL=https://still-base-ac7a.rizwanahmedsora9.workers.dev
        _ENV_PUBLIC_BASE_URL=(os.environ.get("PUBLIC_BASE_URL") or "").strip(),
        PUBLIC_BASE_URL=(os.environ.get("PUBLIC_BASE_URL") or "").strip(),
        UPLOAD_DIR=os.environ.get("UPLOAD_DIR", str(root / "static" / "uploads")),
        # Daily database backups deliberately live OUTSIDE instance/ so they
        # survive someone deleting or rebuilding the runtime folder.
        BACKUP_DIR=os.environ.get("BACKUP_DIR", str(root / "backups" / "db")),
        DAILY_BACKUP_SCHEDULER=(
            os.environ.get("AMS_DAILY_BACKUP_SCHEDULER", "1").strip().lower()
            not in ("0", "false", "no")
        ),
        MAINTENANCE_TEMP_DIR=os.environ.get("MAINTENANCE_TEMP_DIR", str(instance_dir / "storage" / "temp")),
        BACKUP_INTERVAL_SECONDS=int(os.environ.get("BACKUP_INTERVAL_SECONDS", "3600") or "3600"),
        BACKUP_RETENTION=int(os.environ.get("BACKUP_RETENTION", "3") or "3"),
        BACKUP_LOCK_STALE_SECONDS=int(os.environ.get("BACKUP_LOCK_STALE_SECONDS", "7200") or "7200"),
        TEMP_RETENTION_SECONDS=int(os.environ.get("TEMP_RETENTION_SECONDS", "86400") or "86400"),
        MIN_FREE_DISK_BYTES=int(os.environ.get("MIN_FREE_DISK_BYTES", str(100 * 1024 * 1024)) or "0"),
        # Do not create backup database files from the web process. Backups
        # remain available only through an explicit maintenance operation.
        BACKUP_EMBEDDED_SCHEDULER=(os.environ.get("BACKUP_EMBEDDED_SCHEDULER", "0").strip().lower() not in ("0", "false", "no")),
        # Scheduled work (reconcile pass, daily backup, embedded maintenance)
        # runs only where it was asked for: ``AMS_ENABLE_BACKGROUND_WORKERS=1``.
        # It defaults to off so a WSGI worker never copies the database or
        # rewrites balances from a request.
        ENABLE_BACKGROUND_WORKERS=(
            os.environ.get("AMS_ENABLE_BACKGROUND_WORKERS", "").strip().lower()
            in ("1", "true", "yes", "on")
        ),
        # Versioned automatic schema migrations (app/services/auto_migrate.py):
        # numbered NNNN_*.sql files in app/migrations/ apply on every boot.
        MIGRATIONS_DIR=os.environ.get(
            "MIGRATIONS_DIR", str(Path(app.root_path) / "migrations")
        ),
        MIGRATIONS_ALLOW_DESTRUCTIVE=(
            os.environ.get("MIGRATIONS_ALLOW_DESTRUCTIVE") or "0"
        ).strip().lower() in ("1", "true", "on", "yes"),
        TESTING=False,
    )
    if test_config:
        app.config.update(test_config)

    _configure_logging(app)
    db.init_app(app)

    # Unhandled failures: reference code + bounded technical log, rollback of
    # the failed transaction, and one retry for a transiently locked SQLite
    # database.  Installed before the bootstrap so a bootstrap-time exception
    # is recorded the same way.
    from app.services.errors import install_error_handling

    install_error_handling(app)

    # SQLite does not enforce declared foreign keys unless each connection
    # explicitly enables them. Register this before bootstrap opens the first
    # connection so future lifecycle regressions fail transactionally instead
    # of accumulating silent dangling rows.
    with app.app_context():
        engine = db.engine
        if engine.dialect.name == "sqlite" and not getattr(engine, "_ams_fk_listener", False):
            @event.listens_for(engine, "connect")
            def _enable_sqlite_foreign_keys(dbapi_connection, _connection_record):
                cursor = dbapi_connection.cursor()
                try:
                    cursor.execute("PRAGMA foreign_keys=ON")
                    # Wait longer than one page render before giving up: a
                    # backup copy or an import must not turn a shop-floor save
                    # into "database is locked".
                    cursor.execute("PRAGMA busy_timeout=15000")
                    enabled = cursor.execute("PRAGMA foreign_keys").fetchone()
                    if not enabled or enabled[0] != 1:
                        raise RuntimeError("SQLite foreign-key enforcement could not be enabled")
                finally:
                    cursor.close()

            engine._ams_fk_listener = True

    login_manager = LoginManager()
    login_manager.login_view = "login"
    # "basic" flags a session whose identifier (IP + User-Agent) changed: the
    # session is marked not-fresh rather than dropped, so shop-floor PCs behind
    # NAT do not get logged out, but a replayed cookie from another device is
    # detectable. "strong" would force re-login on any such change.
    login_manager.session_protection = "basic"
    login_manager.init_app(app)

    from app.services.permissions import load_user

    login_manager.user_loader(load_user)

    # Core domain routes first so short names (clients, login, …) are not
    # stolen by later feature packs such as fbm_rentals.clients.
    from app.blueprints.core import bp as core_bp
    from app.blueprints.auth import bp as auth_bp
    from app.blueprints.sales import bp as sales_bp
    from app.blueprints.masters import bp as masters_bp
    from app.blueprints.ledgers import bp as ledgers_bp
    from app.blueprints.ops import bp as ops_bp
    from app.blueprints.reports import bp as reports_bp
    from app.blueprints.api import bp as api_bp
    from app.blueprints.system import bp as system_bp
    from app.blueprints.misc import bp as misc_bp
    from app.blueprints.migration import bp as migration_bp

    for bp in (
        core_bp,
        auth_bp,
        sales_bp,
        masters_bp,
        ledgers_bp,
        ops_bp,
        reports_bp,
        api_bp,
        system_bp,
        misc_bp,
        migration_bp,
    ):
        if bp.name not in app.blueprints:
            app.register_blueprint(bp)

    _alias_unprefixed_endpoints(app)

    load_modules(app, blueprint_dir=str(root / "blueprints"))

    from app.hooks import register_hooks

    register_hooks(app)

    # SQLite write contention (PythonAnywhere / any network-filesystem host uses
    # the rollback journal, where an open reader blocks a save's COMMIT).  Every
    # mutating route is wrapped so a save waits for the lock instead of failing
    # with a 15 s "database is locked" 500.  Must run after all blueprints and
    # feature packs are registered.
    from app.services.db_busy import install_busy_retry

    install_busy_retry(app)

    from app.services.import_jobs import register_import_job_routes

    register_import_job_routes(app)

    # Compile every Jinja template once at startup so the first request after a
    # worker (re)start doesn't pay a ~200ms+ compile cost for layout.html +
    # the large module pages.  The compiled code is persisted (bytecode cache)
    # so a restart only recompiles what actually changed.
    _install_template_bytecode_cache(app)
    _warm_template_cache(app)

    with app.app_context():
        try:
            from app.services import health as health_service
            from app.services import constants as constants_svc
            # Health protection and service helpers must follow the configured
            # v4.4 file, not a retired live path captured at import time.
            health_service.db_path = db_path
            constants_svc.db_path = db_path
            health_service._DB_HEALTH_SNAPSHOT_PATH = str(snapshot_path)
            constants_svc._DB_HEALTH_SNAPSHOT_PATH = str(snapshot_path)
            from app.services import schema as schema_svc
            schema_svc.db_path = db_path
            schema_svc._DB_HEALTH_SNAPSHOT_PATH = str(snapshot_path)
            from app.services.health import (
                _guard_db_file_before_bootstrap,
                _db_health_check_after_bootstrap,
            )
            from app.services.schema import _bootstrap_database
            if runtime_status.created:
                # Recreating a deleted/missing file must not be treated as
                # accidental data loss against a leftover health snapshot.
                app.config["_DB_FILE_WAS_MISSING"] = True
                try:
                    snapshot_path.unlink(missing_ok=True)
                except OSError:
                    pass

            if app.config.get("TESTING"):
                from app.services.schema import (
                    _ensure_default_admin,
                    _ensure_loan_party_two_way_schema,
                    _ensure_model_columns,
                )
                db.create_all()
                _ensure_model_columns()
                _ensure_loan_party_two_way_schema()
                # Keep a fresh test database usable in the same way as a fresh
                # production database.  The smoke tests and local developers
                # rely on the documented Admin login even when no rows exist.
                _ensure_default_admin()
            else:
                if app.config.get("AMS_SCHEMA_VERSION") == "v44":
                    from app.services.v44_schema import (
                        initialize_v44_database,
                        retire_legacy_database_files,
                        schema_path as v44_schema_path,
                    )
                    retire_legacy_database_files(instance_dir, extra_dirs=[root / "v44"])
                    _retire_stale_live_health_snapshot(snapshot_path)
                _guard_db_file_before_bootstrap()
                if app.config.get("AMS_SCHEMA_VERSION") == "v44":
                    # Optional v4.4 SQL bundle. It is not in the repo; skip
                    # silently and let the ORM bootstrap create tables. Never
                    # abort here — that used to leave no `user` table and a
                    # 500 on every login.
                    try:
                        if v44_schema_path().exists():
                            initialize_v44_database(
                                db_path,
                                default_user=(os.environ.get("DEFAULT_ADMIN_USER") or "Admin").strip() or "Admin",
                                default_password=(os.environ.get("DEFAULT_ADMIN_PASSWORD") or "Admin@fbm12345").strip() or "Admin@fbm12345",
                            )
                    except Exception:
                        logging.getLogger(__name__).warning(
                            "v4.4 schema bootstrap skipped; continuing with the "
                            "ORM schema bootstrap.",
                            exc_info=True,
                        )
                _bootstrap_database()
                try:
                    _db_health_check_after_bootstrap()
                except Exception:
                    # A health *report* failure must not leave the app running
                    # against a half-bootstrapped database.
                    logging.getLogger(__name__).warning(
                        "Post-bootstrap DB health check failed", exc_info=True
                    )
        except Exception:
            logging.getLogger(__name__).critical(
                "DATABASE BOOTSTRAP FAILED — the application will return HTTP 500 "
                "on any page that touches the database.",
                exc_info=True,
            )
            app.config["AMS_BOOTSTRAP_ERROR"] = traceback.format_exc()

        # Automatic versioned schema migrations. Runs on every start (tests,
        # local runs, and every deployment reload) after the ORM bootstrap so
        # model tables already exist; only pending numbered SQL files in
        # app/migrations/ are applied and recorded in migration_history.
        # A failure here is fatal: continuing could expose a partially updated
        # schema to users and corrupt/report inconsistent business data.
        try:
            from app.services.auto_migrate import (
                run_sql_migrations as _run_auto_migrations,
            )

            app.config["AMS_MIGRATION_REPORT"] = _run_auto_migrations()
        except Exception as exc:
            logging.getLogger(__name__).critical(
                "Automatic schema migration failed; refusing to serve requests "
                "against a potentially partial schema.",
                exc_info=True,
            )
            raise RuntimeError("Automatic schema migration failed; application startup aborted.") from exc

        # Permanent entry numbers.  Assigned once on INSERT and never updated,
        # so editing a record can no longer move it up or down a list (the lists
        # used to order by date_posted, which an edit rewrote).  Installed after
        # the migrations above, because 0016 adds the column it fills.
        try:
            from app.services.entry_seq import install_listeners as _install_entry_seq

            _install_entry_seq()
        except Exception:
            # Numbering is a display convenience: a failure here must never stop
            # the shop from trading.  The lists fall back to date ordering.
            logging.getLogger(__name__).warning(
                "Permanent entry numbering could not be installed; lists fall "
                "back to date ordering.",
                exc_info=True,
            )

        # Daily Cash & Bank Reconciliation stores the physically counted
        # amounts and verified day locks against a numeric account id.  Older
        # wipes left those rows behind, and SQLite hands a deleted id back out
        # to the next account created — so the board showed figures nobody
        # typed for the new accounts.  Purge anything that cannot belong to the
        # accounts that exist now.  The board repeats this on every render;
        # running it at boot means an existing database is repaired on restart
        # even if the page is never opened.
        try:
            from app.services.cash_day_recon import purge_stale_reconciliation_state

            stale_positions, stale_locks = purge_stale_reconciliation_state()
            if stale_positions or stale_locks:
                logging.getLogger(__name__).info(
                    "Purged stale daily reconciliation state: %s positions, %s day locks",
                    stale_positions,
                    stale_locks,
                )
        except Exception:
            logging.getLogger(__name__).warning(
                "Daily reconciliation startup cleanup skipped", exc_info=True
            )

    # Start once at application startup, never from a user request. The
    # cross-process filesystem lock prevents duplicate work under Gunicorn.
    # Both schedulers refuse to start unless AMS_ENABLE_BACKGROUND_WORKERS is
    # set (``wsgi.py`` never sets it), so a deployed web worker stays free of
    # maintenance threads; cron runs them explicitly instead.
    from app.services.maintenance import start_embedded_scheduler
    start_embedded_scheduler(app)

    # Daily database backup (outside instance/, optionally emailed). Disabled
    # by default in tests; the per-day check + file lock make a cron job safe
    # alongside this thread.
    from app.services.daily_backup import start_daily_backup_scheduler
    start_daily_backup_scheduler(app)

    return app


_NETWORK_FILESYSTEMS = {
    "nfs", "nfs4", "cifs", "smb", "smb2", "smbfs", "afs", "fuse.sshfs",
    "9p", "glusterfs", "lustre", "ceph", "beegfs", "afpfs", "ncpfs",
}


def _on_network_filesystem(path: str) -> bool:
    """Best-effort detection of a network-mounted filesystem.

    SQLite's WAL journal needs POSIX shared memory, which network filesystems
    do not provide.  Shared hosting such as PythonAnywhere serves /home over
    NFS-like storage, so a WAL database there fails with "unable to open
    database file" / "disk I/O error" on every request.
    """
    try:
        target = Path(path).expanduser().resolve()
    except Exception:
        return False
    candidate = target if target.exists() else target.parent
    try:
        mounts = Path("/proc/mounts").read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    best_point, best_type = "", ""
    for line in mounts.splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        point, fstype = parts[1].replace("\\040", " "), parts[2]
        try:
            mount_path = Path(point)
        except Exception:
            continue
        if candidate == mount_path or mount_path in candidate.parents:
            if len(point) >= len(best_point):
                best_point, best_type = point, fstype
    return best_type.lower() in _NETWORK_FILESYSTEMS


def _retire_stale_live_health_snapshot(snapshot_path: Path) -> None:
    """Drop a health snapshot that still describes the retired live database."""
    if not snapshot_path.exists():
        return
    try:
        import json
        payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
    except Exception:
        snapshot_path.unlink(missing_ok=True)
        return
    db_name = Path(str(payload.get("db_path") or "")).name
    if db_name in {"ahmed_cement.db", "ahmed_cement_v44.db"}:
        snapshot_path.unlink(missing_ok=True)


def _resolve_sqlite_journal_mode(db_path: str) -> str:
    """Pick a journal mode that actually works on this host.

    Override explicitly with SQLITE_JOURNAL_MODE=WAL|DELETE|TRUNCATE.
    """
    configured = (os.environ.get("SQLITE_JOURNAL_MODE") or "").strip().upper()
    allowed = {"WAL", "DELETE", "TRUNCATE", "PERSIST", "MEMORY", "OFF"}
    if configured in allowed:
        return configured
    # PythonAnywhere exports these markers in the web-app environment.
    on_pythonanywhere = any(
        key in os.environ
        for key in ("PYTHONANYWHERE_DOMAIN", "PYTHONANYWHERE_SITE")
    )
    if on_pythonanywhere or _on_network_filesystem(db_path):
        return "DELETE"
    return "WAL"


def _install_template_bytecode_cache(app: Flask) -> None:
    """Persist compiled templates between worker restarts.

    Jinja recompiled all 139 templates on every ``create_app()`` — the single
    largest part of boot (measured ~1.5 s of a 1.8 s boot).  A
    :class:`jinja2.FileSystemBytecodeCache` keeps the compiled code on disk and
    invalidates an entry exactly when its template source changes, so the warm
    path is fast without any staleness rules of our own.

    Deliberately conservative:

    * never in tests (a throw-away app per test would only churn the folder),
    * never when ``TEMPLATES_AUTO_RELOAD`` is on (a developer wants the source),
    * a failure to write the cache leaves plain Jinja behaviour in place.
    """
    try:
        if app.config.get("TESTING") or app.jinja_env.auto_reload:
            return

        from jinja2 import FileSystemBytecodeCache

        cache_dir = Path(app.instance_path) / "cache" / "jinja"
        cache_dir.mkdir(parents=True, exist_ok=True)
        app.jinja_env.bytecode_cache = FileSystemBytecodeCache(str(cache_dir))
        app.config["AMS_TEMPLATE_CACHE_DIR"] = str(cache_dir)
    except Exception:
        logging.getLogger(__name__).warning(
            "Template bytecode cache disabled; templates will compile per boot.",
            exc_info=True,
        )


def _warm_template_cache(app: Flask) -> None:
    """Pre-compile templates so the first page hit after boot is already warm.

    Only compiles (``jinja_env.get_template``); it never renders, so no request
    context or context-processor data is needed.

    Compilation results are persisted in a bytecode cache under ``instance/``
    (see :func:`_install_template_bytecode_cache`), so this costs ~30 ms on a
    worker restart instead of ~1.5 s, and only the templates that actually
    changed are recompiled after a deploy.
    """
    try:
        templates_root = Path(app.template_folder)
        count = 0
        for path in templates_root.rglob("*.html"):
            rel = path.relative_to(templates_root).as_posix()
            try:
                app.jinja_env.get_template(rel)
                count += 1
            except Exception:
                # A broken/optional template must not block startup.
                continue
        logging.getLogger(__name__).info("Warmed Jinja cache for %d templates", count)
    except Exception:
        logging.getLogger(__name__).warning("Template warm-up skipped", exc_info=True)


def _alias_unprefixed_endpoints(app: Flask) -> None:
    """Keep legacy url_for('login') / templates working after blueprint split."""
    existing = set(app.view_functions)
    extras = []
    for rule in list(app.url_map.iter_rules()):
        if "." not in rule.endpoint:
            continue
        short = rule.endpoint.split(".", 1)[1]
        if short in existing:
            continue
        view = app.view_functions.get(rule.endpoint)
        if view is None:
            continue
        app.view_functions[short] = view
        extras.append((rule.rule, short, view, sorted((rule.methods or set()) - {"HEAD", "OPTIONS"})))
        existing.add(short)
    for rule, short, view, methods in extras:
        try:
            app.add_url_rule(rule, endpoint=short, view_func=view, methods=methods or None)
        except Exception:
            pass


def _configure_logging(app: Flask) -> None:
    """Configure console output and a bounded technical diagnostic log."""
    root = logging.getLogger()
    formatter = logging.Formatter("%(asctime)s %(levelname)s [%(name)s]: %(message)s")
    if not any(getattr(handler, "_ams_console", False) for handler in root.handlers):
        console = logging.StreamHandler()
        console._ams_console = True
        console.setLevel(logging.INFO)
        console.setFormatter(formatter)
        root.addHandler(console)

    log_dir = Path(app.instance_path) / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = (log_dir / "errorlog.txt").resolve()
        existing = any(
            isinstance(handler, RotatingFileHandler)
            and Path(getattr(handler, "baseFilename", "")).resolve() == log_path
            for handler in root.handlers
        )
        if not existing:
            rotating = RotatingFileHandler(
                log_path,
                maxBytes=int(os.environ.get("ERROR_LOG_MAX_BYTES", str(2 * 1024 * 1024))),
                backupCount=int(os.environ.get("ERROR_LOG_BACKUP_COUNT", "3")),
                encoding="utf-8",
            )
            rotating.setLevel(logging.WARNING)
            rotating.setFormatter(formatter)
            root.addHandler(rotating)
    except OSError:
        # A read-only log directory must not prevent the application starting.
        root.exception("Unable to configure rotating file logging")
    root.setLevel(logging.INFO)
    logging.getLogger("werkzeug").setLevel(logging.WARNING)

"""Run the AMS self-check suites in order.

Usage (from the repository root):

    python tests/run_all.py            # fast suites (~1 minute total)
    python tests/run_all.py --scale    # additionally the 10k-row durability test (slow)

Each suite runs as a separate process against its own throwaway database
(see tests/README.md) and exits non-zero on any failure.
"""
import os
import subprocess
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTS = os.path.join(REPO_ROOT, 'tests')

FAST = [
    ('e2e_smoke.py', 'End-to-end business chain (login -> GRN -> booking -> sale -> payments -> reports)'),
    ('delete_semantics.py', 'Immediate delete: money/stock reversed, Restore gone, guards intact'),
    ('deep_verification.py', 'FIFO costing, booking allocation, negative stock, concurrency'),
]

SCALE = [
    ('scale_seed.py', 'Seed ~10,000 of each record type into a throwaway DB'),
    ('scale_verify.py', 'Restart against the seeded DB and prove nothing auto-deletes / math holds'),
]


def run(script):
    print()
    print('=' * 78)
    print(f'>>> tests/{script}')
    print('=' * 78, flush=True)
    r = subprocess.run([sys.executable, os.path.join(TESTS, script)], cwd=REPO_ROOT)
    return r.returncode


def main():
    suites = list(FAST)
    if '--scale' in sys.argv or '-s' in sys.argv:
        suites += SCALE
    failures = {}
    for script, desc in suites:
        print(f'\n# {desc}')
        code = run(script)
        if code != 0:
            failures[script] = code
    print()
    print('=' * 78)
    if failures:
        print('SELF-CHECK FAILED:', ', '.join(failures))
        sys.exit(1)
    print('SELF-CHECK PASSED:', ', '.join(s for s, _ in suites))
    print('=' * 78)


if __name__ == '__main__':
    main()

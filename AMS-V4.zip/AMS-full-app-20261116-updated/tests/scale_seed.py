"""AMS scale + durability test.

Seeds 10,000 records into every major section of a fresh database, then:
  1. verifies row counts & account math,
  2. RESTARTS the app (create_app again -> boot-time void purge runs),
  3. re-verifies every count (detects any accidental automatic deletion),
  4. checks the main report pages render and match independent SQL math.
"""
import os, sys, time, sqlite3
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH = os.path.join(REPO_ROOT, 'tests', '.scratch')
os.makedirs(SCRATCH, exist_ok=True)
os.environ['APP_DB_PATH'] = os.path.join(SCRATCH, 'scale.db')
os.environ['DB_HEALTH_SNAPSHOT_PATH'] = os.path.join(SCRATCH, 'scale_snapshot.json')
os.environ['AMS_ENABLE_BACKGROUND_WORKERS'] = ''
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)
for suffix in ('', '-wal', '-shm', '-journal'):
    p = os.environ['APP_DB_PATH'] + suffix
    if os.path.exists(p):
        os.remove(p)

from app import create_app
t0 = time.time()
app = create_app()
print(f'boot 1: {time.time()-t0:.1f}s')

DB = os.environ['APP_DB_PATH']
N = 10000

con = sqlite3.connect(DB)
con.execute('PRAGMA foreign_keys=ON')
cur = con.cursor()

def q(sql, params=()):
    return cur.execute(sql, params)

print('seeding masters...')
now = '2026-11-16 08:00:00'
cur.execute("INSERT INTO material (code, name, category_id, unit_price, unit, is_active) VALUES (?,?,?,?,?,?)",
            ('SCALECEM', 'Scale Cement 50kg', None, 1100.0, 'Bags', 1))
MAT_ID = cur.lastrowid
cur.execute("INSERT INTO supplier (name, phone, address, opening_balance, is_active) VALUES (?,?,?,?,?)",
            ('Scale Supplier', '03000000010', 'Scale Street', 0.0, 1))
SUP_ID = cur.lastrowid
cur.execute("INSERT INTO client (code, name, phone, category, opening_balance, book_no, cement_book_no, steel_book_no, financial_book_no, is_active) VALUES (?,?,?,?,?,?,?,?,?,?)",
            ('SCL-00001', 'Scale Client', '03000000011', 'General', 0.0, '', '', '', '', 1))
CLI_ID = cur.lastrowid
cur.execute("""INSERT INTO account (name, category, source_category, account_type, type, balance, balance_minor,
              opening_balance, opening_balance_minor, opening_balance_date, is_active, account_status,
              class_category, class_subcategory, class_account_type, channel)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            ('Scale Main Cash', 'cash', 'cash', 'cash', 'cash', 1000000.0, 100000000,
             1000000.0, 100000000, '2026-01-01 00:00:00', 1, 'active',
             'Assets', 'Cash', 'Main Cash', 'cash'))
ACC_ID = cur.lastrowid
cur.execute("INSERT INTO loan_party (name, note, opening_principal_minor, is_active, created_at) VALUES (?,?,?,?,?)",
            ('Scale Lender', 'scale test', 0, 1, now))
LOAN_PARTY_ID = cur.lastrowid
cur.execute("INSERT INTO cash_flow_category (name, direction, is_active, notes) VALUES (?,?,?,?)",
            ('Scale Expenses', 'out', 1, 'scale test'))
CAT_ID = cur.lastrowid
print(f'masters: material={MAT_ID} supplier={SUP_ID} client={CLI_ID} account={ACC_ID} loan_party={LOAN_PARTY_ID} category={CAT_ID}')

def day(i):
    return f'2026-{(i % 10) + 1:02d}-{(i % 28) + 1:02d} 09:00:00'

print('seeding 10,000 GRNs (+items +stock IN entries)...')
grn_rows = []
for i in range(N):
    bn = f'GRN-SCALE-{i+1:05d}'
    grn_rows.append((SUP_ID, 'Scale Supplier', bn, day(i), 0,
                     0.0, 1000.0, 0.0, 0.0, 0.0,
                     1000.0, 100000, 0.0,
                     'cash', 'material', 1000.0, 100000,
                     f'scale grn {i+1}', 1, 'scale'))
cur.executemany("""INSERT INTO grn (supplier_id, supplier, auto_bill_no, date_posted, is_void,
                  loading_cost, freight_cost, other_expense, adjustment_amount, discount,
                  supplier_material_amount, supplier_material_amount_minor, paid_amount,
                  payment_type, costing_mode, landed_cost_total, landed_cost_total_minor,
                  note, revision, created_by)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", grn_rows)

print('seeding 10,000 bookings...')
bk_rows = []
for i in range(N):
    bk_rows.append(('Scale Client', 260.0, 0.0, f'BK-SCALE-{i+1:05d}', day(i), 0, 0.0, '', f'booking note {i}'))
cur.executemany("""INSERT INTO booking (client_name, amount, paid_amount, auto_bill_no, date_posted,
                    is_void, discount, discount_reason, note)
                    VALUES (?,?,?,?,?,?,?,?,?)""", bk_rows)

print('seeding 10,000 cash sales (+items +stock OUT)...')
sale_rows = []
for i in range(N):
    sale_rows.append(('Scale Client', 'SCL-00001', 'Cash', 130.0, 130.0, 0.0, f'SB-SCALE-{i+1:05d}', day(i), 0, 'Scale Driver', 'Cash', ACC_ID))
cur.executemany("""INSERT INTO direct_sale (client_name, client_code, category, amount, paid_amount, discount,
                       auto_bill_no, date_posted, is_void, driver_name, payment_method, payment_account_id)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", sale_rows)

print('fetching ids for child rows...')
grn_ids = [r[0] for r in q('SELECT id FROM grn').fetchall()]
bk_ids = [r[0] for r in q('SELECT id FROM booking').fetchall()]
sale_ids = [r[0] for r in q('SELECT id FROM direct_sale').fetchall()]

print('seeding 10,000 GRN items...')
cur.executemany("INSERT INTO grn_item (grn_id, mat_name, qty, price_at_time, is_void) VALUES (?,?,?,?,?)",
                [(g, 'Scale Cement 50kg', 10.0, 100.0, 0) for g in grn_ids])
print('seeding 10,000 booking items...')
cur.executemany("INSERT INTO booking_item (booking_id, material_name, qty, price_at_time) VALUES (?,?,?,?)",
                [(b, 'Scale Cement 50kg', 2.0, 130.0) for b in bk_ids])
print('seeding 10,000 sale items...')
cur.executemany("INSERT INTO direct_sale_item (sale_id, product_name, qty, price_at_time) VALUES (?,?,?,?)",
                [(s, 'Scale Cement 50kg', 1.0, 130.0) for s in sale_ids])

print('seeding 20,000 stock entries (IN from GRN, OUT from sales)...')
entry_rows = []
for g in grn_ids:
    entry_rows.append((day(g % N), 'IN', 'Scale Cement 50kg', 'Scale Supplier', '', 'Cement', 10.0, f'SCALE-GRN-{g:05d}', 'GRN Receipt', 'Scale Cement 50kg', 'grn', str(g), 'IN'))
for s in sale_ids:
    entry_rows.append((day(s % N), 'OUT', 'Scale Cement 50kg', 'Scale Client', 'SCL-00001', 'Cash Customer', 1.0, f'SCALE-SALE-{s:05d}', 'Direct Sale', 'Scale Cement 50kg', 'direct_sale', str(s), 'OUT'))
cur.executemany("""INSERT INTO entry (date, time, type, material, client, client_code, client_category,
                    qty, bill_no, nimbus_no, booked_material, source_table, source_id, transaction_type)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                [(r[0], '09:00:00', r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12]) for r in entry_rows])

print('seeding 10,000 client payments (+account transactions)...')
pay_rows = []
tx_rows = []
for i in range(N):
    pay_rows.append((CLI_ID, 'Scale Client', 500.0, 50000, 'Cash', 'Receipt', day(i), 0, f'CP-SCALE-{i+1:05d}', ACC_ID))
cur.executemany("""INSERT INTO payment (client_id, client_name, amount, amount_minor, method, payment_type,
                     date_posted, is_void, auto_bill_no, payment_account_id)
                     VALUES (?,?,?,?,?,?,?,?,?,?)""", pay_rows)

print('seeding 10,000 supplier payments (+account transactions)...')
sup_pay_rows = []
for i in range(N):
    sup_pay_rows.append((SUP_ID, 500.0, 50000, 'Cash', 'Payment', day(i), 0, f'SP-SCALE-{i+1:05d}', ACC_ID, 'material'))
cur.executemany("""INSERT INTO supplier_payment (supplier_id, amount, amount_minor, method, payment_type,
                     date_posted, is_void, auto_bill_no, payment_account_id, payment_kind)
                     VALUES (?,?,?,?,?,?,?,?,?,?)""", sup_pay_rows)

print('seeding 10,000 loan movements (+account transactions)...')
loan_rows = []
for i in range(N):
    loan_rows.append((LOAN_PARTY_ID, 'received', 20000, ACC_ID, day(i), f'LN-SCALE-{i+1:05d}', now))
cur.executemany("""INSERT INTO loan_movement (loan_party_id, movement_type, amount_minor, cash_account_id,
                     date_posted, reference, created_at)
                     VALUES (?,?,?,?,?,?,?)""", loan_rows)

print('seeding 10,000 expenses (+account transactions)...')
cf_rows = []
for i in range(N):
    cf_rows.append(('out', 50.0, 5000, ACC_ID, CAT_ID, 'Scale electricity & transport', day(i), 'scale expense', f'CF-SCALE-{i+1:05d}'))
cur.executemany("""INSERT INTO cash_flow_entry (direction, amount, amount_minor, account_id, category_id,
                    description, date_posted, note, reference)
                    VALUES (?,?,?,?,?,?,?,?,?)""", cf_rows)

print('seeding matching account transactions...')
# sales receipts +
for i, s in enumerate(sale_ids):
    tx_rows.append((None, ACC_ID, 130.0, 13000, f'Sale receipt [SRC:DirectSale:{s}]', day(i), 0, 'Receipt', 'direct_sale', str(s)))
for i in range(N):
    tx_rows.append((None, ACC_ID, 500.0, 50000, 'Client payment received', day(i), 0, 'Receipt', 'payment', str(i+1)))
# supplier payments -
for i in range(N):
    tx_rows.append((ACC_ID, None, 500.0, 50000, 'GRN payment to Scale Supplier', day(i), 0, 'Payment', 'supplier_payment', str(i+1)))
# loans +
for i in range(N):
    tx_rows.append((None, ACC_ID, 200.0, 20000, 'Loan principal received from Scale Lender', day(i), 0, 'Receipt', 'loan_movement', str(i+1)))
# expenses -
for i in range(N):
    tx_rows.append((ACC_ID, None, 50.0, 5000, 'Scale expense', day(i), 0, 'Payment', 'cash_flow', str(i+1)))
cur.executemany("""INSERT INTO account_transaction (from_account_id, to_account_id, amount, amount_minor,
                   description, date_posted, is_void, transaction_type, source_type, source_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""", tx_rows)

# set account balance to the ledger-derived value so stored field == computed
incoming = 130.0*N + 500.0*N + 200.0*N
outgoing = 500.0*N + 50.0*N
expected_balance = 1000000.0 + incoming - outgoing
cur.execute("UPDATE account SET balance=?, balance_minor=? WHERE id=?",
            (expected_balance, int(round(expected_balance*100)), ACC_ID))
con.commit()
print(f'expected account balance = {expected_balance:,.2f}')

counts = {}
for t in ['grn','grn_item','booking','booking_item','direct_sale','direct_sale_item','entry',
          'payment','supplier_payment','loan_movement','cash_flow_entry','account_transaction']:
    counts[t] = q(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
print('counts after seed:', counts)
con.close()

import json
json.dump({'counts': counts, 'expected_balance': expected_balance,
           'ids': {'mat': MAT_ID, 'sup': SUP_ID, 'cli': CLI_ID, 'acc': ACC_ID, 'loan': LOAN_PARTY_ID}},
          open(os.path.join(SCRATCH, 'scale_meta.json'), 'w'))
print('SEED COMPLETE')

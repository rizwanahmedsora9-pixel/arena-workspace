"""Boot-2 durability + math verification on the 10k-scale database."""
import os, sys, time, json, sqlite3
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH = os.path.join(REPO_ROOT, 'tests', '.scratch')
META = os.path.join(SCRATCH, 'scale_meta.json')
if not os.path.exists(META):
    sys.exit('scale_meta.json not found — run "python tests/scale_seed.py" first (it takes a few minutes).')
os.environ['APP_DB_PATH'] = os.path.join(SCRATCH, 'scale.db')
os.environ['DB_HEALTH_SNAPSHOT_PATH'] = os.path.join(SCRATCH, 'scale_snapshot.json')
os.environ['AMS_ENABLE_BACKGROUND_WORKERS'] = ''
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)

meta = json.load(open(META))
counts_before = meta['counts']
ACC_ID = meta['ids']['acc']

DB = os.environ['APP_DB_PATH']

def table_counts():
    con = sqlite3.connect(f'file:{DB}?mode=ro', uri=True)
    out = {t: con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in counts_before}
    con.close()
    return out

t0 = time.time()
from app import create_app
app = create_app()
print(f'boot 2 (restart with wipe/purge logic): {time.time()-t0:.1f}s')
boot_err = app.config.get('AMS_BOOTSTRAP_ERROR')
print('bootstrap error:', boot_err)

counts_after = table_counts()
print()
print(f'{"table":<22}{"before":>10}{"after":>10}  status')
ok = True
for t, b in counts_before.items():
    a = counts_after[t]
    status = 'OK' if a == b else 'LOST!'
    if a != b:
        ok = False
    print(f'{t:<22}{b:>10}{a:>10}  {status}')
print()
print('DATA SURVIVED RESTART:', 'YES' if ok else 'NO — DATA LOST')

# ---------- independent SQL math ----------
con = sqlite3.connect(f'file:{DB}?mode=ro', uri=True)
cur = con.cursor()

sales_sum = cur.execute("SELECT COALESCE(SUM(amount),0) FROM direct_sale WHERE COALESCE(is_void,0)=0").fetchone()[0]
sale_paid = cur.execute("SELECT COALESCE(SUM(paid_amount),0) FROM direct_sale WHERE COALESCE(is_void,0)=0").fetchone()[0]
pay_sum = cur.execute("SELECT COALESCE(SUM(amount),0) FROM payment WHERE COALESCE(is_void,0)=0").fetchone()[0]
sup_sum = cur.execute("SELECT COALESCE(SUM(amount),0) FROM supplier_payment WHERE COALESCE(is_void,0)=0").fetchone()[0]
loan_sum = cur.execute("SELECT COALESCE(SUM(amount_minor),0) FROM loan_movement WHERE movement_type='received'").fetchone()[0] / 100
exp_sum = cur.execute("SELECT COALESCE(SUM(amount),0) FROM cash_flow_entry WHERE COALESCE(is_void,0)=0 AND direction='out'").fetchone()[0]
in_stock = cur.execute("SELECT COALESCE(SUM(qty),0) FROM entry WHERE type='IN' AND COALESCE(is_void,0)=0").fetchone()[0]
out_stock = cur.execute("SELECT COALESCE(SUM(qty),0) FROM entry WHERE type='OUT' AND COALESCE(is_void,0)=0").fetchone()[0]
grn_value = cur.execute("SELECT COALESCE(SUM(supplier_material_amount),0) FROM grn WHERE COALESCE(is_void,0)=0").fetchone()[0]
booking_value = cur.execute("SELECT COALESCE(SUM(amount),0) FROM booking WHERE COALESCE(is_void,0)=0").fetchone()[0]
tx_in = cur.execute("SELECT COALESCE(SUM(amount),0) FROM account_transaction WHERE to_account_id=? AND COALESCE(is_void,0)=0", (ACC_ID,)).fetchone()[0]
tx_out = cur.execute("SELECT COALESCE(SUM(amount),0) FROM account_transaction WHERE from_account_id=? AND COALESCE(is_void,0)=0", (ACC_ID,)).fetchone()[0]
print()
print(f'sales total (10k x 130)      = {sales_sum:,.2f}  (expect 1,300,000.00)')
print(f'sales paid                   = {sale_paid:,.2f}  (expect 1,300,000.00)')
print(f'client payments              = {pay_sum:,.2f}  (expect 5,000,000.00)')
print(f'supplier payments            = {sup_sum:,.2f}  (expect 5,000,000.00)')
print(f'loans received               = {loan_sum:,.2f}  (expect 2,000,000.00)')
print(f'expenses out                 = {exp_sum:,.2f}  (expect 500,000.00)')
print(f'GRN material value           = {grn_value:,.2f}  (expect 10,000,000.00)')
print(f'booking value                = {booking_value:,.2f}  (expect 2,600,000.00)')
print(f'stock IN qty (10k x 10)      = {in_stock:,.1f}  (expect 100,000.0)')
print(f'stock OUT qty (10k x 1)      = {out_stock:,.1f}  (expect 10,000.0)')
print(f'stock on hand                = {in_stock - out_stock:,.1f}  (expect 90,000.0)')
print(f'ledger IN  / OUT             = {tx_in:,.2f} / {tx_out:,.2f}')
print(f'implied balance (1,000,000 + IN - OUT) = {1000000 + tx_in - tx_out:,.2f}  (expect 3,800,000.00)')
con.close()

with app.app_context():
    from app.services.payments_crud import ledger_balance
    lb = ledger_balance(ACC_ID)
    print(f'ledger_balance()             = {lb:,.2f}  (expect 3,800,000.00)  {"OK" if abs(lb - 3800000) < 0.01 else "MISMATCH"}')

# ---------- report pages render + response time ----------
client = app.test_client()
client.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})
paths = [
    '/', '/stock_summary', '/profit_reports', '/cash_flow',
    '/clients', '/direct_sales', '/bookings', '/grn',
    '/accounts/', '/accounts/dashboard',
]
print('\nreport/page checks:')
for p in paths:
    t = time.time()
    try:
        r = client.get(p)
        print(f'  GET {p:<28} -> {r.status_code}  {(time.time()-t)*1000:,.0f} ms')
    except Exception as exc:
        print(f'  GET {p:<28} -> ERROR {exc}')

"""AMS deep verification: GRN FIFO costing, booking-allocation pricing,
negative stock, concurrency. HTTP-driven against a fresh deep database."""
import os, sys, re, threading, time, sqlite3, atexit, shutil, tempfile
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH_DIR = tempfile.mkdtemp(prefix='ams_test_')
os.environ['APP_DB_PATH'] = os.path.join(SCRATCH_DIR, 'ams_tests.db')
os.environ['DB_HEALTH_SNAPSHOT_PATH'] = os.path.join(SCRATCH_DIR, 'health_snapshot.json')
os.environ['AMS_ENABLE_BACKGROUND_WORKERS'] = ''
atexit.register(shutil.rmtree, SCRATCH_DIR, True)
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)

from app import create_app
app = create_app()
app.config['TESTING'] = True
C = app.test_client()
C.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})

passed, failed = 0, 0
def check(label, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print(f'[PASS] {label}')
    else: failed += 1; print(f'[FAIL] {label}  {detail}')

def dbq(mode, query, params=()):
    con = sqlite3.connect(f'file:{os.environ["APP_DB_PATH"]}?mode=ro', uri=True)
    try:
        return con.execute(query, params).fetchall()
    finally:
        con.close()

def post(client, url, data, label):
    r = client.post(url, data=data, follow_redirects=True)
    body = r.get_data(as_text=True)
    flash = re.findall(r'<div[^>]*alert[^>]*>(.*?)</div>', body, re.S)
    flash_text = ' | '.join(re.sub(r'<[^>]+>', ' ', m).strip()[:220] for m in flash[:2])
    print(f'    {label}: HTTP {r.status_code} {flash_text[:200]}')
    return r, flash_text

# ---------------- masters ----------------
post(C, '/add_material', {'material_name': 'FIFO Cement', 'material_code': 'FIFOCEM', 'material_unit': 'Bags', 'unit_price': '100'}, 'material fixture')
post(C, '/add_material', {'material_name': 'Book Cement', 'material_code': 'BOOKCEM', 'material_unit': 'Bags', 'unit_price': '1300'}, 'material booking')
post(C, '/add_material', {'material_name': 'Neg Steel', 'material_code': 'NEGSTEEL', 'material_unit': 'Kg', 'unit_price': '500'}, 'material steel')
post(C, '/add_material', {'material_name': 'Conc Cement', 'material_code': 'CONCCEM', 'material_unit': 'Bags', 'unit_price': '1100'}, 'material conc')
post(C, '/add_supplier', {'name': 'Deep Supplier', 'opening_balance': '0'}, 'supplier')
post(C, '/add_client', {'name': 'Deep Client', 'category': 'General'}, 'client')
post(C, '/accounts/accounts/add', {
    'name': 'Deep Cash', 'class_category': 'Assets', 'class_subcategory': 'Cash',
    'class_account_type': 'Main Cash', 'channel': 'cash',
    'opening_amount': '10000000', 'opening_position': 'debit'}, 'account')
with app.app_context():
    from models import Client, Account, Material
    client_obj = Client.query.filter_by(name='Deep Client').first()
    ACC_ID = Account.query.filter_by(name='Deep Cash').first().id
    CLIENT_CODE = client_obj.code
    print('    client code:', CLIENT_CODE, 'account id:', ACC_ID)

def grn(client, mat, qty, price, date, label):
    r, _ = post(client, '/grn', {
        'action': 'add', 'supplier': 'Deep Supplier',
        'mat_name[]': [mat], 'qty[]': [str(qty)], 'price[]': [str(price)],
        'date': date, 'note': label}, f'GRN {label}')
    return r

print()
print('=== TEST 1: GRN FIFO costing ===')
grn(C, 'FIFO Cement', 100, 100, '2026-01-05', 'GRN-A 100@100')
grn(C, 'FIFO Cement', 100, 120, '2026-02-05', 'GRN-B 100@120')
grn(C, 'FIFO Cement', 100, 150, '2026-03-05', 'GRN-C 100@150')

grn_items = {r[2]: r[0] for r in dbq(None, "SELECT id, qty, mat_name, price_at_time FROM grn_item")}
print('    grn_items:', dbq(None, 'select id, mat_name, qty, price_at_time from grn_item order by id'))

# sale A: 150 @ 200
r, _ = post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['FIFO Cement'], 'qty[]': ['150'], 'unit_rate[]': ['200'],
    'paid_amount': '30000', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-01'}, 'sale A (150 @ 200)')
saleA = dbq(None, "select id from direct_sale where note is null or 1=1 order by id")[-1][0]
saleA = dbq(None, "select max(id) from direct_sale")[0][0]
allocA = dbq(None, """select ga.grn_item_id, ga.qty, ga.cost_rate from grn_allocation ga
                       where ga.sale_id = ? order by ga.grn_item_id""", (saleA,))
itemsA = dbq(None, "select product_name, qty, price_at_time, cost_rate_at_sale from direct_sale_item where sale_id = ? order by id", (saleA,))
print('    sale A id:', saleA, 'allocations:', allocA)
print('    sale A items:', itemsA)

# independent FIFO re-derivation from raw tables
def fifo_expected(mat_key_qty):
    rows = dbq(None, """select gi.id, gi.qty, gi.price_at_time from grn_item gi
                        join grn g on g.id = gi.grn_id
                        where lower(trim(gi.mat_name)) = 'fifo cement' and coalesce(gi.is_void,0)=0
                        order by g.date_posted asc, g.id asc, gi.id asc""")
    consumed = {r[0]: 0.0 for r in rows}
    for r in dbq(None, "select grn_item_id, sum(qty) from grn_allocation where coalesce(is_void,0)=0 group by grn_item_id"):
        consumed[r[0]] = r[1]
    lots = []
    for (gid, qty, rate) in rows:
        avail = qty - consumed.get(gid, 0.0)
        if avail > 0:
            lots.append([gid, avail, rate])
    plan = []
    remaining = mat_key_qty
    for lot in lots:
        take = min(lot[1], remaining)
        if take <= 0: continue
        plan.append((lot[0], take, lot[2]))
        remaining -= take
        if remaining <= 0: break
    return plan

# pre-sale state: GRN-A/B/C all had 100 open -> FIFO plan for 150 = A:100 + B:50
gidA1, gidB1, gidC1 = [r[0] for r in dbq(None, 'select id from grn_item order by id')][:3]
check('FIFO sale A: allocated from GRN-A(100) + GRN-B(50)',
      sorted([(int(a[0]), a[1], a[2]) for a in allocA]) == sorted([(gidA1, 100.0, 100.0), (gidB1, 50.0, 120.0)]),
      f'alloc={allocA}')
check('FIFO sale A: direct_sale_item cost rates frozen per lot (100/120)',
      sorted(i[3] for i in itemsA) == sorted([100.0, 120.0]),
      f'items={itemsA}')

# sale B: 120 @ 210 -> expect 50 from GRN-B @120, 70 from GRN-C @150
post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['FIFO Cement'], 'qty[]': ['120'], 'unit_rate[]': ['210'],
    'paid_amount': '25200', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-02'}, 'sale B (120 @ 210)')
saleB = dbq(None, "select max(id) from direct_sale")[0][0]
allocB = dbq(None, "select grn_item_id, qty, cost_rate from grn_allocation where sale_id = ? order by grn_item_id", (saleB,))
print('    sale B allocations:', allocB)
gidA, gidB, gidC = [r[0] for r in dbq(None, 'select id from grn_item order by id')][:3]
check('FIFO sale B: 50 @120 from GRN-B + 70 @150 from GRN-C',
      sorted([(int(a[0]), a[1], a[2]) for a in allocB]) == sorted([(gidB, 50.0, 120.0), (gidC, 70.0, 150.0)]),
      f'allocB={allocB} gidB={gidB} gidC={gidC}')

# cumulative consumption
cum = {r[0]: r[1] for r in dbq(None, "select grn_item_id, sum(qty) from grn_allocation where coalesce(is_void,0)=0 group by grn_item_id")}
check('FIFO cumulative consumption: GRN-A=100, GRN-B=100, GRN-C=70',
      cum.get(gidA) == 100.0 and cum.get(gidB) == 100.0 and cum.get(gidC) == 70.0, f'cum={cum}')

# void sale A -> allocations freed
r, _ = post(C, f'/void_transaction/DirectSale/{saleA}', {'reason': 'fifo test'}, f'hard-delete sale A ({saleA})')
allocA_after = dbq(None, "select count(*) from grn_allocation where sale_id = ?", (saleA,))[0][0]
saleA_after = dbq(None, "select count(*) from direct_sale where id = ?", (saleA,))[0][0]
cum2 = {r[0]: r[1] for r in dbq(None, "select grn_item_id, sum(qty) from grn_allocation where coalesce(is_void,0)=0 group by grn_item_id")}
print('    after void A: allocations left:', allocA_after, 'sale rows:', saleA_after, 'cum consumption:', cum2)
check('void sale A removes its GRN allocations and the sale row', allocA_after == 0 and saleA_after == 0)
check('FIFO consumption freed correctly (GRN-A=0, GRN-B=50, GRN-C=70)',
      cum2.get(gidA) in (None, 0.0) and cum2.get(gidB) == 50.0 and cum2.get(gidC) == 70.0, f'cum2={cum2}')

mat_total = dbq(None, "select total from material where name='FIFO Cement'")[0][0]
print('    Material.total FIFO Cement after sale A void:', mat_total, '(GRN 300 - OUT 120 = 180 expected)')
check('Material.total reflects net stock (180)', abs((mat_total or 0) - 180.0) < 0.01, f'total={mat_total}')

print()
print('=== TEST 2: booking allocation pricing ===')
post(C, '/add_booking', {'client_code': CLIENT_CODE, 'material_name[]': ['Book Cement'],
                         'qty[]': ['10'], 'unit_rate[]': ['1300'], 'paid_amount': '0',
                         'date': '2026-01-10'}, 'booking 1: 10 @ 1300')
post(C, '/add_booking', {'client_code': CLIENT_CODE, 'material_name[]': ['Book Cement'],
                         'qty[]': ['10'], 'unit_rate[]': ['1500'], 'paid_amount': '0',
                         'date': '2026-02-10'}, 'booking 2: 10 @ 1500')
bk_items = dbq(None, """select bi.id, b.auto_bill_no, bi.qty, bi.price_at_time
                        from booking_item bi join booking b on b.id = bi.booking_id order by bi.id""")
print('    booking items:', bk_items)
bi1, bi2 = bk_items[0][0], bk_items[1][0]

post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Book Cement'], 'qty[]': ['15'], 'unit_rate[]': ['2000'],
    'paid_amount': '0', 'category': 'Booking Delivery', 'sale_date': '2026-03-01'},
    'Booking Delivery 15 bags')
bok1 = dbq(None, "select booking_item_id, qty from booking_allocation order by booking_item_id, id")
print('    allocations after delivery of 15:', bok1)
check('booking FIFO: 10 from booking 1 + 5 from booking 2',
      bok1 == [(bi1, 10.0), (bi2, 5.0)], f'alloc={bok1} bi1={bi1} bi2={bi2}')

# booking delivery sale should carry amount = 0
bd = dbq(None, "select amount, paid_amount, category from direct_sale order by id desc limit 1")[0]
print('    booking delivery sale row:', bd)
check('Booking Delivery sale carries amount 0 (fulfilment only)', bd[0] == 0 and bd[1] == 0)

post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Book Cement'], 'qty[]': ['5'], 'unit_rate[]': ['2000'],
    'paid_amount': '0', 'category': 'Booking Delivery', 'sale_date': '2026-03-02'},
    'Booking Delivery 5 bags (exhaust pool)')
bok2 = dbq(None, "select booking_item_id, sum(qty) from booking_allocation group by booking_item_id order by booking_item_id")
print('    allocations after delivery of 20 total:', bok2)
check('booking pool now fully consumed (bi1=10, bi2=10)',
      bok2 == [(bi1, 10.0), (bi2, 10.0)], f'alloc={bok2}')

before = dbq(None, "select count(*) from direct_sale")[0][0]
post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Book Cement'], 'qty[]': ['1'], 'unit_rate[]': ['2000'],
    'paid_amount': '0', 'category': 'Booking Delivery', 'sale_date': '2026-03-03'},
    'Booking Delivery 1 more (expect rejection)')
after = dbq(None, "select count(*) from direct_sale")[0][0]
check('booking over-delivery rejected (no sale created)', after == before, f'before={before} after={after}')

# booking pool recompute independently
booked = dbq(None, "select sum(qty) from booking_item")[0][0]
delivered = dbq(None, "select coalesce(sum(qty),0) from booking_allocation")[0][0]
print(f'    booking pool: booked={booked} delivered={delivered} remaining={booked-delivered}')
check('independent pool recompute matches (20 booked - 20 delivered = 0)', booked - delivered == 0)

print()
print('=== TEST 3: negative stock ===')
r, flash = post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Neg Steel'], 'qty[]': ['1'], 'unit_rate[]': ['600'],
    'paid_amount': '600', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-03'}, 'sale of 1kg steel, zero stock')
check('sale rejected with zero stock', 'Insufficient stock' in flash, f'flash={flash}')

grn(C, 'Neg Steel', 20, 500, '2026-01-20', 'GRN NegSteel 20')
mat = dbq(None, "select total from material where name='Neg Steel'")[0][0]
print('    Material.total after GRN 20:', mat)
check('GRN 20 posted -> Material.total = 20', abs((mat or 0) - 20.0) < 0.01, f'total={mat}')

before = dbq(None, "select count(*) from direct_sale where client_name='Deep Client' and note is null")[0][0]
r, flash = post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Neg Steel'], 'qty[]': ['25'], 'unit_rate[]': ['600'],
    'paid_amount': '15000', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-04'}, 'sale of 25 (>20), no flag')
after = dbq(None, "select count(*) from direct_sale")[0][0]
check('oversell rejected without negative-stock flag', 'Insufficient stock' in flash, f'flash={flash}')

r, flash = post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Neg Steel'], 'qty[]': ['25'], 'unit_rate[]': ['600'],
    'paid_amount': '15000', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-04', 'allow_negative_stock': '1'}, 'sale of 25 with allow_negative_stock')
mat = dbq(None, "select total from material where name='Neg Steel'")[0][0]
print('    Material.total after flagged oversell:', mat)
check('oversell allowed with flag; stock = -5', abs((mat or 0) - (-5.0)) < 0.01, f'total={mat}')

with app.app_context():
    from models import Settings, db as _db
    s = Settings.query.first()
    if s is None:
        s = Settings()
        _db.session.add(s)
    s.allow_global_negative_stock = True
    _db.session.commit()
r, flash = post(C, '/add_direct_sale', {
    'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
    'product_name[]': ['Neg Steel'], 'qty[]': ['10'], 'unit_rate[]': ['600'],
    'paid_amount': '6000', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-04-05'}, 'sale of 10 with global negative-stock on')
with app.app_context():
    from models import Settings, db as _db
    s = Settings.query.first()
    s.allow_global_negative_stock = False
    _db.session.commit()
mat = dbq(None, "select total from material where name='Neg Steel'")[0][0]
print('    Material.total after global-flag sale:', mat)
check('oversell allowed with global setting; stock = -15', abs((mat or 0) - (-15.0)) < 0.01, f'total={mat}')

print()
print('=== TEST 4: concurrency (8 threads x 10 cash sales + 4 threads x 10 payments) ===')
grn(C, 'Conc Cement', 10000, 100, '2026-01-25', 'GRN ConcCem 10000')
print('    Material.total Conc Cement:', dbq(None, "select total from material where name='Conc Cement'")[0][0])
bal_before = dbq(None, "select balance from account where id=?", (ACC_ID,))[0][0]
sales0 = dbq(None, "select count(*) from direct_sale")[0][0]

def worker_sale(wid, results):
    try:
        c = app.test_client()
        c.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})
        ok = 0
        for i in range(10):
            r = c.post('/add_direct_sale', data={
                'client_name': 'Deep Client', 'driver_name': 'Deep Driver',
                'product_name[]': ['Conc Cement'], 'qty[]': ['1'], 'unit_rate[]': ['130'],
                'paid_amount': '130', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
                'category': 'Cash', 'sale_date': '2026-04-06'})
            if r.status_code in (200, 302):
                ok += 1
            else:
                results.append(('sale', wid, i, r.status_code))
        results.append(('sale_done', wid, ok, None))
    except Exception as exc:
        results.append(('sale_error', wid, str(exc), None))

def worker_pay(wid, results):
    try:
        c = app.test_client()
        c.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})
        ok = 0
        for i in range(10):
            r = c.post('/accounts/payments/clients/save', data={
                'client_code': CLIENT_CODE, 'client_name': 'Deep Client',
                'amount': '10', 'payment_type': 'Receipt', 'method': 'Cash',
                'payment_account_id': str(ACC_ID), 'date': '2026-04-06'}, follow_redirects=True)
            body = r.get_data(as_text=True)
            if 'Payment saved successfully' in body:
                ok += 1
            else:
                m = None
                import re as _re
                mm = _re.search(r'Unable to save payment: ([^<]{0,120})', body)
                if mm:
                    m = mm.group(1).strip()
                else:
                    mm2 = _re.search(r'class="[^"]*alert[^"]*"[^>]*>(.*?)</div>', body, _re.S)
                    m = _re.sub(r'<[^>]+>', ' ', mm2.group(1)).strip()[:120] if mm2 else 'UNRECOGNISED FLASH'
                results.append(('pay_rejected', wid, i, m))
        results.append(('pay_done', wid, ok, None))
    except Exception as exc:
        results.append(('pay_error', wid, str(exc), None))

results = []
threads = []
for w in range(4):
    threads.append(threading.Thread(target=worker_sale, args=(w, results)))
for w in range(4, 8):
    threads.append(threading.Thread(target=worker_sale, args=(w, results)))
for w in range(4):
    threads.append(threading.Thread(target=worker_pay, args=(w, results)))
t0 = time.time()
for t in threads: t.start()
for t in threads: t.join()
dt = time.time() - t0
errors = [r for r in results if r[0] not in ('sale_done', 'pay_done')]
rejects = [r for r in results if r[0] == 'pay_rejected']
done_sales = sum(r[2] for r in results if r[0] == 'sale_done')
done_pays = sum(r[2] for r in results if r[0] == 'pay_done')
print(f'    12 threads finished in {dt:.1f}s; sales ok={done_sales}/80 payments saved={done_pays}/40 rejected_with_flash={len(rejects)}')
for rej in rejects[:6]:
    print('      rejected:', rej[3])

sales_after = dbq(None, "select count(*) from direct_sale")[0][0]
bal_after = dbq(None, "select balance from account where id=?", (ACC_ID,))[0][0]
mat_conc = dbq(None, "select total from material where name='Conc Cement'")[0][0]
pays_saved, pays_sum = dbq(None, "select count(*), coalesce(sum(amount),0) from payment where date_posted like '2026-04-06%'")[0]
print(f'    sales before={sales0} after={sales_after}')
print(f'    concurrent client payments actually saved: {pays_saved}/40 amount={pays_sum}')
print(f'    cash account: before={bal_before} after={bal_after} delta={bal_after-bal_before} (expect 80*130 + {pays_saved}*10 = {80*130 + pays_saved*10})')
print(f'    Conc Cement stock after: {mat_conc} (expect 10000 - 80 = 9920)')
hard_errors = [r for r in errors if r[0] != 'pay_rejected']
check('no concurrency errors/exceptions raised in workers', not hard_errors, f'errors={hard_errors}')
check('exactly 80 concurrent sales recorded', sales_after - sales0 == 80)
check('account balance delta internally consistent (80 sales + saved payments only)',
      abs((bal_after - bal_before) - (80*130 + pays_sum)) < 0.01,
      f'delta={bal_after-bal_before} expected={80*130+pays_sum}')
check('stock decremented exactly 80 (no lost updates)', abs((mat_conc or 0) - 9920.0) < 0.01, f'total={mat_conc}')

alloc_tot = dbq(None, """select coalesce(sum(ga.qty),0) from grn_allocation ga
                          join direct_sale s on s.id = ga.sale_id
                          where s.payment_account_id = ? and s.date_posted like '2026-04-06%'""", (ACC_ID,))[0][0]
print(f'    GRN allocated to the 80 concurrent sales: {alloc_tot} (expect 80)')
check('FIFO allocated exactly 80 units for concurrent sales', alloc_tot == 80.0, f'allocated={alloc_tot}')

print()
print(f'DEEP VERIFICATION RESULT: {passed} passed, {failed} failed')
sys.exit(1 if failed else 0)

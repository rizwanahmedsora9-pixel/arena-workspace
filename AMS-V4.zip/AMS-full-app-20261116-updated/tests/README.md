# tests/ — AMS self-check suites

These scripts re-check the app end to end, the way the original audit did.
They are plain Python (no pytest fixtures needed) and exit non-zero on any
failure, so they work both interactively and in CI.

## Quick start

From the **repository root** (the folder that contains `main.py`):

```bash
pip install -r requirements.txt
python tests/run_all.py            # fast suites (~1 minute)
python tests/run_all.py --scale    # additionally the 10k-row durability test (several minutes)
```

Or run the individual suites directly:

```bash
python tests/e2e_smoke.py          # log in, masters -> GRN -> booking -> cash/credit sales ->
                                   # client/supplier payments -> loan -> expense; cross-check pages
python tests/delete_semantics.py   # immediate delete: money+stock reversed at once, Restore gone,
                                   # supplier/client delete guards intact, health guard stays calm
python tests/deep_verification.py  # GRN FIFO costing, booking-allocation pricing, negative-stock
                                   # gates, 8 threads x 10 concurrent sales + concurrent receipts
python tests/scale_seed.py         # OPTIONAL heavy test: seeds 10,000 of each record type
python tests/scale_verify.py       # restart against the seeded DB and prove nothing auto-deletes
```

## Expected results (as of 2026-11-16)

| Suite | Expected |
|---|---|
| `e2e_smoke.py` | `RESULT: 12 passed, 0 failed` |
| `delete_semantics.py` | `RESULT: 25 passed, 0 failed` |
| `deep_verification.py` | `DEEP VERIFICATION RESULT: 22 passed, 0 failed` |
| `scale_verify.py` | `DATA SURVIVED RESTART: YES` (row counts identical; totals exact) |

## Safety — what these tests touch

- Every suite creates its **own throwaway SQLite database** in a temp directory
  (`APP_DB_PATH`/`DB_HEALTH_SNAPSHOT_PATH` pointed there) and **never touches
  `instance/`** — your real app data is safe to run these against.
- The temp databases are deleted automatically when the suite finishes.
- The exception is the optional scale test, which keeps its files under
  `tests/.scratch/` (git-ignored, ~2 GB sparse / large file — delete that
  folder any time; `scale_verify.py` re-creates instructions to re-seed).
- Fresh throwaway DBs auto-create the built-in `Admin` account with the
  built-in default password used by the installer
  (`Admin@fbm12345`). This is the throwaway password for test databases only.

## What each suite covers

### e2e_smoke.py — the business chain
material/supplier/client/cash-account masters → GRN → booking → cash sale →
credit sale → client payment → supplier payment → loan received → expense via
cash flow — then cross-checks counts and that key report pages render.

### delete_semantics.py — immediate delete (2026-11-16 policy)
GRN delete reverses stock to zero and removes rows for real; a GRN with
Accounts payments refuses deletion until those are deleted; a cash sale delete
restores stock and the exact account balance; a client receipt delete reverses
cash exactly; the old Restore/unvoid endpoints return 404/405; a legacy voided
row survives a restart untouched; deleting 60 pending bills re-baselines the
boot health snapshot so the next start does **not** refuse to boot; a
supplier with GRNs/payments cannot be hard-deleted (fresh one can); a client
delete suspends instead of deleting.

### deep_verification.py — the math
GRN FIFO cost allocation with frozen lot prices (independently re-derived);
booking FIFO allocation and pool exhaustion; oversell rejected without the
negative-stock flag, allowed with it (stock goes negative as posted);
80/80 concurrent sales persist with exact stock and exact FIFO allocation;
concurrent client receipts against the *same* cash account under load —
internally consistent totals, but see the known limitation below.

### scale_seed.py + scale_verify.py — does the app survive its own size?
Seeds 10,000 records per major section (GRNs, bookings, cash sales, client
payments, supplier payments, loan movements, expenses + matching ledger
transactions), restarts the app against that database, and proves: no row is
auto-deleted at boot, every total still matches independent SQL math
(10,000 × 130 sales = 1,300,000.00, stock 100,000 in − 10,000 out = 90,000,
account balance 3,800,000.00, etc.), and the report pages render.

## Known limitation you will see here

`deep_verification.py` (TEST 4) shows **concurrent client payments to the same
account lose ~50–70% of the posts** to `StaleDataError` (the `Account`
mapper uses `version_id_col`), roll back cleanly, and return HTTP 200 with an
error flash. The database stays internally consistent — but money records can
be lost at the till. The fix (BEGIN IMMEDIATE like the sale route, or atomic
increment/retry) is documented in `AMS-AUDIT-REPORT.md` §7.4/§7.5 and was
deliberately not applied yet.

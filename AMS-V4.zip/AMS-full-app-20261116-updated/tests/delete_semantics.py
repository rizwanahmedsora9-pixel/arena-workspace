"""Round 3 verification: immediate delete (money+stock reversed at once),
no Restore anywhere, boot does not purge, health guard not tripped by
legitimate big deletes, master-data delete guard kept.

HTTP-driven against a fresh scratch DB (auto-wiped on each run)."""
import os, sys, re, sqlite3, atexit, shutil, tempfile
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH_DIR = tempfile.mkdtemp(prefix='ams_test_')
os.environ['APP_DB_PATH'] = os.path.join(SCRATCH_DIR, 'ams_tests.db')
os.environ['DB_HEALTH_SNAPSHOT_PATH'] = os.path.join(SCRATCH_DIR, 'health_snapshot.json')
os.environ['AMS_ENABLE_BACKGROUND_WORKERS'] = ''
atexit.register(shutil.rmtree, SCRATCH_DIR, True)
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)

from app import create_app
app = create_app()
app.config['TESTING'] = True
C = app.test_client()
C.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})

passed, failed = 0, 0
def check(label, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print(f'[PASS] {label}')
    else: failed += 1; print(f'[FAIL] {label}  {detail}')

def dbq(query, params=()):
    con = sqlite3.connect(f'file:{os.environ["APP_DB_PATH"]}?mode=ro', uri=True)
    try:
        return con.execute(query, params).fetchall()
    finally:
        con.close()

def post(client, url, data, label, method='post'):
    r = getattr(client, method)(url, data=data, follow_redirects=True)
    body = r.get_data(as_text=True)
    flash = re.findall(r'<div[^>]*alert[^>]*>(.*?)</div>', body, re.S)
    flash_text = ' | '.join(re.sub(r'<[^>]+>', ' ', m).strip()[:200] for m in flash[:2])
    print(f'    {label}: HTTP {r.status_code} {flash_text[:180]}')
    return r, flash_text

print('=== fixtures ===')
post(C, '/add_material', {'material_name': 'Del Cement', 'material_code': 'DELCEM', 'material_unit': 'Bags', 'unit_price': '100'}, 'material')
post(C, '/add_supplier', {'name': 'Del Supplier', 'opening_balance': '0'}, 'supplier')
post(C, '/add_client', {'name': 'Del Client', 'category': 'General'}, 'client')
post(C, '/accounts/accounts/add', {
    'name': 'Del Cash', 'class_category': 'Assets', 'class_subcategory': 'Cash',
    'class_account_type': 'Main Cash', 'channel': 'cash',
    'opening_amount': '100000', 'opening_position': 'debit'}, 'account')
with app.app_context():
    from models import Client, Account, Material, DirectSale
    CLIENT_CODE = Client.query.filter_by(name='Del Client').first().code
    ACC_ID = Account.query.filter_by(name='Del Cash').first().id
    MAT_ID = Material.query.filter_by(name='Del Cement').first().id

opening_balance = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
print('    opening cash balance:', opening_balance)

print()
print('=== 1. GRN added, then deleted: money+stock reversed at once, row gone ===')
post(C, '/grn', {'action': 'add', 'supplier': 'Del Supplier',
                 'mat_name[]': ['Del Cement'], 'qty[]': ['50'], 'price[]': ['100'],
                 'date': '2026-05-01', 'note': 'del-test'}, 'GRN add')
stock = dbq('select total from material where name=?', ('Del Cement',))[0][0]
grn_id = dbq('select max(id) from grn')[0][0]
entries = dbq("select count(*) from entry where type='IN' and auto_bill_no in (select auto_bill_no from grn where id=?)", (grn_id,))[0][0]
print(f'    stock after GRN: {stock} (expect 50), grn id={grn_id}, IN entries={entries}')
check('GRN posted stock +50', abs(stock - 50) < 0.001 and entries > 0)
r, txt = post(C, '/grn', {'action': 'delete', 'id': str(grn_id)}, 'GRN delete')
stock = dbq('select total from material where name=?', ('Del Cement',))[0][0]
grn_gone = dbq('select count(*) from grn where id=?', (grn_id,))[0][0] == 0
entries_gone = dbq("select count(*) from entry where type='IN' and auto_bill_no in (select auto_bill_no from grn where id=?)", (grn_id,))[0][0] == 0
items_gone = dbq('select count(*) from grn_item where grn_id=?', (grn_id,))[0][0] == 0
print(f'    stock after GRN delete: {stock} (expect 0), grn gone={grn_gone}, IN entries gone={entries_gone}, items gone={items_gone}')
check('GRN deleted immediately; stock reversed to 0', abs(stock) < 0.001)
check('GRN row + items + entries removed', grn_gone and items_gone and entries_gone)

print()
print('=== 2. Fresh GRN + linked Accounts payment -> GRN delete REFUSED ===')
post(C, '/grn', {'action': 'add', 'supplier': 'Del Supplier',
                 'mat_name[]': ['Del Cement'], 'qty[]': ['20'], 'price[]': ['100'],
                 'date': '2026-05-02', 'note': 'del-test-2'}, 'GRN add 2')
grn2 = dbq('select max(id) from grn')[0][0]
with app.app_context():
    from models import db, SupplierPayment, GRN, Supplier
    g = db.session.get(GRN, grn2)
    sup = Supplier.query.filter_by(name='Del Supplier').first()
    p = SupplierPayment(supplier_id=sup.id, account_name='Del Supplier', amount=100.0,
                        amount_minor=10000, payment_account_id=ACC_ID, source_type='GRN_PAYMENT',
                        grn_id=grn2, payment_kind='GRN_MATERIAL',
                        date_posted=g.date_posted)
    db.session.add(p); db.session.commit()
check('linked GRN payment seeded', dbq('select count(*) from supplier_payment where grn_id=?', (grn2,))[0][0] == 1)
r, txt = post(C, '/grn', {'action': 'delete', 'id': str(grn2)}, 'GRN delete with payment')
still = dbq('select count(*) from grn where id=?', (grn2,))[0][0] == 1
print(f'    grn still present: {still} (expect True)')
check('GRN with Accounts payments cannot be deleted (money trail kept)', still)

print()
print('=== 3. Cash sale then delete: sale gone, stock restored, money reversed ===')
post(C, '/add_direct_sale', {
    'client_name': 'Del Client', 'driver_name': 'Del Driver',
    'product_name[]': ['Del Cement'], 'qty[]': ['10'], 'unit_rate[]': ['130'],
    'paid_amount': '1300', 'payment_method': 'Cash', 'payment_account_id': str(ACC_ID),
    'category': 'Cash', 'sale_date': '2026-05-03'}, 'cash sale')
bal_after_sale = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
stock_after_sale = dbq('select total from material where name=?', ('Del Cement',))[0][0]
sale_id = dbq('select max(id) from direct_sale')[0][0]
print(f'    balance after sale: {bal_after_sale}, stock: {stock_after_sale}, sale id: {sale_id}')
check('sale posted (money in, stock out)', abs(bal_after_sale - (opening_balance + 1300)) < 0.01)
r, txt = post(C, f'/delete_transaction/DirectSale/{sale_id}', {}, 'sale delete')
bal_after_del = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
stock_after_del = dbq('select total from material where name=?', ('Del Cement',))[0][0]
sale_gone = dbq('select count(*) from direct_sale where id=?', (sale_id,))[0][0] == 0
txs_gone = dbq("select count(*) from account_transaction where note like ? and (is_void is null or is_void = 0)", (f'%[SRC:DirectSale:{sale_id}]%',))[0][0] == 0
print(f'    balance after delete: {bal_after_del}, stock: {stock_after_del}, sale gone={sale_gone}, live txs gone={txs_gone}')
check('sale deleted immediately; money reversed to opening', abs(bal_after_del - opening_balance) < 0.01)
check('sale rows + ledger txs removed', sale_gone and txs_gone)

print()
print('=== 4. Client receipt then delete: receipt gone, cash reversed exactly ===')
open_bal = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
post(C, '/accounts/payments/clients/save', {
    'client_code': CLIENT_CODE, 'client_name': 'Del Client',
    'amount': '500', 'payment_type': 'Receipt', 'method': 'Cash',
    'payment_account_id': str(ACC_ID), 'date': '2026-05-04'}, 'client receipt')
bal_after_pay = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
pay_id = dbq("select max(id) from payment where payment_type='Receipt'")[0][0]
print(f'    balance after receipt: {bal_after_pay} (expect +500), payment id: {pay_id}')
check('receipt posted (+500)', abs(bal_after_pay - (open_bal + 500)) < 0.01)
r, txt = post(C, f'/accounts/payments/clients/void/{pay_id}', {}, 'receipt delete')
bal_after_del = dbq('select balance from account where id=?', (ACC_ID,))[0][0]
pay_gone = dbq('select count(*) from payment where id=?', (pay_id,))[0][0] == 0
txs_gone = dbq("select count(*) from account_transaction where note like ?", (f'%[SRC:Payment:{pay_id}]%',))[0][0] == 0
print(f'    balance after delete: {bal_after_del} (expect {open_bal}), payment gone={pay_gone}, txs gone={txs_gone}')
check('receipt deleted immediately; cash reversed exactly', abs(bal_after_del - open_bal) < 0.01)
check('payment row + ledger txs removed', pay_gone and txs_gone)

print()
print('=== 5. Restore is gone (endpoints and buttons) ===')
for url in ('/unvoid_transaction/Payment/1',
            '/void_audit/restore/Payment/1',
            '/accounts/payments/clients/restore/1',
            '/payments/suppliers/1/restore',
            '/grn_payments/1/restore',
            '/delivery_person_payments/1/restore',
            '/inventory/lost_ledger/restore/1',
            '/restore_supplier_payment/1'):
    r = C.post(url, data={})
    check(f'POST {url} -> 404/405 (no restore)', r.status_code in (404, 405), f'got {r.status_code}')

print()
print('=== 6. Legacy voided rows survive boot, inert; no boot purge ===')
# craft a synthetic legacy voided row directly
with app.app_context():
    from models import db, Payment, Client
    cli = Client.query.filter_by(name='Del Client').first()
    legacy = Payment(client_id=cli.id, client_name='Del Client', amount=999.0,
                     amount_minor=99900, payment_type='Receipt', method='Cash',
                     payment_account_id=ACC_ID, date_posted=__import__('datetime').datetime(2026, 5, 5),
                     is_void=True, note='legacy void row')
    db.session.add(legacy); db.session.commit()
    legacy_id = legacy.id
print(f'    seeded legacy voided payment id={legacy_id}')

# reboot the app; the boot path must NOT purge it
app2 = create_app()
app2.config['TESTING'] = True
C2 = app2.test_client()
C2.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'})
still_there = dbq('select count(*) from payment where id=? and is_void=1', (legacy_id,))[0][0] == 1
check('legacy voided row survives restart (no boot purge)', still_there)

print()
print('=== 7. Big legitimate deletes do not trip the health guard ===')
# seed 60 pending bills (tracked table), snapshot baseline, then delete them all
with app.app_context():
    from models import db, PendingBill
    from app.services import health as health_svc
    for i in range(60):
        db.session.add(PendingBill(client_name='Del Client', bill_no=f'DEL-LOAD-{i:04d}',
                                   amount=1.0, reason='load test'))
    db.session.commit()
    total_before = sum(health_svc._collect_health_counts().values())
    health_svc._rebuild_health_snapshot()
    # bill_no is rewritten by the bill normalizer, so track ids directly
    seeded_ids = [r[0] for r in db.session.query(PendingBill.id).order_by(PendingBill.id.desc()).limit(60).all()]
    print(f'    seeded pending bills to delete: {len(seeded_ids)}')
    from app.services.void_rebuild import hard_delete_pending_bill
    for pid in seeded_ids:
        pb = db.session.get(PendingBill, pid)
        if pb:
            hard_delete_pending_bill(pb)
    db.session.commit()
    total_after = sum(health_svc._collect_health_counts().values())
    print(f'    health counts: before={total_before} after={total_after} (dropped {total_before - total_after})')
    # after the commit, the after_commit hook must have re-baselined the snapshot
    snap = health_svc._read_health_snapshot() or {}
    snap_pb = (snap.get('counts') or {}).get('pending_bill', '?')
    print(f'    snapshot pending_bill after deletes: {snap_pb} (expected {total_after - 4 + snap_pb if False else "rebuilt"})')
    ok_rebaseline = snap.get('counts', {}).get('pending_bill', 1e9) <= total_after - 4 + 60 - 56  # re-baselined near current
    # the after_commit hook must have re-baselined the snapshot to current reality
    snap = health_svc._read_health_snapshot() or {}
    snap_pb = (snap.get('counts') or {}).get('pending_bill')
    _c = dbq("select count(*) from pending_bill")[0][0]
    print(f'    snapshot pending_bill after commit: {snap_pb} (current table count: {_c})')
    check('snapshot re-baselined on commit (pending_bill)', snap_pb == _c, f'snapshot={snap_pb} actual={_c}')

    # the real next-boot guard must now pass
    try:
        health_svc._db_health_check_after_bootstrap()
        print('    post-delete health check: OK (no false alarm)')
        boot_ok = True
    except RuntimeError as exc:
        boot_ok = False
        print('    post-delete health check RAISED:', exc)
    check('health guard passes after legitimate big delete (no false alarm)', boot_ok)

print()
print('=== 8. Supplier with data cannot be hard-deleted; fresh supplier can ===')
with app.app_context():
    from models import Supplier
    sup = Supplier.query.filter_by(name='Del Supplier').first()
    print(f'    supplier id: {sup.id} (has GRNs)')
r, txt = post(C, f'/hard_delete_supplier/{sup.id}', {}, 'hard delete supplier WITH data')
still = dbq('select count(*) from supplier where id=?', (sup.id,))[0][0] == 1
print(f'    supplier still present: {still} (expect True)')
check('supplier with GRNs/payments cannot be deleted', still)
post(C, '/add_supplier', {'name': 'Temp Supplier', 'opening_balance': '0'}, 'fresh supplier')
with app.app_context():
    from models import Supplier
    temp_id = Supplier.query.filter_by(name='Temp Supplier').first().id
r, txt = post(C, f'/hard_delete_supplier/{temp_id}', {}, 'hard delete fresh supplier')
gone = dbq('select count(*) from supplier where id=?', (temp_id,))[0][0] == 0
print(f'    fresh supplier deleted: {gone} (expect True)')
check('unreferenced supplier can be hard-deleted', gone)

print()
print('=== 9. Client cannot be deleted, only suspended (rule kept) ===')
with app.app_context():
    from models import Client
    cli = Client.query.filter_by(name='Del Client').first()
    cli_id = cli.id
r, txt = post(C, f'/delete_client/{cli_id}', {}, 'client delete attempt')
cli_ok = dbq('select is_active from client where id=?', (cli_id,))[0][0]
check('client delete suspends instead of deleting (history kept)', cli_ok == 0)

print()
print(f'RESULT: {passed} passed, {failed} failed')
sys.exit(1 if failed else 0)

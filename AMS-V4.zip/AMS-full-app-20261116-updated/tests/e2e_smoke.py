"""AMS end-to-end functional test — drives the real app via HTTP test client.

Exercises the full business chain:
  material/supplier/client/account masters -> GRN -> booking -> direct (cash) sale
  -> credit sale -> client payment -> supplier payment -> loan -> expense
and then cross-checks the database and key report pages.
"""
import os, sys, atexit, shutil, tempfile
from datetime import datetime
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH_DIR = tempfile.mkdtemp(prefix='ams_test_')
os.environ['APP_DB_PATH'] = os.path.join(SCRATCH_DIR, 'ams_tests.db')
os.environ['DB_HEALTH_SNAPSHOT_PATH'] = os.path.join(SCRATCH_DIR, 'health_snapshot.json')
os.environ['AMS_ENABLE_BACKGROUND_WORKERS'] = ''
os.environ['PUBLIC_BASE_URL'] = ''
atexit.register(shutil.rmtree, SCRATCH_DIR, True)
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)

from app import create_app

app = create_app()
app.config['TESTING'] = True
client = app.test_client()

OK, FAIL = [], []

def check(label, cond, detail=''):
    status = 'PASS' if cond else 'FAIL'
    (OK if cond else FAIL).append(label)
    print(f'[{status}] {label}' + (f'  -- {detail}' if detail and not cond else ''))

# ---------- login ----------
r = client.get('/login')
print('GET /login ->', r.status_code)
r = client.post('/login', data={'username': 'Admin', 'password': 'Admin@fbm12345'}, follow_redirects=False)
print('POST /login ->', r.status_code, r.headers.get('Location'))
check('login redirects (authenticated)', r.status_code in (302, 303))

with app.app_context():
    from models import db, Client, Account

# ---------- create material ----------
r = client.post('/add_material', data={
    'material_name': 'Cement OPC 50kg', 'material_code': 'CEM50TEST',
    'material_unit': 'Bags', 'unit_price': '1100',
}, follow_redirects=False)
print('add_material ->', r.status_code)

# ---------- create supplier ----------
r = client.post('/add_supplier', data={'name': 'E2E Supplier', 'phone': '03000000001', 'opening_balance': '0'}, follow_redirects=False)
print('add_supplier ->', r.status_code)

# ---------- create client ----------
r = client.post('/add_client', data={'name': 'E2E Client', 'phone': '03000000002', 'category': 'General'}, follow_redirects=False)
print('add_client ->', r.status_code)

with app.app_context():
    from models import Client, Supplier, Material
    cli = Client.query.filter_by(name='E2E Client').first()
    sup = Supplier.query.filter_by(name='E2E Supplier').first()
    mat = Material.query.filter_by(name='Cement OPC 50kg').first()
    print('client:', cli and (cli.id, cli.code, cli.name))
    print('supplier:', sup and (sup.id, sup.name))
    print('material:', mat and (mat.id, mat.name))
    check('client created', cli is not None)
    check('supplier created', sup is not None)
    check('material created', mat is not None)
    CLIENT_CODE = cli.code if cli else ''

# ---------- create cash account ----------
r = client.post('/accounts/accounts/add', data={
    'name': 'E2E Main Cash', 'class_category': 'Assets',
    'class_subcategory': 'Cash', 'class_account_type': 'Main Cash',
    'channel': 'cash', 'opening_amount': '100000', 'opening_position': 'debit',
}, follow_redirects=False)
print('accounts/add ->', r.status_code)
with app.app_context():
    acct = Account.query.filter_by(name='E2E Main Cash').first()
    print('account:', acct and (acct.id, acct.name, acct.balance))
    check('cash account created', acct is not None)
    ACCOUNT_ID = acct.id if acct else None

# ---------- GRN: receive 200 bags @ 1000 ----------
today = datetime.now().strftime('%Y-%m-%d')
r = client.post('/grn', data={
    'action': 'add', 'supplier': 'E2E Supplier',
    'mat_name[]': ['Cement OPC 50kg'], 'qty[]': ['200'], 'price[]': ['1000'],
    'date': today, 'note': 'e2e grn',
}, follow_redirects=False)
print('grn add ->', r.status_code)
with app.app_context():
    from models import GRN
    grn = GRN.query.order_by(GRN.id.desc()).first()
    print('grn:', grn and (grn.id, grn.supplier_name if hasattr(grn,'supplier_name') else grn.supplier_id))
    check('GRN created', grn is not None)
    GRN_ID = grn.id if grn else None

# ---------- booking: client books 50 bags @ 1300 ----------
r = client.post('/add_booking', data={
    'client_code': CLIENT_CODE,
    'material_name[]': ['Cement OPC 50kg'], 'qty[]': ['50'], 'unit_rate[]': ['1300'],
    'amount': '65000', 'paid_amount': '0', 'date': today,
}, follow_redirects=False)
print('add_booking ->', r.status_code)
with app.app_context():
    from models import Booking
    bk = Booking.query.order_by(Booking.id.desc()).first()
    print('booking:', bk and (bk.id, bk.amount))
    check('booking created', bk is not None)
    check('booking amount 65000', bk is not None and abs((bk.amount or 0) - 65000) < 0.01)

# ---------- direct cash sale: 10 bags @ 1300, paid 13000 ----------
r = client.post('/add_direct_sale', data={
    'client_name': 'E2E Client', 'driver_name': 'E2E Driver',
    'product_name[]': ['Cement OPC 50kg'], 'qty[]': ['10'], 'unit_rate[]': ['1300'],
    'paid_amount': '13000', 'payment_method': 'Cash',
    'payment_account_id': str(ACCOUNT_ID),
    'category': 'Cash', 'sale_date': today,
}, follow_redirects=False)
print('add_direct_sale(cash) ->', r.status_code)
with app.app_context():
    from models import DirectSale
    sale = DirectSale.query.order_by(DirectSale.id.desc()).first()
    print('sale:', sale and (sale.id, getattr(sale, 'total_amount', None), getattr(sale, 'category', None)))
    check('direct sale created', sale is not None)
    SALE_ID = sale.id if sale else None

# ---------- direct credit sale: 20 bags @ 1300, paid 0 ----------
r = client.post('/add_direct_sale', data={
    'client_name': 'E2E Client', 'driver_name': 'E2E Driver',
    'product_name[]': ['Cement OPC 50kg'], 'qty[]': ['20'], 'unit_rate[]': ['1300'],
    'paid_amount': '0', 'payment_method': 'Cash',
    'category': 'Credit Customer', 'sale_date': today,
}, follow_redirects=False)
print('add_direct_sale(credit) ->', r.status_code)

# ---------- client payment: 5000 ----------
r = client.post('/accounts/payments/clients/save', data={
    'client_code': CLIENT_CODE, 'client_name': 'E2E Client',
    'amount': '5000', 'payment_type': 'Receipt', 'method': 'Cash',
    'payment_account_id': str(ACCOUNT_ID), 'date': today,
}, follow_redirects=False)
print('client_payment_save ->', r.status_code)

# ---------- supplier payment: 10000 ----------
r = client.post('/accounts/payments/suppliers/save', data={
    'supplier_id': '1', 'amount': '10000', 'method': 'Cash',
    'payment_account_id': str(ACCOUNT_ID), 'date': today, 'allow_advance': '1',
}, follow_redirects=False)
print('supplier_payment_save ->', r.status_code)

# ---------- loan party + movement ----------
r = client.post('/accounts/loans/parties/add', data={
    'name': 'E2E Lender', 'phone': '03000000003', 'opening_balance': '0',
}, follow_redirects=False)
print('loan party add ->', r.status_code)
with app.app_context():
    from models import LoanParty
    lp = LoanParty.query.filter_by(name='E2E Lender').first()
    print('loan party:', lp and lp.id)
    LP_ID = lp.id if lp else None
if True:
    try:
        r = client.post('/accounts/loans/movements/add', data={
            'loan_party_id': str(LP_ID), 'movement_type': 'received', 'amount': '20000',
            'cash_account_id': str(ACCOUNT_ID), 'date_posted': today, 'note': 'e2e loan',
        }, follow_redirects=False)
        print('loan movement add ->', r.status_code)
    except Exception as exc:
        print('loan movement failed:', exc)

# ---------- expense via cash flow ----------
r = client.post('/cash_flow', data={
    'action': 'record_movement', 'direction': 'out', 'amount': '1500',
    'cash_account_id': str(ACCOUNT_ID), 'category_name': 'Utilities',
    'description': 'e2e electricity bill', 'movement_date': today,
}, follow_redirects=False)
print('cash_flow record_movement ->', r.status_code)

# ---------- database cross-checks ----------
with app.app_context():
    from models import DirectSale, Booking, GRN, GRNItem, CashFlowEntry, AccountTransaction
    n_sales = DirectSale.query.count()
    n_bookings = Booking.query.count()
    n_grns = GRN.query.count()
    sales_total = sum((s.amount or 0) for s in DirectSale.query.all())
    print(f'counts: sales={n_sales} bookings={n_bookings} grns={n_grns} sales_total={sales_total}')
    check('2 sales recorded', n_sales == 2)
    check('1 booking recorded', n_bookings == 1)
    check('1 GRN recorded', n_grns == 1)

# ---------- report endpoints render ----------
for path in ['/', '/profit_reports', '/cash_flow', '/reports/cash_flow', '/stock_summary']:
    try:
        r = client.get(path)
        print(f'GET {path} -> {r.status_code}')
    except Exception as exc:
        print(f'GET {path} -> ERROR {exc}')

print()
print(f'RESULT: {len(OK)} passed, {len(FAIL)} failed')
if FAIL:
    print('FAILED:', FAIL)
    sys.exit(1)

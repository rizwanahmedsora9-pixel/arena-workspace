"""payments — split from accounts.py."""
from ._common import *  # noqa
from app.services.grn_costing import OBLIGATION_LABEL
from app.services.grn_costing import payment_obligation_label
from app.services.grn_payments import supplier_open_obligation_options

def _payment_page_size():
    try:
        raw = request.args.get('per_page', 50, type=int)
        if raw is None:
            raw = 50
        return min(max(int(raw), 10), 100)
    except Exception:
        return 50


def _normalize_method_filter(method_raw):
    if not method_raw:
        return []
    m = method_raw.strip().lower()
    if not m:
        return []
    if m == 'bank':
        return ['bank', 'bank transfer']
    if m in ('check', 'cheque'):
        return ['check', 'cheque']
    return [m]


def _payment_filter_state():
    q = (request.args.get('q') or '').strip()
    method = (request.args.get('method') or '').strip()
    show = (request.args.get('show') or 'active').strip().lower()
    payment_type = (request.args.get('payment_type') or '').strip()
    try:
        party_raw = request.args.get('party_id')
        party_id = int(party_raw) if party_raw not in (None, '', '0') else None
        if party_id == 0:
            party_id = None
    except Exception:
        party_id = None
    try:
        acc_raw = request.args.get('account_id')
        account_id = int(acc_raw) if acc_raw not in (None, '', '0') else None
        if account_id == 0:
            account_id = None
    except Exception:
        account_id = None

    return {
        'q': q,
        'method': method,
        'method_values': _normalize_method_filter(method),
        'payment_type': payment_type,
        'show': show,
        'party_id': party_id,
        'account_id': account_id,
        'per_page': _payment_page_size(),
    }


@accounts_bp.route('/payments/clients')
@login_required
def client_payments():
    """Paginated, intersecting filters and full CRUD for client payments."""
    page = max(request.args.get('page', 1, type=int) or 1, 1)
    state = _payment_filter_state()
    show_mode = state['show'] if state['show'] in ('active', 'voided', 'all') else 'active'
    date_from, date_to_excl = _parse_date_range()

    q = Payment.query.filter(Payment.date_posted >= date_from, Payment.date_posted < date_to_excl)
    if show_mode == 'active':
        q = q.filter(Payment.is_void == False)
    elif show_mode == 'voided':
        q = q.filter(Payment.is_void == True)

    if state['q']:
        like = f"%{state['q']}%"
        q = q.outerjoin(Client, Payment.client_id == Client.id).filter(or_(
            Payment.client_name.ilike(like),
            Client.code.ilike(like),
            Client.name.ilike(like),
            Payment.note.ilike(like),
            Payment.account_name.ilike(like),
            Payment.bank_name.ilike(like),
            Payment.account_no.ilike(like),
            Payment.manual_bill_no.ilike(like),
            Payment.auto_bill_no.ilike(like),
            Payment.method.ilike(like),
            Payment.discount_reason.ilike(like),
        ))

    if state['method_values']:
        q = q.filter(func.lower(Payment.method).in_(state['method_values']))

    if state['payment_type']:
        pt = state['payment_type'].strip().lower()
        if pt in ('receipt', 'payment received'):
            q = q.filter(Payment.amount >= 0, func.lower(func.coalesce(Payment.payment_type, '')) != 'refund')
        elif pt == 'refund':
            q = q.filter(or_(func.lower(Payment.payment_type) == 'refund', Payment.amount < 0))
        elif pt in ('waive-off', 'waive off', 'waive'):
            q = q.filter(or_(func.lower(Payment.payment_type).like('%waive%'), Payment.discount > 0))

    if state['party_id']:
        selected_client = db.session.get(Client, state['party_id'])
        if selected_client:
            q = q.filter(or_(
                Payment.client_id == selected_client.id,
                and_(
                    Payment.client_id.is_(None),
                    func.lower(func.trim(Payment.client_name)) == selected_client.name.strip().lower()
                )
            ))
        else:
            q = q.filter(False)

    if state['account_id']:
        q = q.filter(Payment.payment_account_id == state['account_id'])

    total_amount = q.with_entities(func.coalesce(func.sum(Payment.amount), 0)).scalar() or 0
    total_count = q.with_entities(func.count(func.distinct(Payment.id))).scalar() or 0

    ordered_q = q.order_by(Payment.date_posted.desc(), Payment.id.desc())
    payments = ordered_q.paginate(page=page, per_page=state['per_page'], error_out=False)
    if payments.pages and page > payments.pages:
        payments = ordered_q.paginate(page=payments.pages, per_page=state['per_page'], error_out=False)

    accounts = _active_accounts().filter(func.lower(func.trim(Account.category)).in_(['cash', 'bank'])).order_by(Account.name.asc(), Account.id.asc()).all()
    clients = _active_clients()
    all_clients = Client.query.order_by(Client.name.asc(), Client.id.asc()).all()
    from .helpers import _not_system_account_query
    all_accounts = _not_system_account_query(Account.query).order_by(Account.name.asc(), Account.id.asc()).all()
    client_options = [{'code': c.code, 'name': c.name} for c in clients]
    account_options = [{'id': a.id, 'label': _account_option_label(a)} for a in accounts]
    payment_meta = {}
    from app.services.payments_crud import _client_payment_kind, _client_payment_source
    for p in payments.items:
        source_type, source_id = _client_payment_source(p)
        payment_meta[p.id] = {'kind': _client_payment_kind(p), 'source_type': source_type, 'source_id': source_id}
    payments_readonly = not _payments_permission_ok()

    return render_template(
        'accounts/client_payments.html', payments=payments,
        date_from=date_from, date_to=date_to_excl - timedelta(days=1),
        search=state['q'], method_f=state['method'], payment_type_f=state['payment_type'], show_mode=show_mode,
        party_id_f=state['party_id'], account_id_f=state['account_id'], per_page=state['per_page'],
        total_amount=total_amount, total_count=total_count,
        payments_readonly=payments_readonly, accounts=accounts, clients=clients,
        all_clients=all_clients, all_accounts=all_accounts,
        client_options=client_options, account_options=account_options,
        filter_party_options=[{'id': c.id, 'label': f"{c.name} ({c.code})" + ('' if c.is_active else ' [Inactive]')} for c in all_clients],
        filter_account_options=[{'id': a.id, 'label': _account_option_label(a) + ('' if a.is_active else ' [Inactive]')} for a in all_accounts],
        filter_party_name=(next((f"{c.name} ({c.code})" for c in all_clients if c.id == state['party_id']), '')),
        filter_account_name=(next((_account_option_label(a) for a in all_accounts if a.id == state['account_id']), '')),
        payment_meta=payment_meta,
    )


@accounts_bp.route('/payments/suppliers')
@login_required
def supplier_payments():
    """Paginated, intersecting filters and full CRUD for supplier payments."""
    page = max(request.args.get('page', 1, type=int) or 1, 1)
    state = _payment_filter_state()
    show_mode = state['show'] if state['show'] in ('active', 'voided', 'all') else 'active'
    date_from, date_to_excl = _parse_date_range()

    q = SupplierPayment.query.filter(SupplierPayment.date_posted >= date_from, SupplierPayment.date_posted < date_to_excl)
    if show_mode == 'active':
        q = q.filter(SupplierPayment.is_void == False)
    elif show_mode == 'voided':
        q = q.filter(SupplierPayment.is_void == True)

    if state['q']:
        like = f"%{state['q']}%"
        q = q.outerjoin(Supplier).filter(or_(
            Supplier.name.ilike(like),
            SupplierPayment.note.ilike(like),
            SupplierPayment.account_name.ilike(like),
            SupplierPayment.bank_name.ilike(like),
            SupplierPayment.account_no.ilike(like),
            SupplierPayment.manual_bill_no.ilike(like),
            SupplierPayment.auto_bill_no.ilike(like),
            SupplierPayment.method.ilike(like),
        ))

    if state['method_values']:
        q = q.filter(func.lower(SupplierPayment.method).in_(state['method_values']))

    if state['party_id']:
        q = q.filter(SupplierPayment.supplier_id == state['party_id'])

    if state['account_id']:
        q = q.filter(SupplierPayment.payment_account_id == state['account_id'])

    total_amount = q.with_entities(func.coalesce(func.sum(SupplierPayment.amount), 0)).scalar() or 0
    total_count = q.with_entities(func.count(func.distinct(SupplierPayment.id))).scalar() or 0

    ordered_q = q.order_by(SupplierPayment.date_posted.desc(), SupplierPayment.id.desc())
    payments = ordered_q.paginate(page=page, per_page=state['per_page'], error_out=False)
    if payments.pages and page > payments.pages:
        payments = ordered_q.paginate(page=payments.pages, per_page=state['per_page'], error_out=False)

    suppliers = _active_suppliers()
    accounts = _active_accounts().filter(func.lower(func.trim(Account.category)).in_(['cash', 'bank'])).order_by(Account.name.asc(), Account.id.asc()).all()
    all_suppliers = Supplier.query.order_by(Supplier.name.asc(), Supplier.id.asc()).all()
    from .helpers import _not_system_account_query
    all_accounts = _not_system_account_query(Account.query).order_by(Account.name.asc(), Account.id.asc()).all()
    supplier_options = [{'id': s.id, 'name': s.name} for s in suppliers]
    account_options = [{'id': a.id, 'label': _account_option_label(a)} for a in accounts]
    payment_meta = {}
    from app.services.payments_crud import _supplier_payment_source
    for p in payments.items:
        source_type, source_id = _supplier_payment_source(p)
        payment_meta[p.id] = {
            'source_type': source_type,
            'source_id': source_id,
            'grn_payment': bool(getattr(p, 'grn_id', None)
                                or (getattr(p, 'source_type', None) or '') == 'GRN_PAYMENT'),
            'obligation_label': payment_obligation_label(p),
        }
    payments_readonly = not _payments_permission_ok()
    # The form pays a real GRN payable; it never posts a free-floating voucher
    # that the receiving GRN would not know about (owner rule A3).
    pay_obligations = supplier_open_obligation_options(state['party_id']) if state['party_id'] else []

    return render_template(
        'accounts/supplier_payments.html', payments=payments,
        date_from=date_from, date_to=date_to_excl - timedelta(days=1),
        search=state['q'], method_f=state['method'], show_mode=show_mode,
        party_id_f=state['party_id'], account_id_f=state['account_id'], per_page=state['per_page'],
        total_amount=total_amount, total_count=total_count,
        suppliers=suppliers, accounts=accounts,
        all_suppliers=all_suppliers, all_accounts=all_accounts,
        supplier_options=supplier_options, account_options=account_options,
        filter_party_options=[{'id': s.id, 'label': s.name + ('' if s.is_active else ' [Inactive]')} for s in all_suppliers],
        filter_account_options=[{'id': a.id, 'label': _account_option_label(a) + ('' if a.is_active else ' [Inactive]')} for a in all_accounts],
        filter_party_name=(next((s.name for s in all_suppliers if s.id == state['party_id']), '')),
        filter_account_name=(next((_account_option_label(a) for a in all_accounts if a.id == state['account_id']), '')),
        payments_readonly=payments_readonly, payment_meta=payment_meta,
        pay_obligations=pay_obligations,
        obligation_labels=OBLIGATION_LABEL,
    )


@accounts_bp.route('/payments/clients/void/<int:id>', methods=['POST'])
@login_required
def client_payment_void(id):
    if not (current_user.role in ('admin', 'root') or getattr(current_user, 'can_manage_payments', False)):
        flash('Permission denied', 'danger')
        return redirect(request.referrer or url_for('accounts.client_payments'))

    payment = Payment.query.get_or_404(id)
    try:
        from app.services.payments_crud import delete_client_payment
        if delete_client_payment(payment, actor=current_user):
            db.session.commit()
            flash('Payment deleted. Balances reversed and recalculated.', 'success')
        else:
            flash('Payment already deleted.', 'warning')
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), 'danger')
    except Exception as exc:
        db.session.rollback()
        logger.exception('Client payment delete failed')
        flash(f'Unable to delete payment: {exc or "the payment could not be deleted. Please try again."}', 'danger')

    return redirect(request.referrer or url_for('accounts.client_payments'))



@accounts_bp.route('/expenditures')
@login_required
def expenditures():
    """View and manage personal expenditures."""
    page = request.args.get('page', 1, type=int)
    per_page = 50
    search = (request.args.get('q') or '').strip()
    category_f = (request.args.get('category') or '').strip()
    method_f = (request.args.get('method') or '').strip()
    date_from, date_to_excl = _parse_date_range()

    fbm_q = FbmCashDrawerEntry.query.filter(
        FbmCashDrawerEntry.entry_type == 'out',
        FbmCashDrawerEntry.is_void == False,
        FbmCashDrawerEntry.date_posted >= date_from,
        FbmCashDrawerEntry.date_posted < date_to_excl
    )
    if search:
        like = f'%{search}%'
        fbm_q = fbm_q.filter(or_(FbmCashDrawerEntry.note.ilike(like), FbmCashDrawerEntry.category.ilike(like)))
    if category_f:
        fbm_q = fbm_q.filter(FbmCashDrawerEntry.category == category_f)
    if method_f:
        fbm_q = fbm_q.filter(func.lower(FbmCashDrawerEntry.method) == method_f.lower())
    fbm_expenditures = fbm_q.all()

    tx_q = AccountTransaction.query.filter(
        AccountTransaction.date_posted >= date_from,
        AccountTransaction.date_posted < date_to_excl,
        AccountTransaction.is_void == False,
        AccountTransaction.transaction_type.in_(['Expense', 'Payment', 'Driver Payment']),
        func.lower(func.coalesce(AccountTransaction.source_type, '')) != 'loanprincipal',
        AccountTransaction.from_account_id.isnot(None)
    )
    # Search and category filtering are applied below after linked Cash Flow
    # metadata is loaded, so the visible category and recipient are searchable.
    # Legacy rows still fall back to their transaction description.
    if method_f:
        tx_q = tx_q.join(Account, AccountTransaction.from_account_id == Account.id).filter(func.lower(Account.category) == method_f.lower())
    tx_expenditures = tx_q.all()
    tx_ids = [tx.id for tx in tx_expenditures]
    flow_by_tx = {}
    for idx in range(0, len(tx_ids), 900):
        for flow in CashFlowEntry.query.filter(CashFlowEntry.account_tx_id.in_(tx_ids[idx:idx + 900])).all():
            flow_by_tx[flow.account_tx_id] = flow

    all_expenditures = []
    for e in fbm_expenditures:
        all_expenditures.append({
            'date_posted': e.date_posted,
            'category': e.category or '',
            'amount': float(e.amount or 0),
            'method': e.method or '',
            'note': e.note or '',
            'type': 'FBM Cash Drawer'
        })
    accounts_by_id = {a.id: a for a in Account.query.all()} if tx_expenditures else {}
    for tx in tx_expenditures:
        acc = accounts_by_id.get(tx.from_account_id)
        flow = flow_by_tx.get(tx.id)
        category = ('Driver / Delivery Services' if tx.transaction_type == 'Driver Payment'
                    else ((flow.category.name if flow and flow.category else '')
                          or tx.description or 'Expense'))
        if category_f and category != category_f:
            continue
        if search:
            searchable = ' '.join(filter(None, [
                tx.description, tx.note, category,
                flow.subcategory.name if flow and flow.subcategory else '',
                flow.party_name if flow else '',
            ])).lower()
            if search.lower() not in searchable:
                continue
        note_parts = [tx.note or '']
        if flow and flow.party_name:
            note_parts.append(f'Recipient: {flow.party_name}')
        all_expenditures.append({
            'date_posted': tx.date_posted,
            'category': category,
            'amount': float(tx.amount or 0),
            'method': (acc.category.capitalize() if acc else 'Other'),
            'note': ' · '.join(part for part in note_parts if part),
            'type': 'Account Transaction'
        })

    all_expenditures.sort(key=lambda x: x['date_posted'], reverse=True)

    total_amount = sum(item['amount'] for item in all_expenditures)
    total_count = len(all_expenditures)

    start = (page - 1) * per_page
    end = start + per_page
    paginated_expenditures = all_expenditures[start:end]
    
    pagination_wrapper = SimpleNamespace(
        items=paginated_expenditures,
        page=page,
        per_page=per_page,
        total=total_count,
        pages=(total_count + per_page - 1) // per_page,
        has_prev=(page > 1),
        has_next=(end < total_count),
        prev_num=page - 1,
        next_num=page + 1
    )

    all_categories = set()
    for r in db.session.query(FbmCashDrawerEntry.category).filter(
        FbmCashDrawerEntry.entry_type == 'out',
        FbmCashDrawerEntry.is_void == False,
        FbmCashDrawerEntry.category.isnot(None),
        FbmCashDrawerEntry.category != ''
    ).distinct(FbmCashDrawerEntry.category).all():
        all_categories.add(r[0])
    for r in db.session.query(AccountTransaction.description).filter(
        AccountTransaction.is_void == False,
        AccountTransaction.transaction_type.in_(['Expense', 'Payment']),
        AccountTransaction.description.isnot(None),
        AccountTransaction.description != ''
    ).distinct(AccountTransaction.description).all():
        all_categories.add(r[0])
    for r in db.session.query(CashFlowCategory.name).filter(
        CashFlowCategory.is_active == True,
        func.lower(func.coalesce(CashFlowCategory.direction, 'both')).in_(['out', 'both']),
    ).distinct(CashFlowCategory.name).all():
        all_categories.add(r[0])
    categories = sorted(list(all_categories))

    all_methods = set()
    for r in db.session.query(FbmCashDrawerEntry.method).filter(
        FbmCashDrawerEntry.entry_type == 'out',
        FbmCashDrawerEntry.is_void == False,
        FbmCashDrawerEntry.method.isnot(None),
        FbmCashDrawerEntry.method != ''
    ).distinct(FbmCashDrawerEntry.method).all():
        all_methods.add(r[0])
    for r in db.session.query(Account.category).filter(
        Account.is_active == True,
        Account.category.isnot(None),
        Account.category != ''
    ).distinct(Account.category).all():
        all_methods.add(r[0].capitalize())
    methods = sorted(list(all_methods))

    # GRN charges flagged EXPENSE are accrued purchase expenses (they may be
    # unpaid).  They are shown separately from cash-based expenditure totals
    # so nothing is double counted.
    from models import GRNCharge, GRN
    from app.services.grn_costing import (
        charge_billed_to_supplier, charge_supplier_billed_minor, charge_effective_minor,
    )
    accrued_charges = GRNCharge.query.filter(
        GRNCharge.cost_treatment.in_(['EXPENSE', 'INVENTORY']),
        GRNCharge.is_void == False,
    ).all()
    accrued_grn_ids = sorted({int(c.grn_id) for c in accrued_charges if getattr(c, 'grn_id', None)})
    accrued_grns = {}
    for idx in range(0, len(accrued_grn_ids), 900):
        for g in GRN.query.filter(GRN.id.in_(accrued_grn_ids[idx:idx + 900])).all():
            accrued_grns[int(g.id)] = g
    accrued = []
    for charge in accrued_charges:
        grn = accrued_grns.get(int(charge.grn_id)) if getattr(charge, 'grn_id', None) else None
        if grn is None or bool(getattr(grn, 'is_void', False)):
            continue
        posted = getattr(grn, 'date_posted', None)
        # date_posted is a datetime; the filter bounds are dates.
        posted_day = posted.date() if hasattr(posted, 'date') else posted
        if date_from and posted_day and posted_day < date_from:
            continue
        if posted_day and posted_day >= date_to_excl:
            continue
        treatment = (getattr(charge, 'cost_treatment', None) or 'INVENTORY').upper()
        billed_to_supplier = charge_billed_to_supplier(charge, grn)
        if treatment == 'INVENTORY' and not billed_to_supplier:
            # Material costs are inside the stock value; only the GRN expenses
            # that were billed to the supplier are recognised here, and never
            # twice with the cash-based rows above.
            continue
        accrued.append({
            'date_posted': posted,
            'category': charge.charge_type or 'GRN Charge',
            'amount': float(charge_effective_minor(charge)) / 100.0,
            'note': f"GRN #{charge.grn_id} · {getattr(charge, 'recipient_name', '') or ''}"
                    + (' · billed to supplier' if billed_to_supplier else ''),
            'paid_minor': charge_supplier_billed_minor(charge, grn) if billed_to_supplier else 0,
        })
    accrued.sort(key=lambda x: x['date_posted'] or date_from, reverse=True)

    return render_template('accounts/expenditures.html', expenditures=pagination_wrapper,
                           accrued_purchase_expenses=accrued,
                           accrued_total=sum(a['amount'] for a in accrued),
                           date_from=date_from, date_to=date_to_excl - timedelta(days=1),
                           search=search, category_f=category_f, method_f=method_f,
                           categories=categories, methods=methods,
                           total_amount=total_amount, total_count=total_count,
                           page=page, per_page=per_page,
                           has_prev=(page > 1), has_next=(end < total_count))


@accounts_bp.route('/receipts')
@login_required
def receipts():
    """View receipts from sales and GRN paid amounts within a date range."""
    date_from, date_to_excl = _parse_date_range(default_days=0)

    sales = DirectSale.query.filter(
        DirectSale.date_posted >= date_from,
        DirectSale.date_posted < date_to_excl,
        DirectSale.is_void == False
    ).order_by(DirectSale.date_posted.desc()).all()

    grns = GRN.query.filter(
        GRN.date_posted >= date_from,
        GRN.date_posted < date_to_excl,
        GRN.is_void == False,
        GRN.paid_amount > 0
    ).order_by(GRN.date_posted.desc()).all()

    # The receipt line must show what the GRN was actually worth.  Summing only
    # the landed-cost columns (loading / freight / other / adjustment) ignored
    # every received material line, so an ordinary purchase of 100 bags showed
    # "Total Rs. 0.00" while its paid amount was 50,000.  Use the same
    # authoritative total as the GRN page, ledger and printed bill.
    from app.services.grn_costing import grn_breakdown
    grn_totals = {grn.id: grn_breakdown(grn)['landed_cost_total'] for grn in grns}

    return render_template('accounts/receipts.html', sales=sales, grns=grns,
                           grn_totals=grn_totals,
                           date_from=date_from, date_to=date_to_excl - timedelta(days=1))




def _payments_permission_ok():
    return current_user.role in ('admin', 'root') or getattr(current_user, 'can_manage_payments', False)


@accounts_bp.route('/payments/clients/save', methods=['POST'])
@login_required
def client_payment_save():
    """Create or update a client payment (single shared form for Create + Edit)."""
    if not _payments_permission_ok():
        flash('Permission denied', 'danger')
        return redirect(url_for('accounts.client_payments'))
    show_mode = (request.form.get('show') or 'active').strip().lower()
    payment_id = request.form.get('payment_id', type=int)
    try:
        from app.services.files_pdf import save_photo
        from app.services.payments_crud import save_client_payment
        uploaded_photo = save_photo(request.files.get('photo'))
        payment, created = save_client_payment(
            payment_id=payment_id,
            client_name=request.form.get('client_name', ''),
            client_code=request.form.get('client_code', ''),
            amount=request.form.get('amount', 0),
            discount=request.form.get('discount', 0),
            discount_reason=request.form.get('discount_reason', ''),
            payment_type=request.form.get('payment_type', 'Receipt'),
            method=request.form.get('method', 'Cash'),
            payment_account_id=request.form.get('payment_account_id'),
            manual_bill_no=request.form.get('manual_bill_no', ''),
            date_posted=request.form.get('date', ''),
            note=request.form.get('note', ''),
            photo_path=uploaded_photo,
            photo_url=request.form.get('photo_url', ''),
            idempotency_key=request.form.get('idempotency_key'),
            expected_revision=request.form.get('revision'),
            actor=current_user,
        )
        replay = bool(getattr(payment, '_idempotent_replay', False))
        db.session.commit()
        if replay:
            flash('This payment submission was already processed; no duplicate was created.', 'info')
        else:
            flash('Payment saved successfully.' if created else 'Payment updated. All balances recalculated.', 'success')
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), 'danger')
    except Exception as exc:
        db.session.rollback()
        logger.exception('Client payment save failed')
        flash(f'Unable to save payment: {exc or "the payment could not be saved. Please check the details and try again."}', 'danger')
    return redirect(url_for('accounts.client_payments', show=show_mode))


@accounts_bp.route('/payments/clients/<int:id>/data')
@login_required
def client_payment_data(id):
    """JSON payload that populates the shared create/edit form for an existing payment."""
    p = Payment.query.get_or_404(id)
    c = db.session.get(Client, p.client_id) if getattr(p, 'client_id', None) else None
    if c is None:
        try:
            from app.services.lookups import get_client_by_input
            c = get_client_by_input(p.client_name or '')
        except Exception:
            c = None
    from app.services.payments_crud import _client_payment_kind, _client_payment_source
    source_type, source_id = _client_payment_source(p)
    payment_kind = _client_payment_kind(p)
    account_label = _account_option_label(p.payment_account) if p.payment_account else (p.account_name or '')
    return jsonify({
        'id': p.id,
        'revision': getattr(p, 'revision', None) or 1,
        'client_name': p.client_name or '',
        'client_code': (c.code if c else ''),
        'amount': round(abs(float(p.amount or 0)), 2),
        'discount': round(float(p.discount or 0), 2),
        'discount_reason': p.discount_reason or '',
        'payment_type': payment_kind,
        'method': ('Cash' if (p.method or '').strip().lower() == 'refund' else (p.method or 'Cash')),
        'payment_account_id': p.payment_account_id,
        'bank_name': p.bank_name or '',
        'account_name': p.account_name or '',
        'account_label': account_label,
        'account_no': p.account_no or '',
        'manual_bill_no': p.manual_bill_no or '',
        'auto_bill_no': p.auto_bill_no or '',
        'date': p.date_posted.strftime('%Y-%m-%d') if p.date_posted else '',
        'note': p.note or '',
        'photo_url': p.photo_url or '',
        'photo_path': p.photo_path or '',
        'is_void': bool(p.is_void),
        'source_type': source_type,
        'source_id': source_id,
    })


@accounts_bp.route('/payments/suppliers/save', methods=['POST'])
@login_required
def supplier_payment_save():
    """Create or update a supplier payment (single shared form for Create + Edit)."""
    if not _payments_permission_ok():
        flash('Permission denied', 'danger')
        return redirect(url_for('accounts.supplier_payments'))
    show_mode = (request.form.get('show') or 'active').strip().lower()
    payment_id = request.form.get('payment_id', type=int)
    try:
        from app.services.payments_crud import save_supplier_payment
        from app.services.grn_payments import post_supplier_payment
        obligation_key = (request.form.get('obligation_key') or '').strip()
        if payment_id:
            # Editing an existing (standalone) voucher keeps its own path.
            payment, created = save_supplier_payment(
                payment_id=payment_id,
                supplier_id=request.form.get('supplier_id'),
                amount=request.form.get('amount', 0),
                method=request.form.get('method', 'Cash'),
                payment_account_id=request.form.get('payment_account_id'),
                bank_name=request.form.get('bank_name', ''),
                account_name=request.form.get('account_name', ''),
                account_no=request.form.get('account_no', ''),
                manual_bill_no=request.form.get('manual_bill_no', ''),
                date_posted=request.form.get('date', ''),
                note=request.form.get('note', ''),
                idempotency_key=request.form.get('idempotency_key'),
                expected_revision=request.form.get('revision'),
                actor=current_user,
            )
            payments, created_any = [payment], created
        else:
            # New payments MUST settle a GRN payable (material, GRN expenses or
            # a charge recipient) so no GRN is left showing money as unpaid.
            payments, created_any = post_supplier_payment(
                supplier_id=request.form.get('supplier_id'),
                amount=request.form.get('amount', 0),
                method=request.form.get('method', 'Cash'),
                payment_account_id=request.form.get('payment_account_id'),
                date_posted=request.form.get('date', ''),
                reference=(request.form.get('manual_bill_no') or '').strip(),
                note=request.form.get('note', ''),
                manual_bill_no=(request.form.get('manual_bill_no') or '').strip(),
                obligation_key=obligation_key or None,
                allow_advance=bool(request.form.get('allow_advance')),
                idempotency_key=request.form.get('idempotency_key'),
                actor=current_user,
            )
            created = created_any
        replay = any(bool(getattr(p, '_idempotent_replay', False)) for p in payments)
        db.session.commit()
        if replay:
            flash('This supplier-payment submission was already processed; no duplicate was created.', 'info')
        elif created and not payment_id:
            total = sum(float(getattr(p, 'amount', 0) or 0) for p in payments)
            detail = ', '.join(sorted({payment_obligation_label(p) for p in payments}))
            flash(f'Rs. {total:,.2f} paid — {detail}. The GRN payable, Cash Flow and the ledgers are updated.', 'success')
        else:
            flash('Supplier payment saved successfully.' if created else 'Supplier payment updated. All balances recalculated.', 'success')
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), 'danger')
    except Exception as exc:
        db.session.rollback()
        logger.exception('Supplier payment save failed')
        flash(f'Unable to save supplier payment: {exc or "the payment could not be saved. Please check the details and try again."}', 'danger')
    return redirect(url_for('accounts.supplier_payments', show=show_mode))


@accounts_bp.route('/payments/suppliers/<int:id>/data')
@login_required
def supplier_payment_data(id):
    """JSON payload that populates the shared create/edit form for a supplier payment."""
    p = SupplierPayment.query.get_or_404(id)
    from app.services.payments_crud import _supplier_payment_source
    source_type, source_id = _supplier_payment_source(p)
    account_label = _account_option_label(p.payment_account) if p.payment_account else (p.account_name or '')
    return jsonify({
        'id': p.id,
        'revision': getattr(p, 'revision', None) or 1,
        'supplier_id': p.supplier_id,
        'supplier_name': (p.supplier.name if p.supplier else ''),
        'amount': round(float(p.amount or 0), 2),
        'method': p.method or 'Cash',
        'payment_account_id': p.payment_account_id,
        'bank_name': p.bank_name or '',
        'account_name': p.account_name or '',
        'account_label': account_label,
        'account_no': p.account_no or '',
        'manual_bill_no': p.manual_bill_no or '',
        'auto_bill_no': p.auto_bill_no or '',
        'date': p.date_posted.strftime('%Y-%m-%d') if p.date_posted else '',
        'note': p.note or '',
        'is_void': bool(p.is_void),
        'source_type': source_type,
        'source_id': source_id,
        'grn_payment': bool(getattr(p, 'grn_id', None)
                            or (getattr(p, 'source_type', None) or '') == 'GRN_PAYMENT'),
        'obligation_label': payment_obligation_label(p),
    })


@accounts_bp.route('/payments/suppliers/<int:id>/delete', methods=['POST'])
@login_required
def supplier_payment_delete(id):
    """Soft-delete a supplier payment and reverse its accounting effects."""
    if not _payments_permission_ok():
        flash('Permission denied', 'danger')
        return redirect(url_for('accounts.supplier_payments'))
    payment = SupplierPayment.query.get_or_404(id)
    try:
        from app.services.payments_crud import delete_supplier_payment
        if delete_supplier_payment(payment, actor=current_user):
            db.session.commit()
            flash('Supplier payment deleted. Balances reversed.', 'success')
        else:
            flash('Supplier payment already deleted.', 'warning')
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), 'danger')
    except Exception as exc:
        db.session.rollback()
        logger.exception('Supplier payment delete failed')
        flash(f'Unable to delete supplier payment: {exc or "the payment could not be deleted. Please try again."}', 'danger')
    return redirect(request.referrer or url_for('accounts.supplier_payments'))



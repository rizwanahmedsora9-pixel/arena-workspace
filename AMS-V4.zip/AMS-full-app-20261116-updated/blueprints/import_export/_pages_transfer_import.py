"""pages — split from import_export.py."""
from ._common import *  # noqa

def _wants_import_json():
    if (request.args.get('format') or request.form.get('format') or '').lower() == 'json':
        return True
    if request.headers.get('X-Requested-With') == 'fetch':
        return True
    accept = (request.headers.get('Accept') or '').lower()
    return 'application/json' in accept


def _import_result_payload(ok, headline, report, extra=None):
    report = report or {}
    # Slim row-level issue details for the finish dialog.  Capped and truncated
    # so a bad workbook cannot produce a multi-megabyte JSON response; the full
    # list stays available in the downloadable issue report.
    issue_rows = []
    for issue in (report.get('issue_rows') or [])[:100]:
        slim = {
            'table': str(issue.get('table') or '')[:80],
            'sheet_row': '' if issue.get('sheet_row') in (None, '') else str(issue.get('sheet_row'))[:12],
            'status': str(issue.get('status') or '')[:40],
            'reason': str(issue.get('reason') or '')[:300],
            'primary_key': str(issue.get('primary_key') or '')[:200],
            'label': str(issue.get('label') or '')[:200],
        }
        row_json = str(issue.get('row_json') or '')
        if row_json:
            slim['row_json'] = row_json[:300]
        issue_rows.append(slim)
    try:
        issue_rows_count = int(report.get('issue_rows_count') or 0)
    except (TypeError, ValueError):
        issue_rows_count = 0
    if not issue_rows_count:
        raw_issues = report.get('issue_rows')
        if isinstance(raw_issues, (list, tuple)):
            issue_rows_count = len(raw_issues)
        else:
            # Missing/empty issue_rows used to be `or 0`, then len(0) crashed
            # the JSON finish dialog (and the JSON error handler that retries
            # this helper with {}).
            issue_rows_count = 0
    error_details = [str(item)[:300] for item in (report.get('error_details') or [])[:100]]
    # A rolled-back attempt persisted nothing: show zero saved data so the
    # dialog cannot be misread as "some rows were imported".
    rolled_back = bool((report or {}).get('rolled_back'))
    payload = {
        'ok': bool(ok),
        'status': (report or {}).get('status') or ('ok' if ok else 'failed'),
        'headline': headline,
        'rolled_back': rolled_back,
        'inserted': 0 if rolled_back else ((report or {}).get('inserted') or (report or {}).get('imported') or 0),
        'updated': 0 if rolled_back else ((report or {}).get('updated') or 0),
        'skipped': 0 if rolled_back else ((report or {}).get('skipped') or 0),
        'failed': (report or {}).get('failed') or (report or {}).get('errors') or 0,
        'errors': (report or {}).get('errors') or (report or {}).get('failed') or 0,
        'warnings': (report or {}).get('warnings') or 0,
        'tables': (report or {}).get('tables'),
        'table_results': (report or {}).get('table_results') or [],
        'users': (report or {}).get('users') or [],
        'issue_rows': issue_rows,
        'issue_rows_count': issue_rows_count,
        'error_details': error_details,
    }
    if extra:
        payload.update(extra)
    return payload


def _json_import_error(msg, status=400):
    """Return a JSON error payload for fetch-driven import clients."""
    return jsonify(_import_result_payload(False, msg, {})), status


@import_export_bp.route('/transfer/import', methods=['POST'])
@login_required
def transfer_import():
    # ===== PANDAS DEPENDENCY CHECK =====
    if not _validate_pandas_installed():
        msg = 'Spreadsheet import requires pandas. Install requirements-data.txt and restart the app.'
        if _wants_import_json():
            return _json_import_error(msg, 503)
        flash(msg, 'danger')
        return redirect(url_for('import_export.import_export_page'))
    # ===== END DEPENDENCY CHECK =====
    
    file = request.files.get('file')
    if not file:
        msg = 'Please upload an Excel file.'
        if _wants_import_json():
            return _json_import_error(msg, 400)
        flash(msg, 'danger')
        return redirect(url_for('import_export.import_export_page'))

    try:
        scope_ctx = _resolve_scope_context(
            scope_raw=request.form.get('scope'),
            tenant_id_raw=request.form.get('tenant_id'),
        )
    except ValueError as e:
        msg = str(e)
        if _wants_import_json():
            return _json_import_error(msg, 400)
        flash(msg, 'danger')
        return redirect(url_for('import_export.import_export_page'))

    sections = [str(x).strip().lower() for x in request.form.getlist('sections') if str(x).strip()]
    if not sections:
        sections = ['all_business']

    try:
        file_bytes = file.read()
        if hasattr(file, 'stream'):
            file.stream.seek(0)
        _archive_artifact_bytes(file_bytes, f"transfer_import_{file.filename}", kind='imports')
    except Exception as e:
        msg = f'Invalid file: {e}'
        if _wants_import_json():
            return _json_import_error(msg, 400)
        flash(msg, 'danger')
        return redirect(url_for('import_export.import_export_page'))

    notes = []
    detected_kind = _detect_transfer_workbook_kind(file_bytes)
    if detected_kind == 'literal_all' and 'literal_all' not in sections:
        sections = ['literal_all']
        notes.append('Detected Literal Full Raw workbook. Switched import mode automatically.')
    elif detected_kind == 'all_business' and 'literal_all' in sections and 'all_business' not in sections:
        sections = ['all_business']
        notes.append('Detected Master Backup workbook. Switched import mode automatically.')

    if 'literal_all' in sections:
        if not _full_raw_import_enabled():
            msg = 'Literal Full Import is disabled by safety toggle.'
            if _wants_import_json():
                return _json_import_error(msg, 400)
            flash(msg, 'warning')
            return redirect(url_for('import_export.import_export_page'))
        mode = (request.form.get('mode') or 'append').strip().lower()
        if mode not in ['append', 'replace_tenant_data']:
            mode = 'append'
        if scope_ctx.get('scope') == 'all_tenants' and mode == 'replace_tenant_data':
            msg = 'Replace mode is blocked for all-tenants scope. Use append mode.'
            if _wants_import_json():
                return _json_import_error(msg, 400)
            flash(msg, 'danger')
            return redirect(url_for('import_export.import_export_page'))
        # Granular restore: restrict import (and overwrite clearing) to the
        # modules the user selected.  Empty selection = every table in file.
        import_modules = [
            str(x).strip().lower() for x in request.form.getlist('modules') if str(x).strip()
        ]
        allowed_tables = _tables_for_modules(import_modules) or None
        try:
            report, report_name = _run_full_raw_import_bytes(
                file_bytes=file_bytes,
                scope_ctx=scope_ctx,
                mode=mode,
                source_file_name=file.filename,
                allowed_tables=allowed_tables,
            )
            failed = int(report.get('failed') or report.get('errors') or 0)
            warnings = int(report.get('warnings') or 0)
            rolled = bool(report.get('rolled_back'))
            scope_note = f" modules: {', '.join(import_modules)}" if allowed_tables else ''
            if failed:
                msg = (
                    f"Import FAILED — nothing was imported; the database was rolled back "
                    f"to its previous state (mode: {mode}{scope_note}). Failed rows: {failed}. "
                    "Fix the reported cells/rows and import again. Nothing you see below "
                    "was saved; your existing data was NOT changed."
                )
            else:
                outcome = 'complete with warnings' if warnings else 'complete'
                msg = (
                    f"Import {outcome} — 100% of the data was imported ({mode}{scope_note}). "
                    f"Inserted: {report.get('inserted', 0)}, "
                    f"Updated: {report.get('updated', 0)}, Skipped: {report.get('skipped', 0)}, "
                    f"Warnings: {warnings}, Tables: {report.get('tables', 0)}."
                )
            if notes:
                msg = msg + ' ' + ' '.join(notes)
            if _wants_import_json():
                # A partial import is a completed request (HTTP 200) with ok=false,
                # allowing the UI to show the full per-table diagnostic report.
                return jsonify(_import_result_payload(failed == 0, msg, report, {'report_name': report_name}))
            for note in notes:
                flash(note, 'info')
            flash(msg, 'danger' if failed else ('warning' if warnings else 'success'))
            return redirect(url_for('import_export.import_export_page', full_raw_import_report=report_name))
        except Exception as e:
            db.session.rollback()
            msg = f'Literal full import failed: {e}'
            if _wants_import_json():
                return _json_import_error(msg, 400)
            flash(msg, 'danger')
            return redirect(url_for('import_export.import_export_page'))

    if getattr(current_user, 'role', None) == 'root' and scope_ctx.get('scope') == 'all_tenants':
        msg = 'Root all-tenant master import is blocked. Use Literal Full Import for all-tenant restore.'
        if _wants_import_json():
            return _json_import_error(msg, 400)
        flash(msg, 'danger')
        return redirect(url_for('import_export.import_export_page'))

    try:
        run_bytes = file_bytes
        if 'all_business' not in sections:
            sheet_names = _selected_master_sheets(sections)
            if not sheet_names:
                msg = 'Select at least one section for import.'
                if _wants_import_json():
                    return _json_import_error(msg, 400)
                flash(msg, 'warning')
                return redirect(url_for('import_export.import_export_page'))
            run_bytes = _filter_excel_bytes_to_sheets(file_bytes, sheet_names)

        _set_import_actor_context(
            username=getattr(current_user, 'username', None),
            tenant_id=scope_ctx.get('target_tenant_id'),
            role=getattr(current_user, 'role', None),
        )
        g.enforce_tenant = (scope_ctx.get('scope') == 'tenant' and scope_ctx.get('target_tenant_id') is not None)
        g.tenant_id = scope_ctx.get('target_tenant_id')
        report = _run_master_import_bytes(
            file_bytes=run_bytes,
            actor_username=getattr(current_user, 'username', None),
            progress_cb=None,
        )
        failed = int(report.get('failed') or report.get('errors') or 0)
        msg = (
            f"Import {'complete with problems' if failed else 'complete'}. "
            f"Imported: {report.get('imported', 0)}, Updated: {report.get('updated', 0)}, "
            f"Skipped: {report.get('skipped', 0)}, Failed: {failed}."
        )
        if notes:
            msg = msg + ' ' + ' '.join(notes)
        if _wants_import_json():
            return jsonify(_import_result_payload(failed == 0, msg, report))
        for note in notes:
            flash(note, 'info')
        flash(msg, 'warning' if failed else 'success')
    except Exception as e:
        db.session.rollback()
        msg = str(e)
        if _wants_import_json():
            return jsonify(_import_result_payload(False, msg, {})), 400
        flash(msg, 'danger')
    finally:
        _clear_import_actor_context()
    return redirect(url_for('import_export.import_export_page'))


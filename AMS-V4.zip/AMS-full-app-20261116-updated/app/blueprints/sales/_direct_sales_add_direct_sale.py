"""direct_sales — split from sales.py."""
from ._common import *  # noqa
from app.services.edit_policy import resolve_payment_account
import secrets
from sqlalchemy.exc import IntegrityError
from app.services.sales_core import (
    _direct_sale_payload_hash,
    _direct_sale_idem_key_is_recent,
)
from app.services import pricing as _pricing


def _line_rows_for_discount(items):
    """Describe sale lines for the discount allocator.

    ``items`` are the final ``processed_items`` rows (after booking split,
    de-duplication and FIFO expansion), which is exactly what becomes a
    ``DirectSaleItem``.  Weighting on the stored gross keeps the stored shares
    reproducible from the document itself.
    """
    rows = []
    for item in items:
        name = (item.get('product_name') or '').strip()
        qty = float(item.get('qty') or 0)
        rate = float(item.get('price_at_time') or 0)
        rows.append({
            'name': name,
            'qty': qty,
            'rate': rate,
            'gross': _pricing.cents_to_float(_pricing.line_gross_cents(qty, rate)),
            'is_service': bool(is_service_name(name)),
        })
    return rows


def _form_named_discounts(form):
    """Read the per-item amounts chosen in the discount panel.

    Returns ``{item name: amount}``.  Names are the values the panel showed,
    so the selection survives booking splits, duplicate-line merging and FIFO
    lot expansion (which all keep the product name).
    """
    names = form.getlist('item_discount_name[]')
    values = form.getlist('item_discount_value[]')
    named = {}
    for name, raw in zip_longest(names, values, fillvalue=''):
        key = str(name or '').strip()
        if not key:
            continue
        try:
            amount = _pricing.round_money(raw)
        except Exception:
            continue
        if amount <= 0:
            continue
        named[key] = named.get(key, _pricing.ZERO) + amount
    return named


def _resolve_line_discounts(form, items, *, bill_discount, discount_reason):
    """Return ``(bill_discount, reason, per_line_discounts, errors)``.

    The arithmetic itself lives in :mod:`app.services.pricing` so bookings and
    returns resolve their discounts the same way.  This wrapper only adapts the
    request form to it.
    """
    rows = _line_rows_for_discount(items)
    total, shares, errors = _pricing.resolve_line_discounts(
        rows, bill_discount, _form_named_discounts(form)
    )
    return total, discount_reason, [float(share) for share in shares], errors


@bp.route('/add_direct_sale', methods=['POST'])
@login_required
def add_direct_sale():
  try:
    # SQLite's default deferred transactions let concurrent requests both read
    # the same stock before either writes. Serialize sale creation before any
    # stock reads so the second request validates against the first sale's
    # committed stock movement. Other database engines keep their normal locking.
    if db.engine.dialect.name == 'sqlite':
        db.session.rollback()  # discard only request-hook reads/touches
        db.session.connection().exec_driver_sql('BEGIN IMMEDIATE')

    def as_bool(val):
        return str(val).strip().lower() in ['1', 'true', 'on', 'yes']

    def _fail_sale(msg):
        flash(msg, 'danger')
        _stash_direct_sale_form_draft(request.form, mode='add')
        return redirect(url_for('direct_sales_page', resume='add'))

    client_name = request.form.get('client_name', '').strip() or request.form.get('client_code', '').strip()
    driver_name = (request.form.get('driver_name') or '').strip()
    materials_list = request.form.getlist('product_name[]')
    alternate_list = request.form.getlist('alternate_material[]')
    qtys = request.form.getlist('qty[]')
    rates = request.form.getlist('unit_rate[]')
    grn_item_ids = request.form.getlist('grn_item_id[]')
    ignore_items = request.form.getlist('ignore_booking_item[]')
    # amount = float(request.form.get('amount', 0) or 0) # Recalculated below
    paid_amount = _to_float_or_zero(request.form.get('paid_amount', 0))
    
    # Get payment method data
    payment_method = request.form.get('payment_method', 'Cash')
    payment_account_id = request.form.get('payment_account_id')
    bank_name = request.form.get('bank_name', '').strip()
    account_name = request.form.get('account_name', '').strip()
    account_no = request.form.get('account_no', '').strip()
    expected_pay_category = _payment_expected_account_category(payment_method)
    
    if payment_account_id:
        try:
            payment_account_id = int(payment_account_id)
            account = Account.query.get(payment_account_id)
            if account:
                if expected_pay_category and (account.category or '').strip().lower() != expected_pay_category:
                    raise ValueError(f"Selected account must be a {expected_pay_category} account for method '{payment_method}'.")
                bank_name = account.bank_name or ''
                account_name = account.account_holder_name or account.name
                account_no = account.account_number or ''
            else:
                payment_account_id = None
        except (ValueError, TypeError) as ve:
            return _fail_sale(str(ve))
    
    if expected_pay_category != 'bank':
        bank_name = ''

    if paid_amount > 0 and expected_pay_category in ['cash', 'bank'] and not payment_account_id:
        # Auto-pick instead of refusing: a complete sale must not be lost to an
        # empty dropdown.  The chosen account is reported back in the flash.
        auto_id, auto_account = resolve_payment_account(None, payment_method)
        if auto_account is None:
            return _fail_sale(
                f'No active {expected_pay_category} account exists to receive the paid '
                'amount. Add one under Accounts, or set the paid amount to 0 and save.'
            )
        payment_account_id = auto_id
        if expected_pay_category == 'bank':
            bank_name = auto_account.bank_name or ''
        account_name = auto_account.account_holder_name or auto_account.name or ''
        account_no = auto_account.account_number or ''
        flash(
            f'Paid amount auto-posted to {account_name} ({expected_pay_category}) '
            'because no account was selected.',
            'info',
        )

    # If nothing is paid now, do not store payment linkage details.
    if paid_amount <= 0:
        payment_account_id = None
        bank_name = ''
        account_name = ''
        account_no = ''
    if _user_can('can_manage_sales'):
        try:
            discount, discount_reason = _parse_discount_fields(
                request.form.get('discount', 0),
                request.form.get('discount_reason', ''),
                label='Sale discount',
                require_reason=False
            )
        except ValueError as ve:
            return _fail_sale(str(ve))
    else:
        discount = 0
        discount_reason = ''
    manual_bill_raw = request.form.get('manual_bill_no', '').strip()
    manual_bill_no = normalize_manual_bill(manual_bill_raw) if manual_bill_raw else ''
    allow_negative_stock = as_bool(request.form.get('allow_negative_stock'))
    note = request.form.get('note', '').strip()
    create_invoice = as_bool(request.form.get('create_invoice'))
    track_as_cash = as_bool(request.form.get('track_as_cash'))
    delivery_rent = _to_float_or_zero(request.form.get('delivery_rent', 0))
    delivery_allocations, delivery_alloc_err, delivery_alloc_total, delivery_bags_total, delivery_primary_name = _parse_delivery_allocations(request.form)
    if delivery_alloc_err:
        return _fail_sale(delivery_alloc_err)
    if delivery_allocations:
        driver_name = delivery_primary_name or driver_name
        delivery_rent = delivery_alloc_total
    draft_id = _safe_int(request.form.get('draft_id'))

    # Idempotency guard: the form mints a fresh key each time the sale sheet is
    # opened. A double-click / network retry re-submits the same key, so treat
    # it as an already-saved sale instead of creating a second transaction.
    idem_key = (request.form.get('idempotency_key') or '').strip() or None
    payload_hash = _direct_sale_payload_hash(request.form)

    def _redirect_to_prior_sale(prior_sale):
        prior_bill = _direct_sale_default_bill_ref(prior_sale)
        flash('This sale was already saved (duplicate submission ignored).', 'info')
        return redirect(url_for(
            'direct_sales_page',
            download_bill=prior_bill,
            download_src='direct_sale',
            download_src_id=prior_sale.id,
            download_client_code=prior_sale.client_code,
            download_client_name=prior_sale.client_name,
        ))

    if idem_key:
        prior_sale = DirectSale.query.filter_by(idempotency_key=idem_key).order_by(DirectSale.id.desc()).first()
        if prior_sale:
            # The key must be bound to the payload it was minted for.  The
            # same key carrying different content is NOT a replay — silently
            # dropping the second sale loses a real transaction.
            stored_hash = getattr(prior_sale, 'idempotency_payload_hash', None)
            if stored_hash and stored_hash != payload_hash:
                return _fail_sale(
                    'This form token was already used for a different sale. '
                    'Reload the page and submit again.'
                )
            return _redirect_to_prior_sale(prior_sale)

    if not idem_key:
        # Server-side replay guard for keyless submissions: the backend must
        # not depend on the JS-minted key.  A deterministic payload
        # fingerprint rejects an immediate double-post of the same sale while
        # still allowing a genuine identical repeat order later (the fresh
        # submission gets a disambiguated fingerprint key).
        fp = f'FP-{payload_hash[:40]}'
        prior_fp = DirectSale.query.filter_by(idempotency_key=fp).order_by(DirectSale.id.desc()).first()
        if prior_fp and getattr(prior_fp, 'idempotency_payload_hash', None) == payload_hash \
                and _direct_sale_idem_key_is_recent(prior_fp):
            return _redirect_to_prior_sale(prior_fp)
        if prior_fp:
            idem_key = f'FP-{payload_hash[:32]}-{secrets.token_hex(3)}'
        else:
            idem_key = fp

    # Check for global setting
    settings = Settings.query.first()
    global_negative_stock_allowed = settings.allow_global_negative_stock if settings else False

    photo_path = save_photo(request.files.get('photo'))
    photo_url = request.form.get('photo_url', '').strip()

    category_input = request.form.get('category', '').strip()
    category = normalize_sale_category(category_input)
    sale_date_raw = request.form.get('sale_date', '').strip()
    sale_posted_at = resolve_posted_datetime(sale_date_raw, fallback_dt=pk_now())
    # Held drafts must use the final save time, not the original hold time.
    if draft_id:
        sale_posted_at = pk_now()

    if not driver_name:
        return _fail_sale('Delivery person is required for sale dispatch.')
    if not delivery_allocations:
        get_or_create_delivery_person(driver_name)
    if delivery_rent < 0:
        return _fail_sale('Delivery rent cannot be negative.')
    # Find client by name or code
    client = get_client_by_input(client_name)

    if client:
        client_name = client.name

    # 1. Calculate Booking Balances
    booking_balances = {}
    if client:
        booking_ids = [
            b.id for b in Booking.query.filter(
                func.lower(func.trim(Booking.client_name)) == func.lower(func.trim(client.name)),
                Booking.is_void == False
            ).all()
        ]
        booked_totals = {}
        if booking_ids:
            for item in BookingItem.query.filter(BookingItem.booking_id.in_(booking_ids)).all():
                key = _material_norm_key(item.material_name)
                if not key:
                    continue
                booked_totals[key] = booked_totals.get(key, 0) + float(item.qty or 0)

        delivered_totals = {}
        entries = Entry.query.filter(
            or_(Entry.client_code == client.code,
                func.lower(func.trim(Entry.client)) == func.lower(func.trim(client.name))),
            Entry.type == 'OUT',
            Entry.is_void == False,
            # Exclude Direct Sales that are NOT Booking Deliveries (i.e. Cash/Credit sales)
            # This prevents regular sales from reducing the booking balance
            not_(and_(Entry.nimbus_no == 'Direct Sale', Entry.client_category != 'Booking Delivery'))
        ).all()
        for entry in entries:
            key = _material_norm_key(entry.booked_material or entry.material)
            if not key:
                continue
            delivered_totals[key] = delivered_totals.get(key, 0) + float(entry.qty or 0)

        # Include returned booked material quantities so that after a Booked Return,
        # the available booked material is correctly restored: available = booked - delivered + returned
        returned_booked_totals = {}
        return_entries = Entry.query.filter(
            or_(Entry.client_code == client.code,
                func.lower(func.trim(Entry.client)) == func.lower(func.trim(client.name))),
            Entry.type == 'IN',
            Entry.is_void == False,
            Entry.nimbus_no == 'Material Return',
            Entry.transaction_category == 'Booked Return'
        ).all()
        for entry in return_entries:
            key = _material_norm_key(entry.material)
            if not key:
                continue
            returned_booked_totals[key] = returned_booked_totals.get(key, 0) + float(entry.qty or 0)

        for mat_in in set(materials_list):
            try:
                # Services resolve here too: this is the booking pool
                # (booked - delivered + returned). Filtering them out would
                # make booked rent unconsumable.
                _kind, mat_obj = resolve_transaction_item(typed_text=mat_in, require_active=True)
            except ValueError:
                continue
            if not mat_obj:
                continue
            key = _material_norm_key(mat_obj.name)
            booking_balances[key] = max(0, booked_totals.get(key, 0) - delivered_totals.get(key, 0) + returned_booked_totals.get(key, 0))

    # 2. Process Items (Auto-Split Booking vs Sale)
    processed_items = []
    calculated_amount = 0
    missing_rate_non_booked = []

    material_ids = request.form.getlist('material_id[]')
    service_ids = request.form.getlist('service_id[]')
    alternate_ids = request.form.getlist('alternate_material_id[]')

    for idx, mat in enumerate(materials_list):
        qty_val = qtys[idx] if idx < len(qtys) else ''
        rate_val = rates[idx] if idx < len(rates) else ''
        mat_name_in = str(mat or '').strip()
        mid = material_ids[idx] if idx < len(material_ids) else ''
        sid = service_ids[idx] if idx < len(service_ids) else ''
        qty = _to_float_or_zero(qty_val)
        if not mat_name_in and not str(mid or '').strip() and qty <= 0:
            continue
        try:
            # service_id is a separate channel on purpose: service ids overlap
            # material ids, so a service id must never reach the unqualified
            # Material PK lookup.
            _kind, mat_obj = resolve_transaction_item(
                service_id=sid,
                material_id=mid,
                typed_text=mat_name_in,
                require_active=True,
            )
        except ValueError as ve:
            return _fail_sale(str(ve))
        if not mat_obj or qty <= 0:
            continue
        mat_name = mat_obj.name
        rate = _to_float_or_zero(rate_val)

        ignore_item = False
        if idx < len(ignore_items):
            ignore_item = str(ignore_items[idx] or '').strip().lower() in ['1', 'true', 'on', 'yes']
        # Cash / credit / open khata are chargeable sales — never silently
        # consume booking qty (that made amount=0 and voided stock).
        if category in ['Cash', 'Credit Customer', 'Open Khata']:
            ignore_item = True
        mat_key = _material_norm_key(mat_name)
        balance = 0 if ignore_item else booking_balances.get(mat_key, 0)
        qty_booking = 0
        qty_sale = qty

        alt_input = (alternate_list[idx] if idx < len(alternate_list) else '').strip()
        alt_mid = alternate_ids[idx] if idx < len(alternate_ids) else ''
        alt_obj = None
        if alt_input or str(alt_mid or '').strip():
            if _kind == 'service' or is_service_name(mat_name):
                return _fail_sale(f'Alternate material cannot be used for service "{mat_name}".')
            if alt_input and is_service_name(alt_input):
                return _fail_sale(f'Service "{alt_input}" cannot be used as an alternate material.')
            try:
                alt_obj = resolve_transaction_material(
                    material_id=alt_mid,
                    typed_text=alt_input,
                    require_active=True,
                )
            except ValueError as ve:
                return _fail_sale(str(ve))
            if not alt_obj:
                return _fail_sale(MATERIAL_NOT_SELECTED_MSG)
            if is_service_name(alt_obj.name):
                return _fail_sale(f'Service "{alt_obj.name}" cannot be used as an alternate material.')

        if balance > 0:
            qty_booking = min(qty, balance)
            qty_sale = qty - qty_booking
            booking_balances[mat_key] -= qty_booking

        if alt_input and (ignore_item or qty_booking <= 0):
            return _fail_sale(f'Alternate material is only allowed for booked items. "{mat_name}" has no booking balance.')

        # The material physically delivered for this row.  When an alternate
        # is supplied against a booked material, every slice of the row
        # (booking fulfilment AND any excess beyond the booking balance) is
        # the alternate material — no quantity of the originally booked
        # material leaves the store.
        delivered_mat = alt_obj.name if alt_obj else mat_name
        delivered_obj = alt_obj or mat_obj

        if qty_booking > 0:
            processed_items.append({
                'product_name': delivered_mat,
                'booked_material': mat_name,
                'qty': qty_booking,
                'price_at_time': 0,
                'grn_item_id': None,  # Booking items don't need GRN tracking
                'is_booking': True,
                'is_alternate': bool(alt_obj and delivered_mat != mat_name)
            })

        if qty_sale > 0:
            if rate <= 0:
                rate = float(delivered_obj.unit_price or 0)
            if rate <= 0:
                missing_rate_non_booked.append(delivered_mat)
            grn_item_id = None
            if idx < len(grn_item_ids) and grn_item_ids[idx]:
                try:
                    grn_item_id = int(grn_item_ids[idx])
                except (ValueError, TypeError):
                    grn_item_id = None
            # A form-selected GRN lot belongs to the originally typed material;
            # when an alternate was supplied the excess ships the alternate, so
            # let FIFO pick lots of the delivered material instead.
            if alt_obj:
                grn_item_id = None
            processed_items.append({
                'product_name': delivered_mat,
                'booked_material': None,
                'qty': qty_sale,
                'price_at_time': rate,
                'grn_item_id': grn_item_id,
                'is_booking': False,
                'is_alternate': False
            })
            calculated_amount += (qty_sale * rate)

    if not processed_items:
        return _fail_sale('No valid material items were captured. Add at least one item with qty > 0.')

    processed_items = _dedupe_direct_sale_items(processed_items)
    processed_items = _expand_chargeable_items_fifo(
        processed_items,
        as_of_dt=(sale_posted_at.date() if sale_posted_at else None),
    )

    if missing_rate_non_booked:
        mats = ', '.join(sorted(set(missing_rate_non_booked)))
        return _fail_sale(f'Rate is required for non-booked items: {mats}')

    # 3. Stock Validation (Only for non-booked items + alternate fulfilments)
    # Aggregate required quantities first to prevent cumulative overrun.
    # Alternate booking fulfilments physically ship the DELIVERED material
    # (item['product_name']), so stock must be validated against it — never
    # against the originally booked material, which stays in the store.
    # Both maps are keyed by the delivered material and validated together so
    # a row split into booking + excess slices checks its combined quantity.
    required_stock = {}
    required_alt_stock = {}
    for item in processed_items:
        if not item['is_booking']:
            mat = item['product_name']
            required_stock[mat] = required_stock.get(mat, 0) + item['qty']
        elif item.get('is_alternate'):
            mat = item['product_name']
            required_alt_stock[mat] = required_alt_stock.get(mat, 0) + item['qty']

    required_total_stock = dict(required_stock)
    for mat, req_qty in required_alt_stock.items():
        required_total_stock[mat] = required_total_stock.get(mat, 0) + req_qty

    for mat, req_qty in required_total_stock.items():
        if is_service_name(mat):
            continue
        mat_obj = Material.query.filter_by(name=mat).first()
        if mat_obj:
            available = mat_obj.total or 0
            if not allow_negative_stock and not global_negative_stock_allowed and available < req_qty:
                detail = 'Non-booked'
                if required_alt_stock.get(mat):
                    detail = 'Alternate delivery' if not required_stock.get(mat) else 'Non-booked + Alternate delivery'
                raise ValueError(f"Insufficient stock for {mat}. Available: {available}, Required: {req_qty} ({detail}). Enable 'Allow Negative Stock' or global setting to bypass.")

    total_qty = sum(_to_float_or_zero(item.get('qty')) for item in processed_items)
    if delivery_allocations and delivery_bags_total > (total_qty + 0.0001):
        return _fail_sale('Total delivery bags cannot exceed total material quantity for this sale.')

    # Compute whether this client has any active booking balance (across all materials).
    # Available booked material = booked - delivered + returned.
    has_client_booking_balance = False
    if client:
        norm_name = (client.name or '').strip().lower()
        booked_rows_all = db.session.query(
            BookingItem.material_name,
            func.sum(BookingItem.qty)
        ).join(Booking, BookingItem.booking_id == Booking.id).filter(
            Booking.is_void == False,
            func.lower(func.trim(Booking.client_name)) == norm_name
        ).group_by(BookingItem.material_name).all()
        if booked_rows_all:
            booked_map_all = {}
            for mat, qty in booked_rows_all:
                key = _material_norm_key(mat)
                if key:
                    booked_map_all[key] = booked_map_all.get(key, 0) + float(qty or 0)
            delivered_rows_all = db.session.query(
                func.coalesce(Entry.booked_material, Entry.material),
                func.sum(Entry.qty)
            ).filter(
                Entry.type == 'OUT',
                Entry.is_void == False,
                or_(
                    Entry.client_code == client.code,
                    func.lower(func.trim(Entry.client)) == norm_name
                ),
                not_(and_(Entry.nimbus_no == 'Direct Sale', Entry.client_category != 'Booking Delivery'))
            ).group_by(func.coalesce(Entry.booked_material, Entry.material)).all()
            delivered_map_all = {}
            for mat, qty in delivered_rows_all:
                key = _material_norm_key(mat)
                if key:
                    delivered_map_all[key] = delivered_map_all.get(key, 0) + float(qty or 0)
            # Also include returned booked material quantities
            returned_booked_rows = db.session.query(
                func.trim(Entry.material),
                func.sum(Entry.qty)
            ).filter(
                Entry.type == 'IN',
                Entry.is_void == False,
                Entry.nimbus_no == 'Material Return',
                Entry.transaction_category == 'Booked Return',
                or_(
                    Entry.client_code == client.code,
                    func.lower(func.trim(Entry.client)) == norm_name
                )
            ).group_by(func.trim(Entry.material)).all()
            returned_booked_map = {}
            for mat, qty in returned_booked_rows:
                key = _material_norm_key(mat)
                if key:
                    returned_booked_map[key] = returned_booked_map.get(key, 0) + float(qty or 0)
            has_client_booking_balance = any(
                booked_qty - delivered_map_all.get(mat_key, 0) + returned_booked_map.get(mat_key, 0) > 0
                for mat_key, booked_qty in booked_map_all.items()
            )

    # 4. Determine Final Category & Amount
    amount = calculated_amount
    all_booking = all(item['is_booking'] for item in processed_items)
    any_booking = any(item['is_booking'] for item in processed_items)
    category_input_l = category.lower()

    # Enforce selected sale-type policy.
    if category_input_l in ['booking delivery', 'mixed transaction', 'credit customer'] and not client:
        return _fail_sale('Select a registered client from the client list for this sale type.')

    if category == 'Booking Delivery':
        if not has_client_booking_balance or not all_booking:
            return _fail_sale('Booked Sale is only for clients with booking balance and booked materials only.')
        # Booked dispatch is fulfillment only — never a credit/due sale.
        amount = 0
        paid_amount = 0
        discount = 0
        create_invoice = False
        track_as_cash = False
    elif category == 'Mixed Transaction':
        if not has_client_booking_balance or not any_booking:
            return _fail_sale('Booked + Credit is only for clients with booking balance and must include booked items.')
        if all_booking or amount <= 0:
            return _fail_sale('Booked + Credit must include a non-booked credit portion with amount > 0.')
    elif category == 'Credit Customer':
        # Due sale can be used for any registered client; it must remain pure chargeable.
        if any_booking:
            return _fail_sale('Credit Sale cannot include booked-material fulfillment.')
    elif category == 'Open Khata':
        # Open Khata is for unregistered walk-in style credit.
        if client and client.code != OPEN_KHATA_CODE:
            return _fail_sale('Open Khata is only for unregistered customers (not selected from client list).')
    else:
        category = 'Cash'

    # Booking Delivery can have zero-priced dispatch (amount=0) while still allowing
    # a financial discount adjustment in client ledger.
    if category != 'Booking Delivery' and discount > (amount + 0.01):
        return _fail_sale('Discount cannot exceed total amount.')

    # ------------------------------------------------------------------ #
    # Per-line discount: split ONCE, here, and store it on the line.
    #
    # The discount panel may send a typed amount per selected item
    # (``item_discount_name[]`` / ``item_discount_value[]``).  Anything left
    # over is allocated from the bill-level amount.  Both paths go through
    # app.services.pricing, which works in whole paisa with largest-remainder
    # rounding, so the shares always add back to the discount exactly and no
    # repeating decimal ever reaches a report.
    # ------------------------------------------------------------------ #
    discount, discount_reason, item_discount_shares, discount_errors = _resolve_line_discounts(
        request.form,
        processed_items,
        bill_discount=discount,
        discount_reason=discount_reason,
    )
    if discount_errors:
        return _fail_sale(discount_errors[0])
    if category == 'Booking Delivery':
        # Booked dispatch is fulfilment only; it carries no sale discount.
        discount = 0.0
        discount_reason = ''
        item_discount_shares = [0.0] * len(processed_items)

    # A cash bill short of its total used to be rejected outright, losing the
    # operator's whole entry.  Post it with the shortfall as an unpaid balance
    # instead and tell them to collect it from the ledger.
    if category == 'Cash' and (paid_amount + discount) < (amount - 0.01):
        shortfall = round((amount - discount) - paid_amount, 2)
        if shortfall > 0:
            flash(
                f'Cash sale saved with Rs. {shortfall:,.2f} left unpaid — '
                'collect it from the client ledger.',
                'warning',
            )
    
    # Auto bill is enough when no manual number is provided.

    # Validation: Manual bill must be unique
    if manual_bill_no:
        conflict = find_bill_conflict(manual_bill_no)
        if conflict:
            return _fail_sale(f"Bill No '{manual_bill_no}' already exists. Please open the existing bill and edit it instead.")

    # Handle Cash category (Manual overrides)
    if category == 'Cash':
        manual_client_name = request.form.get('manual_client_name', '').strip()
        if manual_client_name:
            client_name = manual_client_name
    elif category == 'Open Khata':
        manual_client_name = request.form.get('manual_client_name', '').strip()
        if not manual_client_name:
            return _fail_sale('Open Khata requires manual customer name.')
        client_name = manual_client_name
        create_invoice = False
        track_as_cash = False
        # Materialise the shared OPEN-KHATA master row so the receivable is
        # visible in payables/API/CSV and can be settled through payments.
        try:
            from app.services.schema import ensure_open_khata_client
            ensure_open_khata_client()
        except Exception:
            pass

    # Force manual bill requirement for non-cash sales if not provided
    if category != 'Cash' and not manual_bill_no and not create_invoice:
        # We allow it but it will be auto-generated or marked as system bill
        pass

    hv = request.form.get('has_bill')
    has_bill = True if hv is None else hv in ['on', '1', 'true', 'True']

    pending_amount = max(0.0, amount - discount - paid_amount)
    sale_client_code = client.code if client else None
    if category == 'Open Khata' and not sale_client_code:
        sale_client_code = OPEN_KHATA_CODE
    rent_rec = _rent_reconciliation_from_items(
        processed_items,
        delivery_rent_cost=delivery_rent,
        client_name=client_name,
        client_code=sale_client_code
    )

    if (
        category in ['Mixed Transaction', 'Credit Customer', 'Open Khata']
        and pending_amount <= 0
        and discount <= 0
    ):
        return _fail_sale('This sale type is for credit only. Use Cash Sale if fully paid.')

    # Handle invoice creation
    inv = None
    invoice_no = None
    if create_invoice:
        if manual_bill_no:
            invoice_no = manual_bill_no
            is_manual = True
        else:
            # Invoice without manual bill no (auto)
            invoice_no = f"INV-{pk_now().strftime('%Y%m%d%H%M%S')}"
            is_manual = False

        existing_global = Invoice.query.filter_by(invoice_no=invoice_no).first()
        if existing_global:
            if is_manual:
                return _fail_sale(f'Invoice number "{invoice_no}" is already used. Please use a different number.')
            # Auto invoice: ensure uniqueness instead of reusing/updating
            while Invoice.query.filter_by(invoice_no=invoice_no).first():
                invoice_no = f"INV-{pk_now().strftime('%Y%m%d%H%M%S')}-{secrets.token_hex(2).upper()}"

        balance = max(0.0, amount - discount - paid_amount)
        status = 'PAID' if balance <= 0 else ('PARTIAL' if paid_amount > 0 else 'OPEN')

        inv = Invoice(client_code=sale_client_code,
                      client_name=client.name if client else client_name,
                      invoice_no=invoice_no,
                      is_manual=is_manual,
                      date=sale_posted_at.date(),
                      total_amount=amount,
                      # Note: Invoice model might not have discount column, so we reflect it in balance
                      balance=balance,
                      status=status,
                      is_cash=track_as_cash,
                      note=note,
                      created_at=sale_posted_at.strftime('%Y-%m-%d %H:%M'),
                      created_by=current_user.username)
        db.session.add(inv)
        db.session.flush()

    auto_bill_no = get_next_bill_no(AUTO_BILL_NAMESPACES['DIRECT_SALE'])

    sale = DirectSale(idempotency_key=idem_key,
                      idempotency_payload_hash=payload_hash,
                      client_name=client_name,
                      client_code=sale_client_code,
                      amount=amount,
                      paid_amount=paid_amount,
                      discount=discount,
                      discount_reason=discount_reason,
                      manual_bill_no=manual_bill_no,
                      auto_bill_no=auto_bill_no,
                      photo_path=photo_path,
                      photo_url=photo_url,
                      category=category,
                      note=note,
                      driver_name=driver_name,
                      rent_item_revenue=rent_rec['rent_item_revenue'],
                      delivery_rent_cost=rent_rec['delivery_rent_cost'],
                      rent_variance_loss=rent_rec['rent_variance_loss'],
                      payment_method=payment_method,
                      payment_account_id=payment_account_id,
                      bank_name=bank_name,
                      account_name=account_name,
                      account_no=account_no,
                      date_posted=sale_posted_at)
    db.session.add(sale)
    db.session.flush()

    if create_invoice and inv:
        sale.invoice_id = inv.id

    if delivery_allocations:
        for alloc in delivery_allocations:
            db.session.add(SaleDeliveryPerson(
                sale_id=sale.id,
                delivery_person_id=alloc['delivery_person'].id,
                bags_delivered=alloc['bags_delivered'],
                rent_amount=alloc['rent_amount'],
                created_at=sale_posted_at
            ))
    else:
        dp = get_or_create_delivery_person(driver_name)
        if dp:
            db.session.add(SaleDeliveryPerson(
                sale_id=sale.id,
                delivery_person_id=dp.id,
                bags_delivered=0,
                rent_amount=delivery_rent,
                created_at=sale_posted_at
            ))

    # Create DirectSaleItems and Entries
    now = sale_posted_at
    sale_item_records = []
    for line_index, item in enumerate(processed_items):
        # Per-line discount resolved above (whole paisa, sums to the bill
        # discount exactly).  Reports read this column instead of dividing the
        # bill discount again.
        line_discount = (
            item_discount_shares[line_index]
            if line_index < len(item_discount_shares) else 0.0
        )
        line_discount_kind = 'manual' if _form_named_discounts(request.form) else 'allocated'
        if line_discount <= 0:
            line_discount_kind = 'none'
        # Create Sale Item
        dsi = DirectSaleItem(sale_id=sale.id,
                           product_name=item['product_name'],
                           qty=item['qty'],
                           price_at_time=item['price_at_time'],
                           grn_item_id=item.get('grn_item_id'),
                           cost_rate_at_sale=item.get('cost_rate_at_sale'),
                           discount=line_discount,
                           discount_kind=line_discount_kind,
                           discount_reason=(discount_reason or None) if line_discount > 0 else None)
        db.session.add(dsi)
        sale_item_records.append((dsi, item))

        # Create Entry
        ledger_bill_ref = manual_bill_no or (inv.invoice_no if (create_invoice and inv) else (sale.auto_bill_no or ("UNBILLED-" + str(sale.id))))

        # Determine category per item for mixed transactions
        item_category = category
        if item['is_booking']:
            item_category = 'Booking Delivery'
        elif category == 'Mixed Transaction':
            item_category = 'Credit Customer'
        elif category == 'Booking Delivery': # Fallback if main cat is Booking but this item isn't (shouldn't happen with split logic)
            item_category = 'Credit Customer'

        entry_note = note
        if item.get('is_booking') and item.get('is_alternate') and item.get('booked_material'):
            extra = f"Alternate Material for Booked Sale (Original: {item['booked_material']})"
            entry_note = f"{note} | {extra}" if note else extra
        entry = Entry(date=now.strftime('%Y-%m-%d'),
                      time=now.strftime('%H:%M:%S'),
                      type='OUT',
                      material=item['product_name'],
                      booked_material=(item.get('booked_material') if item.get('is_alternate') else None),
                      client=client_name,
                      client_code=sale_client_code,
                      qty=item['qty'],
                      bill_no=ledger_bill_ref,
                      nimbus_no='Direct Sale',
                      created_by=current_user.username,
                      client_category=item_category,
                      transaction_category=('Unbilled' if category == 'Cash' else 'Billed'),
                      driver_name=driver_name,
                      note=entry_note,
                      is_alternate=bool(item.get('is_alternate')))
        _stamp_source(entry, 'sales', 'direct_sale', sale.id, ledger_bill_ref, item_category)
        db.session.add(entry)

    # Stock is NOT decremented per item here. finalize_transaction() below runs
    # rebuild_direct_sale_effects(rebuild_stock=True) → _rebuild_material_totals(),
    # which recomputes every material total from the freshly flushed entries in a
    # single pass.  The old per-item Material.query + `total -= qty` was both
    # redundant (immediately overwritten) and an N+1 query per sale line.
    db.session.flush()
    _apply_booking_allocations_for_sale(sale, sale_item_records)
    _apply_grn_allocations_for_sale(sale, sale_item_records)

    # finalize_transaction() → rebuild_direct_sale_effects() already synchronises
    # pending bill, delivery rent, waive-off and accounts for this sale, then
    # recalculates stock — all inside the same DB transaction.  Calling those
    # four syncs here too was redundant duplicate work per submit.
    finalize_transaction('sales', sale.id)

    try:
        db.session.commit()
    except IntegrityError:
        # A concurrent identical submission won the unique idempotency-key
        # race (uq_direct_sale_idempotency_key).  That is a replay, not an
        # error: point the user at the already-saved sale.
        db.session.rollback()
        try:
            prior_sale = DirectSale.query.filter_by(idempotency_key=idem_key).order_by(DirectSale.id.desc()).first()
            if prior_sale:
                return _redirect_to_prior_sale(prior_sale)
        except Exception:
            pass
        raise
    if draft_id:
        try:
            draft_row = DirectSaleDraft.query.get(draft_id)
            if draft_row:
                db.session.delete(draft_row)
                db.session.commit()
        except Exception:
            db.session.rollback()
    msg = 'Direct sale added successfully'
    if create_invoice and inv:
        msg += f" â€” Invoice: {inv.invoice_no}"
    flash(msg, 'success')
  except ValueError as ve:
    # Validation messages (insufficient stock, missing rate, closed period,
    # …) are written for users — show them verbatim.
    db.session.rollback()
    flash(str(ve), 'danger')
    _stash_direct_sale_form_draft(request.form, mode='add')
    return redirect(url_for('direct_sales_page', resume='add'))
  except Exception as exc:
    db.session.rollback()
    # Never surface SQL/driver details to the user; log the full traceback
    # server-side instead.
    logging.getLogger('sales').exception('Direct sale save failed')
    flash(f'Error processing sale: {exc or "the sale could not be saved. Please check the details and try again."}', 'danger')
    _stash_direct_sale_form_draft(request.form, mode='add')
    return redirect(url_for('direct_sales_page', resume='add'))

  # Success redirect
  if manual_bill_no:
      bill_ref = manual_bill_no
  elif create_invoice and inv:
      bill_ref = inv.invoice_no
  elif sale.auto_bill_no:
      bill_ref = sale.auto_bill_no
  else:
      bill_ref = f"CSH-{sale.id}" if category == 'Cash' else f"DS-{sale.id}"

  return redirect(url_for(
      'direct_sales_page',
      download_bill=bill_ref,
      download_src='direct_sale',
      download_src_id=sale.id,
      download_client_code=sale_client_code,
      download_client_name=sale.client_name
  ))


"""Domain service module — extracted from legacy ERP core."""
from __future__ import annotations

import os
import io
import secrets
import json
import calendar
import threading
import time
import smtplib
import shutil
import sqlite3
import zipfile
import urllib.request
import urllib.error
import re
import logging
import importlib
from itertools import zip_longest
from urllib.parse import unquote
from contextlib import redirect_stderr
from email.message import EmailMessage
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from datetime import datetime, date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo
from sqlalchemy import func, case, text, or_, and_, exists, not_
from sqlalchemy.orm import selectinload
from types import SimpleNamespace
from flask import (
    current_app as app,
    render_template, request, redirect, url_for, flash, jsonify,
    send_file, Response, make_response, send_from_directory,
    got_request_exception, abort, session, g,
)
from flask_login import login_user, login_required, logout_user, current_user

from models import *
from utils.audit import audit_log
from utils.reconciliation import run_auto_reconcile
from cash_flow_reconciliation_helpers import (
    create_reconciliation, update_reconciliation, delete_reconciliation,
    get_reconciliation_history, migrate_legacy_record,
)
from app.services import constants as C
from app.services import state

# Rebind constants used as bare names
OPEN_KHATA_CODE = C.OPEN_KHATA_CODE
OPEN_KHATA_NAME = C.OPEN_KHATA_NAME
PK_TZ = C.PK_TZ
SALE_CATEGORY_CHOICES = C.SALE_CATEGORY_CHOICES
_SALE_CATEGORY_ALIASES = C._SALE_CATEGORY_ALIASES
DOMAIN_WIPE_REGISTRY = C.DOMAIN_WIPE_REGISTRY
USER_PERMISSION_DEFAULTS = C.USER_PERMISSION_DEFAULTS
PERMISSION_LEGACY_FALLBACKS = C.PERMISSION_LEGACY_FALLBACKS
ENDPOINT_PERMISSION_MAP = C.ENDPOINT_PERMISSION_MAP
AUTO_BILL_NS_DEFAULT = C.AUTO_BILL_NS_DEFAULT
AUTO_BILL_NAMESPACES = C.AUTO_BILL_NAMESPACES
EDITABLE_USER_PERMISSION_FIELDS = C.EDITABLE_USER_PERMISSION_FIELDS
basedir = C.basedir
legacy_instance_dir = C.legacy_instance_dir
legacy_db_path = C.legacy_db_path
db_path = C.db_path
_DB_HEALTH_SNAPSHOT_PATH = C._DB_HEALTH_SNAPSHOT_PATH
_max_upload_mb = C._max_upload_mb
_AUTO_BACKUP_ENABLED = C._AUTO_BACKUP_ENABLED
_WIPE_BACKUP_ENABLED = C._WIPE_BACKUP_ENABLED
_AUTO_RECONCILE_ENABLED = C._AUTO_RECONCILE_ENABLED
_AUTO_RECONCILE_FIX = C._AUTO_RECONCILE_FIX
_AUTO_RECONCILE_INTERVAL_SEC = C._AUTO_RECONCILE_INTERVAL_SEC
_AUTO_RECONCILE_TOL = C._AUTO_RECONCILE_TOL
_ALLOW_EMPTY_DB = C._ALLOW_EMPTY_DB
_ALLOW_DB_DROP = C._ALLOW_DB_DROP
_DB_HEALTH_DROP_RATIO = C._DB_HEALTH_DROP_RATIO
_DB_HEALTH_DROP_MIN = C._DB_HEALTH_DROP_MIN
_DB_HEALTH_MIN_BYTES = C._DB_HEALTH_MIN_BYTES

def require_root():
    """
    Multi-tenant/root features are disabled in single-store mode.
    Keep this guard to avoid exposing legacy endpoints.
    """
    abort(404)


def _user_can(permission_name):
    if not current_user.is_authenticated:
        return False
    if current_user.role in ('admin', 'root'):
        return True

    default_value = USER_PERMISSION_DEFAULTS.get(permission_name, False)
    val = getattr(current_user, permission_name, None)
    if val is None:
        legacy_name = PERMISSION_LEGACY_FALLBACKS.get(permission_name)
        if legacy_name:
            legacy_val = getattr(current_user, legacy_name, None)
            if legacy_val is not None:
                return bool(legacy_val)
        return bool(default_value)
    return bool(val)


def _can_manage_categories():
    return current_user.is_authenticated and _user_can('can_manage_materials')


def load_user(user_id):
    """Resolve the session user id to a User row.

    Flask-Login calls this on every request, and any exception raised here
    becomes an HTTP 500 on every page *after* login — with a stale cookie the
    user cannot even reach the login page again.  A session id that is not a
    valid integer (older cookie format, tampered cookie) or a transient DB
    error must simply mean "not logged in".

    A *transient* error (SQLite "database is locked" while a backup, import or
    report holds the write lock) is retried first: giving up immediately logs
    the user out and bounces every page to ``/login`` — which is exactly what
    a shop sees when a long job overlaps normal work.

    A suspended account must not be restored from either the session cookie or
    the remember-me cookie. Flask-Login calls this loader on every request, so
    reusing User.is_active here enforces the current database status without
    changing the concurrent-login policy or logging out other active users.
    """
    try:
        uid = int(str(user_id).strip())
    except (TypeError, ValueError):
        logging.getLogger("auth").warning("Ignoring malformed session user id %r", user_id)
        return None

    from app.services.errors import is_transient_db_error

    delays = (0.5, 1.5)
    for attempt in range(len(delays) + 1):
        try:
            user = db.session.get(User, uid)
            if user is not None and not user.is_active:
                return None
            return user
        except Exception as exc:
            try:
                db.session.rollback()
            except Exception:
                pass
            if attempt < len(delays) and is_transient_db_error(exc):
                logging.getLogger("auth").warning(
                    "User %s lookup hit a busy database; retrying in %.1fs",
                    uid,
                    delays[attempt],
                )
                time.sleep(delays[attempt])
                continue
            logging.getLogger("auth").exception("Could not load user id %s", uid)
            return None
    return None


def _permissions_from_request_form():
    return {field: (field in request.form) for field in EDITABLE_USER_PERMISSION_FIELDS}



# Panel Overhaul, Posts Workflow & Theme Platform — Professional-Grade Roadmap

Status: proposal · Target: `0.2.0 → 1.0.0` · Owner: AMS
Scope: admin panel shell, posts/pages workflow, appearance hub, theme architecture, theme store.
(The theme store was taken back out in 0.9.0: the CMS ships no themes — see the note on Phase 5.)

---

## 1. Where the product stands today

The CMS is in unusually good shape for its size (~7,000 lines, no framework, no build step beyond
esbuild). What already works and should not be regressed:

- **Security is real**: PBKDF2 sessions, CSRF + Origin checks on every POST, rate limiting, role
  model, sanitizer for non-admin HTML, sandboxed media responses.
- **Cache story is coherent**: generation-stamped KV keys, every mutation bumps the generation.
- **Deployment story is honest**: one Worker or one Node process, D1 + KV, no vendor SDK sprawl.
- **Tests exist and are behavioural** (38 end-to-end/template cases plus 39 panel cases).
- **Themes are data, never code** — the template engine cannot execute anything.

The problem is not quality, it is **ceiling**. The panel was built screen-by-screen, so every route
hand-writes its own markup against one 31 KB CSS string; and the theme system was designed as
"six templates + one CSS blob", which is a *starter* theme format, not a *theme platform*.

### Findings that hold the product back

Severity: P0 = blocks professional use · P1 = visible quality gap · P2 = polish.

#### A. Posts & pages workflow

| # | Finding | Where | Sev |
|---|---|---|---|
| A1 | No autosave, no unsaved-changes warning. Closing a tab loses a draft silently. | `routes/admin/content.ts` | P0 |
| A2 | No revisions. One bad save overwrites published prose with no recovery. | schema | P0 |
| A3 | No edit lock / conflict detection. Two editors → last write wins, no warning. | `content.post('…/save')` | P0 |
| A4 | Visual editor is `contenteditable` + `document.execCommand` (deprecated; inconsistent paste, no block model). | `EDITOR_JS` | P1 |
| A5 | Inserting an image means typing a URL (`data-ask="Image URL"`). Media library has no picker into the editor. | `EDITOR_JS`, `media.ts` | P1 |
| A6 | Featured image is a native `<select>` of 200 filenames. No thumbnail grid. | editor post fields | P1 |
| A7 | No quick edit, no duplicate, no inline title edit, no row thumbnails in Posts/Pages list. | `postListHref` table | P1 |
| A8 | No sticky posts, no page ordering (menu position is the only order, and it is menu-scoped). | schema | P1 |
| A9 | No "last edited by" / no edit history surfaced. | `content` table | P2 |
| A10 | Preview is `?preview=1` only — no "preview in another theme", no device widths. | `public.ts` | P1 |
| A11 | Scheduled posts are a filter tab, not a queue you can see at a glance with countdown. | posts list | P2 |

#### B. Theme architecture

| # | Finding | Where | Sev |
|---|---|---|---|
| B1 | A theme is `templates{}` + one `css` string, capped at **1 MB** in a **single D1 row**. No images, fonts, per-theme JS, or favicons. | `lib/themes.ts` (`MAX_BUNDLE`) | P0 |
| B2 | No template **partials/includes** and no layout inheritance. Every template repeats header/footer markup. | `lib/render.ts` | P0 |
| B3 | Conditional is truthiness only: no `==`, no filters (`{{date}}` formatting, truncate, pluralize), no `{{#each}}` index/parent. Themes cannot express dates, reading time, or "if two categories". | `TOKEN` regex in `render.ts` | P0 |
| B4 | Store themes are hard-wired by cross-import: Premium imports Pro's `page/post/archive/404` and is recompiled with them. Editing Pro silently changes Premium. | `themes/index.ts` | P1 |
| B5 | Theme CSS is **inlined into every page's `<head>`** — no cacheable asset URL, no ETag, 100 KB repeated per request. | `renderTheme` → `theme_css` | P1 |
| B6 | No preview before activate. Store cards show three colour swatches (`preview: [c1,c2,c3]`) and nothing else — it cannot look like a theme marketplace. | `routes/admin/themes.ts` | P0 |
| B7 | No theme editing in the panel. To change one line you download JSON, edit locally, re-upload. | `themes.ts` | P1 |
| B8 | Activation is not reversible: no revision history, no "revert to previous theme", no fallback if the active theme renders badly. | `activate()` | P1 |
| B9 | Upload-by-slug replacement silently discards local edits to that theme. | `saveTheme` | P1 |
| B10 | Themes table has no `author`, `description`, `screenshot`, `settings`, `site_id`. | `schema.sql` | P1 |
| B11 | Public pages ship **no CSP**; theme/custom JS runs unrestricted in the site origin. | `renderTheme` | P1 |
| B12 | `theme.json` v1 has no manifest semantics beyond file names — no slots, no parent, no supported tags, no changelog. | `themes/*/theme.json` | P2 |

#### C. Appearance / Customize

| # | Finding | Where | Sev |
|---|---|---|---|
| C1 | "Customize" is four raw code boxes. No tokens (brand colour, font, radius, width), so every visual change needs CSS knowledge. | `routes/admin/appearance.ts` | P0 |
| C2 | No live preview / no iframe preview pane. You save, then open the site in another tab. | — | P0 |
| C3 | Per-theme settings do not exist, so a theme cannot expose options ("hero on/off", "sidebar right"). | — | P0 |
| C4 | Customize, Themes, Menus, Widgets are four flat pages with no shared model of "the look of the site". | `ADMIN_SECTIONS` | P1 |
| C5 | Light/dark follows `prefers-color-scheme` only — no user override per device. | `ADMIN_CSS` | P2 |

#### D. Panel shell & design system

| # | Finding | Where | Sev |
|---|---|---|---|
| D1 | 31 KB of CSS in a TS template literal, inlined on every admin response, un-versioned. Emoji used as icons. | `lib/ui.ts` | P0 |
| D2 | No component layer. `content.ts` is 1,269 lines: list state, SQL, markup and inline JS per screen. Adding a field means editing three places. | `content.ts` | P0 |
| D3 | No global search. Finding a post means Posts → type → filter tabs. | — | P1 |
| D4 | No breadcrumbs, no consistent page header (title + primary action + tabs are re-invented per screen). | all routes | P1 |
| D5 | Lists are wide tables with `min-width:44rem` and horizontal scroll on mobile; no responsive card fallback. | `posts-table` | P1 |
| D6 | No audit log. Nobody can answer "who unpublished the pricing page". | — | P1 |
| D7 | No keyboard shortcuts, no command palette, no focus management on dialogs. | — | P2 |
| D8 | No per-user preferences (rows per page, editor skin is device-local only via `localStorage`). | `EDITOR_JS` | P2 |
| D9 | Dashboard is counts + two lists. No "needs attention" queue (stale drafts, scheduled today, broken links, pending comments, update available). | `admin/index.ts` | P1 |
| D10 | No empty states/onboarding path for a brand-new install. | — | P2 |

---

## 2. Principles for the overhaul

1. **The panel is a product, not a set of forms.** One design system, one component kit, one page-header
   pattern. No route renders raw markup primitives again.
2. **Nothing is lost.** Autosave + revisions + locks before any new surface ships.
3. **Themes are a platform.** Assets, partials, filters, settings schema, preview, versions, rollback.
4. **Progressive enhancement stays.** Every screen must work with JS off, as today.
5. **Editors never write CSS to get a decent result.** Tokens first, CSS as the escape hatch.
6. **Every phase ships behind tests** and bumps `APP_VERSION`; migrations are forward-only.

---

## 3. Phases

Estimates assume one senior engineer familiar with the codebase. `d` = focused working days.

### Phase 0 — Safety net & design foundations (4 d) — ✅ shipped in 0.3.0

*Why first: everything else lands on top of these, and phases 1–6 are unsafe without tests.*

Shipped:

- `src/admin/assets/{tokens,app,screens}/*.css` served as three immutable, ETagged
  bundles; no inline CSS anywhere, including login and error pages.
- Token layer: colours, space, radius, type scale, shadows, plus light, dark and
  compact-density values. Components may only reference tokens.
- New shell: sticky top bar, collapsible rail (state in a cookie so the server
  renders the right width first time), account menu, skip link, breadcrumbs slot.
- SVG icon sprite replacing emoji (one sprite per document).
- Component kit: `pageHead`, `breadcrumbs`, `tabs`, `card`, `table`, `emptyState`,
  `notice`, `pagination`, `postButton`, `dialog`, `field`, `selectField`, shared JS.
- Preferences screen: scheme / density / rail, applied server-side (no flash).
- Error boundary: a failed screen renders a styled page naming the route.
- `npm run check:assets`: colour-literal ban outside tokens, per-bundle size
  budgets, undefined-token detection, orphan-screen detection. Part of `npm test`.
- `tests/helpers.mjs` harness + `tests/panel.test.mjs` reference test file.
- Users, Comments and Categories/Tags rebuilt on the kit; version 0.3.0.

**Acceptance:** no admin CSS inline; every existing test green; one shared `pageHeader` used by ≥3 screens.

### Phase 1 — Panel shell overhaul (7 d) — ✅ shipped in 0.4.0

*Scope note: the "list table component" landed as a shared list pattern in `src/admin/components.ts` + `screens/lists.css`, applied to posts and pages. Media, tools and the remaining screens still use their legacy markup (moved to Phase 1b below).*

- **App shell v2**: persistent rail (collapsible, remembers state in a cookie so the server can render
  the right width — no layout flash), sticky page header, breadcrumbs, user menu (profile / preferences
  / log out), "View site" always visible.
- **Command palette** (`Ctrl/⌘+K`): jump to any screen, search posts/pages/media/users by title as you
  type, `/new post`, `/settings`, recent items. Server-backed `GET /{admin}/search?q=` returning
  grouped JSON; palette renders it. This alone removes most navigational friction.
- **List table component**: server-rendered table + responsive card mode, column visibility, per-user
  rows-per-page preference, sticky header, bulk-action bar that appears on selection (replaces the
  duplicated top/bottom selects in `postsList`).
- **Dashboard v2 — "Needs attention"**: pending comments, posts scheduled in the next 7 days, drafts
  untouched for 30 days, theme update available, schema migration pending, last backup age, failed
  logins in 24 h. Each row links directly to the fix.
- **Empty states & onboarding**: fresh install gets a 3-step checklist (site details → pick a theme →
  write first post) that disappears when done.
- **A11y pass**: focus trap in dialogs, `aria-live` on toasts, visible focus rings, contrast ≥ 4.5:1
  in both schemes, reduced-motion support, skip-to-content in the admin.
- **Toast/flash v2**: reusable dismissible toast region; keep `?ok=`/`?err=` redirects as the no-JS path.

**Acceptance:** palette finds any post in < 2 keystrokes after the query; posts list usable at 360 px;
Lighthouse a11y ≥ 95 on dashboard and posts list; admin HTML payload down ≥ 60 %.

Shipped in 0.4.0:

- **Command palette** (`src/admin/palette.ts`): ⌘K / Ctrl+K and `/`, arrow keys with
  `aria-activedescendant`, Esc, backdrop click, one `role="status"` live region that
  announces "Searching…", result counts and failures. 120 ms debounced fetch of
  `GET /{admin}/search?q=…&partial=1`; without JavaScript the same form submits to the page.
- **Global search** (`src/admin/search.ts`, `routes/admin/shell.ts`): posts and pages, media,
  comments, categories/tags, users; role-scoped (authors see only their own content, the users
  group is admin-only); comment lookups degrade on pre-migration databases. Grouped results,
  `Cache-Control: no-store`, query echoed back escaped.
- **List pattern** (`listToolbar`, `bulkBar`, `emptyRow`, `td`, `sortColumn`, `LIST_JS` +
  `screens/lists.css`): status tabs with counts, search + filter toolbar, one bulk bar (the
  duplicated top/bottom selects are gone), sortable `<th>` with `aria-sort`, `data-label` on
  every cell so the 700 px breakpoint renders each row as a card. Posts and pages converted.
- **Dashboard v2** (`src/admin/attention.ts` + `screens/dashboard.css`): greeting, site name,
  "needs attention" checklist sorted danger → warn → info (pending/spam comments, overdue
  scheduled posts, posts untouched for 60 days, media without alt text, incomplete media rows,
  pending schema updates, idle authors), each with a link that fixes it; plus "recently
  edited", "at a glance" and "latest comments". Every probe fails soft.
- **Preferences as one-click links**: `GET /{admin}/scheme/:scheme?next=` and
  `GET /{admin}/rail/:state?next=` set the cookie and bounce back (same-panel `next` only);
  `POST /{admin}/density` toggles density.
- **A11y**: skip link first in the document, labelled `main`/`rail`/`search` landmarks,
  `aria-current="page"` on the open section and tab, visible `:focus-visible` rings,
  `:focus-within` on wrapped inputs, live regions for search results and bulk selection,
  `prefers-reduced-motion` zeroes transitions, card mode at 700 px.
- **Tests**: `tests/panel.test.mjs` grew from 5 to 14 cases covering palette markup, search
  full page + fragment + guard + escaping, rail/scheme/density cookies, the list pattern and
  empty states, dashboard priority order, and the a11y floor (including a rule that every
  `outline: none` is scoped to a wrapper that draws its own ring).

**Phase 1b (not shipped, no date committed):** convert media, tools, themes, menus and plugins
screens to the list pattern; 3-step onboarding checklist for fresh installs; dismissible toast
region; per-user rows-per-page; sticky list headers.

**Measured in 0.4.0:** dashboard 33.6 KB HTML, posts list 37.5 KB, `<head>` ~530 B because all
styling lives in cached bundles, largest CSS bundle 29.6 KB raw / 5.7 KB gzip. The ≥ 60 %
payload target is a whole-panel average and is still open for the screens listed in Phase 1b.

### Phase 2 — Posts & pages workflow (11 d) — ✅ shipped in 0.5.0

The heart of the request. Order matters: durability first, then speed.

*Scope note: the block-model editor rewrite (item 4) is **not** in this release. The existing
Text/HTML editor gained autosave, locks, revisions, the media picker and a History card; replacing
`document.execCommand` with a block model is now Phase 2b, because it is the one item that can
regress what is already working and it deserves its own tests.*

1. **Revisions (P0)** — migration 3:
   `content_revisions(id, content_id, title, body, excerpt, seo_*, status, author_id, created_at, note)`.
   Snapshot on every save (and on restore). Admin screen: "Revisions" tab in the editor with a diff
   (line-based, server-rendered, no library) and **Restore**. Keep last 25 per item, prune in cron.
2. **Autosave (P0)** — `POST /{admin}/:kind/:id/autosave` every 30 s when dirty, storing into
   `content_revisions` with `note='autosave'`; the editor shows "Saved 12 s ago". New posts get an
   autosave-created draft so a crash never loses work. `beforeunload` guard + "you have a newer
   autosave, restore it?" banner.
3. **Edit lock (P0)** — `content_lock(content_id, user_id, token, heartbeat_at)`. Advisory lock shown as
   "Alice is editing this post"; takeover button for editors. Prevents silent last-write-wins.
4. **Editor v2 (P1)** — replace `document.execCommand` with a small block model:
   paragraph, H2/H3, list, quote, code, image (+caption), embed, HTML block. Paste sanitizes to blocks;
   toolbar operates on the block model; the HTML textarea remains the source of truth and the no-JS
   path. Ship it as `src/admin/assets/editor.js` (one file, no deps, < 25 KB) with the same classic/modern
   skins so nothing regresses visually.
5. **Media picker (P1)** — one dialog (`GET /{admin}/media/picker?type=image`) reusable for inline
   images, featured image (thumbnail grid, not `<select>`) and page hero. Upload straight from the
   dialog via the existing upload route. Sets `alt` while inserting.
6. **Post list v2 (P1)** — 48 px row thumbnail, status pill column, hover row actions (Edit · Quick edit ·
   Duplicate · Preview · Trash · View), **Quick edit** (title, slug, status, date, categories, tags in
   place), **Duplicate**, sticky pin, and a "Preview in theme…" menu that renders the post with any
   installed theme (`?preview=1&theme=slug`, admin-only) — this also becomes the store's preview engine.
7. **Page ordering (P1)** — `content.menu_order` (integer, drag to reorder in Pages list) and an
   `order_by` setting used by `listPages` in themes; also exposes `{{#each pages}}` nav helper.
8. **Scheduled queue (P2)** — "Scheduled" tab shows countdown and a "publish now" action.
9. **Last edited by (P2)** — `content.updated_by`, shown in the editor footer and list tooltip.

**Acceptance:** kill the browser mid-edit → content recoverable; two sessions editing → second sees the
lock; image insertion possible without leaving the editor; every new route covered by an e2e test.

Shipped in 0.5.0 (schema version 4):

- **Revisions** — `content_revisions` (migration 3). Every save snapshots the row *as it was before*
  the save, so nothing is lost; unchanged re-saves are skipped. `GET /{admin}/{kind}/{id}/revisions`
  lists the history (manual saves and autosaves are labelled separately, 25 + 8 kept per item),
  `.../revisions/:rev` shows a line diff (LCS, gaps collapsed, `<del>`/`<ins>` for the title) and
  `POST .../revisions/:rev/restore` restores — writing a snapshot of what it replaces first, so a
  restore is itself reversible. `src/admin/revisions.ts` holds the logic, `src/admin/editor-views.ts`
  the fragments.
- **Autosave** — `POST /{admin}/{kind}/{id}/autosave` every 30 s while dirty, into the revision table
  with `note='autosave'`, never into the live row: a crashed tab leaves a recoverable copy and the
  published page keeps serving the last real save. The editor shows "Autosaved 12 s ago", arms a
  `beforeunload` guard while dirty, and the editor page shows a "Unsaved work from …" banner when a
  newer autosave exists. JSON in, JSON out, `no-store`; a site without migration 3 answers
  `409 {error:'needs-migration'}` and says so in the editor instead of failing.
- **Edit locks** — `content_lock` (advisory, 2.5 min TTL, heartbeat every 45 s). The second person to
  open a post sees "Alice is editing this post right now" with an editor-only **Edit anyway**
  (`POST .../lock/takeover`). Saving releases the lock and never blocks, so a lost connection can
  not strand a post.
- **Media picker** — one dialog (`src/admin/media-picker.ts`) for the featured image and the
  editor's Insert image button. `GET /{admin}/media/picker` serves JSON for the grid,
  `POST /{admin}/media/picker/upload` uploads multipart and answers JSON with the new item (alt text
  included), and `POST /{admin}/media/{id}/alt` edits alt text from the library. The old `<select>`
  of filenames is gone.
- **List v2** — 48 px row thumbnails, pin badge, and a row menu with Edit · Quick edit · Duplicate ·
  History · View · Pin · Preview in theme… (the menu appears on hover/focus on desktop, always on
  phones). **Quick edit** (`GET/POST /{admin}/{kind}/{id}/quick`) edits title, slug, status, date,
  categories and tags without leaving the list; **Duplicate** copies as a draft; **Pin**
  (`content.pinned`) floats a row to the top.
- **Page ordering** — `content.menu_order` plus a "Page order" panel on the Pages screen
  (`POST /{admin}/pages/order`). Themes get `{{#each pages}}` in the shared render data, ordered by
  `menu_order` (or alphabetically when the `pages_order` setting says `title`), so the site menu and
  the panel agree.
- **Preview in any theme** — `?preview=1&theme=slug` renders a post or page with any *installed*
  theme, admin-session only and never cached. This is the preview engine the theme store will use.
- **Upgrade safety** — migrations now run statement by statement, tolerating the one error SQLite
  cannot express idempotently (`ADD COLUMN` on a database that already has it), and
  `src/lib/schema.ts` probes (cached ~5 s, cleared after a migration) let every new screen degrade
  instead of throwing. `tests/panel.test.mjs` proves it: drop the Phase 2 tables under a running
  server and the editor, history and saves still work, then `Updates → Run updates` restores the
  full feature set. Cron prunes expired locks and autosaves older than 14 days.

**Measured in 0.5.0:** `tests/e2e.mjs` 26 tests, `tests/panel.test.mjs` 23 tests, all green on the
Node runtime; bundle budgets unchanged (largest CSS 29.6 KB raw / 5.7 KB gzip, `screens/editor.css`
adds 8.1 KB raw / 2.0 KB gzip).

**Phase 2b (not shipped):** block-model editor (paragraph/H2/H3/list/quote/code/image/embed/HTML
blocks) replacing the contenteditable command layer; per-user rows-per-page; "last edited by" in the
editor footer.

### Phase 3 — Theme platform v2 (9 d) — ✅ shipped in 0.6.0

This is the architectural change that makes "adding themes" cheap.

1. **Theme packages with assets (P0)** — migration 4:
   `theme_assets(theme_id, path, mime, size, content BLOB | r2_key)`. Public route
   `GET /theme-assets/{slug}/{path}` with long-lived immutable caching, ETag, `nosniff`, and the same
   sandbox CSP as media. Upload accepts `.zip` with `assets/**` (images, fonts, per-theme `theme.js`).
   Cap: 10 MB total per theme, 512 KB per file, allow-listed MIME (no SVG with script, no HTML).
2. **Asset helper in templates** — `{{asset "logo.png"}}` and `{{{theme_css_url}}}` replacing inline
   `{{{theme_css}}}` (keep the old tag working for one release). Themes ship
   `<link rel="stylesheet" href="/theme-assets/{slug}/style.css">` → browsers cache it and pages shrink.
3. **Template engine v2 (P0)** — grammar additions, all data-only:
   - Partials: `{{> header}}`, `{{> post-card}}` resolved from `templates['partial:header']` or
     `partials/header.html` in the zip; `{{> @theme "name"}}` for cross-theme reuse.
   - Layout inheritance: `theme.json` `"layout": "base"`, template declares `{{#block content}}`.
   - Comparisons: `{{#if post.comments_count gt 0}}`, `eq/ne/gt/gte/lt/lte/and/or/not`.
   - Filters: `{{post.date | date "d MMM yyyy"}}`, `| truncate 160`, `| strip_html`, `| slug`,
     `| json`, `| default "…"`, `| upper|lower|capitalize`, `| reading_time`, `| number_format`.
   - Loop helpers: `{{@index}}`, `{{@first}}`, `{{@last}}`, `{{#each}}` over objects.
   - `{{#each}}` limit/offset: `{{#each posts limit=3}}`.
   - Compile cache keyed by template hash; a `GET /{admin}/themes/:id/validate` endpoint reports
     unknown tags/paths/missing partials before activation.
4. **Manifest v2 (`theme.json`)** — see Appendix A. Adds `author`, `homepage`, `description`,
   `screenshot`, `tags`, `parent`, `settings[]` (typed option schema), `tokens`, `assets`, `changelog`.
   Backwards compatible: v1 manifests still load.
5. **De-duplicate store themes (P1)** — Premium stops importing Pro's templates: give it its own
   `page/post/archive/404` files (they are ~15 lines each) or declare `"parent": "ams-pro"` and inherit
   explicitly through the new layout/partial mechanism.
6. **Public CSP (P1)** — emit `Content-Security-Policy` with a per-site nonce: `script-src 'self'
   'nonce-…'`; custom JS and hook snippets get the nonce; theme JS must be a served asset. Report-only
   mode behind a setting for one release, then enforce.
7. **Theme safety** — activation writes a `theme_versions` row (snapshot of templates/css/assets) so
   "Revert" exists; `?theme=<slug>` preview; a render-time fallback to AMS Base if the active theme's
   `base` throws or renders empty, plus a "Theme failed, using AMS Base" admin banner.

**Acceptance:** a theme with an image logo, custom font, `{{> partial}}` and `{{post.date | date}}`
authored and installed purely through the panel; page HTML drops the inlined CSS; CSP enforced with zero
inline violations on all three bundled themes.

Shipped in 0.6.0 (schema version 5):

- **Theme packages** — `theme_assets` (index), `theme_versions` (snapshots), `theme_settings`, plus
  `themes.partials/manifest/parent/author/description/screenshot`. Asset bytes live in the existing file
  store under `themes/{slug}/{path}` (KV on Cloudflare, `data/media/` on Node), so nothing new to
  provision and the 25 MB KV value limit already covers a 512 KB asset. Uploads take a `.zip`
  (`theme.json` + templates + `partials/` + `style.css` + `assets/`) or a v1 `.json` bundle. Limits: 6 MB
  zip, 512 KB per asset, 80 assets, 4 MB total; PNG/JPEG/GIF/WebP/AVIF/ICO, WOFF/WOFF2/TTF/OTF and one
  `theme.js`; **SVG and HTML refused** because they can carry script and are served from the site origin.
- **`GET /theme-assets/{slug}/{path}`** — one-year immutable cache, ETag/304, `nosniff`, sandbox CSP, and
  path traversal refused before any lookup. The stylesheet is stored as an asset, so every v2 layout
  *links* it: page HTML no longer carries a theme's CSS.
- **Template engine v2** (`src/lib/template.ts`, replacing the inline engine in `render.ts`) — comparisons
  (`eq ne gt gte lt lte and or not`, parentheses), loop helpers (`@index/@number/@key/@first/@last`),
  `{{#each}} limit=/offset=` over arrays *and* objects, partials (`{{> header}}`, `{{> card post}}`,
  `{{> @theme "x"}}`), layout blocks (`{{#block content}}` alongside `{{{content}}}`), filters (`date`,
  `truncate`, `strip_html`, `slug`, `json`, `default`, `upper/lower/capitalize`, `reading_time`,
  `number_format`, `asset`, `url`, `escape`, `nl2br`) and `{{asset "x"}}` in both the helper and filter
  spellings. Compile cache keyed by source string. Everything is a pure function over data: a template
  still cannot execute code, and anything that is not a path/literal/filter/block is a parse error.
- **Manifest v2** — `author`, `homepage`, `description`, `tags`, `screenshot`, `parent`, `layout`,
  `supports`, `preview`, `settings[]` (text/textarea/toggle/color/select/number/image/url), `changelog`,
  `assets`. v1 manifests load unchanged.
- **Inheritance + de-duplication** — `"parent": "ams-pro"` merges templates, partials and settings, one
  level deep, with children winning. **AMS Premium stopped copying Pro's templates** and now declares
  Pro as its parent; a cycle or a missing parent is refused at upload time. Deleting a theme that others
  inherit from is refused.
- **Settings** — declared defaults are seeded on install, edited under Themes → *theme*, merged over the
  defaults at render time (`{{theme.accent}}`), invalidated on save, and reset in one click.
- **Version history** — a snapshot is written before every activation, upload and revert (10 kept per
  theme); **Revert** restores templates/partials/CSS/manifest and is itself revertible.
- **Validator** — `GET /{admin}/themes/validate` checks a file *before* installing it, and
  `/themes/{slug}/validate` checks what is installed: template syntax, unknown filters, missing partials,
  assets the manifest promises but does not ship, refused file types, a layout with no page slot, and
  reliance on values the CMS does not provide. Findings are graded error/warning and listed with the
  place to fix them.
- **Public CSP** — per-response nonce (read back out of the rendered HTML so the header and page always
  agree, including on a cache hit), `script-src 'self' 'nonce-…'`, `object-src 'none'`, `base-uri 'self'`,
  `form-action 'self'`, YouTube only in `frame-src`. Custom CSS/JS and hook snippets get the nonce
  automatically; theme JS is a served asset. Setting: **off / report (default) / enforce**, with a
  description of what to do while on report-only.
- **Theme safety** — a theme that throws while rendering falls back to AMS Base for that page and the
  Themes screen shows the error with a link to the editor; `?theme=slug` previews any installed theme for
  signed-in users only, never cached.

**Measured in 0.6.0:** `tests/template.test.mjs` 11 cases (new), `tests/panel.test.mjs` 30 cases (7 new),
`tests/e2e.mjs` 26 cases, all green on Node; panel CSS budgets unchanged (largest 29.6 KB). A zip theme
authored for the test ships a partial, a PNG logo, a linked stylesheet and three typed settings, and is
installed, configured, rendered, versioned, inherited and validated entirely through the panel.

### Phase 4 — Appearance hub & live Customizer (8 d) — ✅ shipped in 0.7.0

New information architecture, replacing four flat pages:

```
Appearance
├── Customize        (tokens → live preview → per-theme settings → advanced CSS)
├── Themes           (store · installed · upload · editor · revisions)
├── Templates        (browse the active theme's templates; per-page template override)
├── Menus            (unchanged API, new chrome, drag sorting, depth-2)
├── Widgets          (areas from theme.json, not three hard-coded footer slots)
└── Identity         (logo, favicon, social image, scheme/colour defaults)
```

1. **Global tokens** (`settings` keys → CSS custom properties injected as `:root`): brand, brand-alt,
   text, surface, background, radius scale, font family (system/rounded/serif/mono + custom stack),
   type scale, container width, scheme default. Themes consume tokens; anything unspecified falls back
   to the theme's own CSS.
2. **Per-theme settings** — `theme.json` `settings[]` describes typed fields
   (`select | toggle | color | text | range | image | richtext`). Stored as
   `theme_settings(theme_id, key, value)`; exposed to templates as `{{theme.hero_title}}`,
   `{{#if theme.show_sidebar}}`. Customizer renders the correct controls automatically — this is what
   turns "adding themes" into "adding a manifest".
3. **Live preview** — split-pane Customizer: an `<iframe src="/?preview=1&theme_customize=token">` the
   admin server renders with the *unsaved* settings passed through a signed, short-lived preview
   cookie (never query-string JSON). Debounced postMessage reload; desktop/tablet/mobile widths.
   No-JS fallback: "Open preview in new tab" using the same signed cookie.
4. **Advanced** — the existing CSS/head/footer/JS boxes move under a collapsed "Custom code" section,
   unchanged in behaviour, with a warning label.
5. **Per-item template override** — "Template" dropdown in the post/page editor listing theme templates
   (e.g. use `page-landing` for this page). `content.template` column, resolved in `resolve()`.

**Acceptance:** change brand colour in the Customizer and see it in the preview without saving; a
newly uploaded theme's manifest settings appear as controls with no code change; per-page template
override renders on the public site.

**What shipped**

- **The hub** — one Appearance section with six children (Customize, Themes, Templates, Menus, Widgets,
  Identity). `/themes` and `/menus` keep their URLs, so bookmarks and existing links are unchanged.
- **Tokens** — `src/lib/tokens.ts` is the single table (group, label, control type, default, help) that drives
  both the controls and the emitted CSS. Emitted as one `:root{…}` block after the theme stylesheet and before
  custom CSS, **filtered to the variables the active theme's stylesheet reads or declares**, under whichever
  alias that theme uses (`--accent`, `--primary`, `--link`, `--gold` for brand). A token a theme cannot honour
  is listed under *Not offered by ⟨theme⟩* rather than offered as a dead control. An unset token emits
  nothing, so an untouched site is byte-identical to 0.6.0. Colours are validated (`#rgb`–`#rrggbbaa`),
  numbers clamped, the custom font stack stripped of `<>{};\`. The colour scheme is applied as
  `<meta name="color-scheme">` and honoured by every theme.
- **Live preview** — `POST /{admin}/appearance/preview` validates the posted control values exactly as a save
  would and mints `ams_preview`: HMAC-signed, `HttpOnly`, `SameSite=Strict`, path `/`, 30-minute TTL, carrying
  *only* the differences (a typical preview is a ~150-byte cookie; past 3.5 KB the reply says so instead of
  silently dropping the preview). Read only for a signed-in admin. The iframe is the real site
  (`/?preview=1&customize=1`), reloaded on a 300 ms debounce; `X-Frame-Options: SAMEORIGIN` plus
  `frame-ancestors 'self'` apply to preview responses only, so the public site stays unframeable. Desktop /
  tablet / mobile widths change the frame's width, so the site's own breakpoints decide. No-JS: the form
  saves and *Open preview in a tab* shows the same signed preview. **Discard** clears the cookie.
- **Per-theme settings, no code** — `settings[]` from `theme.json` renders the matching control (text,
  textarea, toggle, color, select, number, image with the media picker, url). Stored in `theme_settings`,
  previewed unsaved, saved from the Customizer, and still editable on the theme's own screen.
- **Widgets from the manifest** — `"widgets": ["footer", "sidebar"]` (or objects with `label`/`help`). Three
  slots per area as `widget_{area}_{n}_{title,body}`; the theme places an area with `{{{widgets.footer}}}`.
  Areas the layout does not draw are appended with `{{{footer}}}`, so a filled area is never invisible and a
  drawn one is never repeated. A theme that declares none gets the classic `footer` area under the exact keys
  existing sites already have — verified by the 0.6.0-era e2e case, which still passes unchanged.
- **Per-page templates** — the editor's *Publish → Template* dropdown lists the active theme's templates
  (`content.template`, migration **6**); resolved in `resolve()`; only stored when the template exists; a page
  whose template disappears with a theme change falls back to the default for its kind. Templates screen lists
  what the theme offers and which pages override it.
- **Identity** — logo, favicon and social image (URLs from Media via the picker, sanitised) plus the scheme and
  brand defaults. `og:image` falls back to the social image when a page has no featured image; `site.logo` is
  available to themes and all three bundled themes draw it.
- **Custom code** folded under a collapsed disclosure, unchanged in behaviour.
- **Panel CSS** — a new `screens/appearance.css` under a 10 KB / 3 KB budget (6.8 KB / 1.9 KB actual).

**Measured in 0.7.0:** `tests/panel.test.mjs` 39 cases (9 new), `tests/e2e.mjs` 27 cases (13b new, 12f
rewritten for the hub's messages and the area-scoped widget markup), `tests/template.test.mjs` 11 cases — all
green on Node; panel CSS budgets met (largest bundle 29.6 KB). The new e2e case proves the three acceptance
criteria over HTTP: an unsaved brand colour and an unsaved theme setting reach the preview and reach nothing
else, the save keeps both, the same manifest settings become controls with no code, and a page with its own
template renders it publicly while a page without one keeps the default.

### Phase 5 — Theme store & lifecycle (6 d) — ✅ shipped in 0.8.0 · storefront removed in 0.9.0

> **Superseded in part.** The CMS now ships no themes at all, so the storefront half of this phase is
> gone: no cards to list, no one-click install, no bundled update to offer, and no bundled design to fall
> back to. A fresh site renders bare, unstyled HTML until its owner uploads a theme and activates it.
> Everything here about the *lifecycle* still stands — live preview, the in-panel file editor,
> validate-on-save, `theme_versions` history, rollback, zip export/import and "new theme from a template".
> The two demonstration themes were never product themes; a complete example package lives in
> `tests/fixtures/site-theme/` for the test suite to upload.

- **Storefront quality**: real screenshots (`screenshot.png` in the package, rendered via
  `/theme-assets/...`; fall back to a token-generated gradient card if absent), live "Preview" modal
  running the site in an iframe with that theme (using the Phase 2 preview engine), feature tags,
  author, version + changelog, install/update/activate in one click with progress toasts.
- **Version lifecycle**: `theme_versions` rows per install/update; "Update available v1.0 → v1.2" with
  a changelog; **Rollback** one click; if local edits exist on a slug, prompt "Keep my changes /
  Replace / Save mine as a copy".
- **Theme authoring inside the panel**: file tree + CodeMirror-free plain textarea editor (no
  dependency), per-file save, validate-on-save, "New theme from a template", export as ZIP (needs a
  minimal zip *writer* next to `lib/zip.ts`), import from store or upload.
- **Two new bundled themes** to prove the platform: one "Journal" (single column, serif, large images)
  and one "Portfolio" (grid, per-theme settings for hero + accent), both using partials, tokens, a
  per-theme asset and at least three customizer settings.

**Acceptance:** install → preview → customize → rollback performed entirely in the panel; store cards
show screenshots; zip export round-trips through upload byte-for-byte for templates/CSS.

**Shipped in 0.8.0.** Store cards render `screenshot.png` through `/theme-assets/<slug>/screenshot.png`
(cache-busted by version) and fall back to a palette gradient; preview is an iframe running the real site;
install + activate is one POST. `theme_versions` (migration 6) records every install, update and panel save,
the detail screen shows the history newest-first with **Roll back**, and a rollback rewrites the stylesheet
asset as well as the row. The editor is a file tree + textarea with per-file save and validation; export is a
real zip written by `zipFiles` (`theme.json` names the files, assets byte-for-byte) and `POST /themes/upload`
accepts it back; `GET /themes/:id/download.json` keeps the readable form. **AMS Journal** and **AMS Portfolio**
ship with partials, `--j-*`/`--p-*` tokens, a per-theme asset (`screenshot.png`) and 6/8 settings.
*Measured:* `tests/panel.test.mjs` 50 cases, `tests/e2e.mjs` 27, `tests/template.test.mjs` 12 — 89 green on
Node, panel CSS budgets met (largest bundle 29.6 KB, editor JS 8.7 KB / 30 KB).

### Phase 6 — Governance, performance, polish (7 d) — ✅ shipped in 0.8.0

- **Audit log** (migration 5): `audit_log(id, user_id, action, object_type, object_id, summary, ip,
  created_at)` written from one helper on every mutation; viewer under Tools with filters and 90-day
  retention. Answers "who changed what" for content, themes, settings and users.
- **Capabilities instead of hard-coded roles**: `role_caps` map (`manage_themes`, `edit_others_posts`,
  `moderate_comments`, `manage_users`…), UI reads `can(user, cap)`, roles keep their current defaults.
- **Performance budgets**, enforced in CI: admin HTML ≤ 60 KB gzipped, admin CSS ≤ 25 KB, editor JS
  ≤ 30 KB, public page ≤ 45 KB excluding media, TTFB targets documented per runtime.
- **i18n readiness**: all panel strings through `t()` with an `en` catalogue (no behaviour change);
  enables a second language later without touching routes.
- **Docs**: rewrite README "Themes" into a proper *Theme Developer Guide* (manifest v2, tags, filters,
  partials, tokens, assets, settings) plus a *Panel Guide* with screenshots; `docs/` becomes the
  reference, README the front door.
- **Import/export v2**: include theme packages, theme settings and revisions in Tools export.

**Shipped in 0.8.0.** `audit_log` is migration 7 and every mutation goes through `audit()` (content, themes,
users, comments, settings, appearance, import/export) with a readable summary; Tools → Audit log filters by
person/action/area/text through GET parameters, and `pruneAudit` drops rows older than 90 days from the cron.
`src/lib/capabilities.ts` holds 16 capabilities and the role defaults, `can(user, cap)` guards every route and
the sidebar; the Users screen describes a role from the same map. Budgets live in `src/lib/budgets.ts`,
measured by `scripts/measure.mjs` into `src/lib/budget-report.json`, enforced by `npm run check:budgets` in
`npm test` and shown on Site Health. Panel strings for the new screens come from `src/lib/i18n.ts` (`en`
catalogue, `t(key, vars)`, missing keys render visibly). Export is format version 2 with `themes`,
`theme_settings` and `content_revisions`; import validates each theme with the normal manifest parser and
skips a bad one rather than failing the file.

Living docs: `README.md` is the front door (install, run, what is in the box), `docs/panel-guide.md` is every
screen including the audit log and the capability table, and `docs/theme-developer-guide.md` is the manifest,
template tags, assets, settings and CSP. This file stays the plan and the record.

---

## 4. Sequencing, effort and the first slice

| Phase | Content | Days | Depends on |
|---|---|---|---|
| 0 | Safety net, design system, assets | 4 | — |
| 1 | Panel shell, palette, list tables, dashboard | 7 | 0 |
| 2 | Revisions, autosave, locks, editor v2, media picker, list v2 | 11 | 0, 1 |
| 3 ✅ | Theme platform v2 (assets, partials, filters, manifest, CSP) | 9 | 0 |
| 4 ✅ | Appearance hub, tokens, live preview, per-page templates, widget areas, Identity | 8 | 1, 3 |
| 5 ✅ | Store lifecycle, authoring, rollback, 2 new themes | 6 | 3, 4 |
| 6 ✅ | Audit log, capabilities, budgets, i18n, docs | 7 | 1–5 |
| | **Total** | **52** | |

Parallelism: Phase 3 can run alongside 1–2 (different surface area), which compresses this to ~6 weeks
for two engineers.

**Minimum lovable slice (10–12 days)** if you want visible progress fast and everything else later:

1. Phase 0 asset split + component kit (2 d)
2. A1/A2/A3 — autosave, revisions, edit lock (4 d) ← the highest-value change in the whole plan
3. C1 partial: global tokens (brand/text/radius/font) + real-time preview iframe (3 d)
4. B6 partial: screenshots + preview modal in the theme store (2 d)
5. A5 media picker (1 d)

That slice alone turns "a solid CMS" into "a CMS I would defend in a review".

---

## 5. Risk register

| Risk | Impact | Mitigation |
|---|---|---|
| Theme engine v2 breaks existing uploaded themes | High | v1 manifests keep loading; old `{{{theme_css}}}` still resolves for one release; `validate` endpoint; migration test with a v1 fixture |
| Revisions multiply D1 row count/size | Medium | Cap 25 per item, prune in cron, store body diffs optional later |
| Autosave + cache churn on KV (free-plan writes) | Medium | Autosave writes D1 only; cache bumped on real save/publish only |
| CSP enforcement breaks analytics snippets | Medium | Report-only release, per-site nonce, documented allow-list, toggle in Settings |
| Editor v2 regressions in content fidelity | Medium | HTML textarea stays source of truth; round-trip fuzz tests over fixtures |
| Scope creep across 6 phases | High | Ship phase-by-phase behind `APP_VERSION` bumps; each phase independently useful |

---

## 6. Decisions needed from you

1. **Editor ambition** — block model like Phase 2.4, or keep `contenteditable` and invest the time in
   themes instead? (Recommend: block model, but after revisions/autosave/locks.)
2. **Asset storage for themes** — D1 BLOB (simple, 10 MB cap) or reuse the KV/media store (cheaper at
   scale, more moving parts)? (Recommend: media store keyed `themes/{slug}/…`, D1 only for metadata.)
3. **Bundle size discipline** — is "no dependencies beyond Hono" still a rule? Everything above is
   achievable without any; say so now and it stays a selling point.
4. **Which two new store themes** do you want as proof-of-platform (Journal, Portfolio, Agency,
   Corporate, Magazine)?

---

## Appendix A — `theme.json` v2 (proposed)

```json
{
  "name": "Journal",
  "slug": "journal",
  "version": "1.2.0",
  "author": "AMS",
  "homepage": "https://example.com/journal",
  "description": "Single-column, serif, generous whitespace. For writing.",
  "screenshot": "screenshot.png",
  "tags": ["blog", "minimal", "serif"],
  "cms": ">=1.0.0",
  "parent": null,
  "layout": "base",
  "supports": ["comments", "widgets", "tokens", "settings", "assets", "partials"],
  "preview": { "colors": ["#fdfcf8", "#1a1a1a", "#b4552d"], "screenshot": "screenshot.png" },
  "templates": {
    "base": "base.html",
    "home": "home.html",
    "post": "post.html",
    "page": "page.html",
    "archive": "archive.html",
    "404": "404.html",
    "page-landing": "page-landing.html"
  },
  "partials": { "header": "partials/header.html", "post-card": "partials/post-card.html" },
  "assets": { "style": "style.css", "script": "theme.js", "logo": "assets/logo.svg" },
  "settings": [
    { "key": "hero_title", "type": "text", "label": "Hero title", "default": "Journal" },
    { "key": "show_sidebar", "type": "toggle", "label": "Show sidebar", "default": false },
    { "key": "accent", "type": "color", "label": "Accent", "default": "#b4552d" },
    { "key": "layout", "type": "select", "label": "Archive layout", "default": "list",
      "options": [ { "value": "list", "label": "List" }, { "value": "grid", "label": "Grid" } ] }
  ],
  "changelog": [ { "version": "1.2.0", "notes": "Added landing template and sidebar option." } ]
}
```

## Appendix B — Template tags (v2 target)

| Category | Examples |
|---|---|
| Values | `{{post.title}}`, `{{{post.content}}}`, `{{site.title}}`, `{{@index}}`, `{{this}}` |
| Conditions | `{{#if x}}`, `{{#unless x}}`, `{{#if n gt 3}}`, `{{#if a and (not b)}}`, `{{else}}` |
| Loops | `{{#each posts}}`, `{{#each posts limit=3}}`, `{{#each posts}}…{{else}}No posts{{/each}}` |
| Partials | `{{> header}}`, `{{> post-card post}}`, `{{> @theme "post-card"}}` |
| Layout | `{{#block content}}…{{/block}}`, `{{#extends "base"}}` |
| Filters | `{{post.date \| date "d MMM yyyy"}}`, `{{excerpt \| truncate 160}}`, `{{n \| number_format}}` |
| Assets | `{{asset "logo.svg"}}`, `{{{theme_css_url}}}`, `{{theme.accent}}`, `{{#if theme.show_sidebar}}` |
| Meta | `{{{head}}}`, `{{{footer}}}`, `{{{comments_html}}}`, `{{body_class}}`, `{{menu.primary}}` |

Every helper is a pure function over data; the engine still cannot execute code.

## Appendix C — Migrations this plan adds

| Version | Name | Objects |
|---|---|---|
| 3 ✅ | Revisions & workflow | `content_revisions`, `content_lock`, `content.updated_by`, `content.menu_order`, `content.pinned` (`content.template` moved to Phase 3) |
| 4 ✅ | Page ordering default | the `pages_order` setting (a database that ran an early build of v3 lands on a consistent version) |
| 5 ✅ | Theme platform | `theme_assets`, `theme_versions`, `theme_settings`, `themes.partials/manifest/parent/author/description/screenshot` (assets themselves live in the file store) |
| 6 ✅ | Appearance hub | `content.template` (per-page template override). Tokens and widget slots needed no new table: they are rows in `settings`, and per-theme settings already had `theme_settings` from v5 |
| 7 | Governance | `audit_log`, `role_caps`, `user_prefs` |

Forward-only, each applied by the existing `migrate()` and surfaced on the Updates screen.

## Appendix D — Definition of done (every phase)

- [ ] Works with JavaScript disabled (server-rendered path intact)
- [ ] Keyboard operable, focus visible, `aria` labels on every control
- [ ] Light and dark, 360 px → 1920 px
- [ ] e2e coverage for each new route and each destructive action's confirmation
- [ ] `APP_VERSION` bumped, README/docs updated in the same commit
- [ ] No new runtime dependency; bundle budget met
- [ ] Migration + rollback path documented

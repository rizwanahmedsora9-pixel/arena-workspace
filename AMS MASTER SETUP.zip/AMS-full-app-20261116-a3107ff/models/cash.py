from .__base import *  # noqa
from .helpers import *  # noqa
from sqlalchemy import CheckConstraint

class FbmCashDrawerEntry(db.Model):
    __tablename__ = 'fbm_cash_drawer_entry'
    id = db.Column(db.Integer, primary_key=True)
    entry_type = db.Column(db.String(10), default='out', index=True)  # in | out
    amount = db.Column(db.Float, default=0)
    category = db.Column(db.String(100))
    method = db.Column(db.String(20), default='Cash', index=True)  # Cash | Bank | Check
    note = db.Column(db.String(500))
    source = db.Column(db.String(20), default='manual', index=True)
    date_posted = db.Column(db.DateTime, default=pk_model_now, index=True)
    created_by = db.Column(db.String(80))
    is_void = db.Column(db.Boolean, default=False, index=True)


class FbmCashDrawerCategory(db.Model):
    __tablename__ = 'fbm_cash_drawer_category'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)
    is_active = db.Column(db.Boolean, default=True, index=True)
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)


class Account(db.Model):
    """Financial accounts for managing cash flow."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    # Legacy/compat column: existing SQLite DBs may require this field (NOT NULL).
    # Keep in sync with `account_type` to support mixed schemas.
    type = db.Column(db.String(50), nullable=False, default='Unknown')
    category = db.Column(db.String(20), nullable=False, default='cash')  # cash or bank
    source_category = db.Column(db.String(100), index=True)
    account_type = db.Column(db.String(50), nullable=False)  # company, supplier, client, personal, etc
    balance = db.Column(db.Float, default=0)
    balance_minor = db.Column(db.BigInteger, nullable=True)  # authoritative paisa/cents
    # Explicit opening baseline makes the ledger independently reproducible.
    # Legacy rows are backfilled as current balance minus posted net movement.
    opening_balance = db.Column(db.Float, nullable=True)
    opening_balance_minor = db.Column(db.BigInteger, nullable=True)
    opening_balance_date = db.Column(db.DateTime, nullable=True, index=True)
    # Bank details (if category == 'bank')
    bank_name = db.Column(db.String(100))
    account_holder_name = db.Column(db.String(100))
    account_number = db.Column(db.String(50))
    branch_code = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True, index=True)
    revision = db.Column(db.Integer, default=1, nullable=True)
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now, index=True)
    updated_by = db.Column(db.String(80))
    note = db.Column(db.String(500))
    # --- Controlled classification hierarchy (additive; legacy columns above
    # remain the compatibility surface for existing payment/KPI/transfer code).
    # See blueprints/accounts/classification.py for the authoritative registry. ---
    class_category = db.Column(db.String(50), index=True)        # Assets, Liabilities, ...
    class_subcategory = db.Column(db.String(80), index=True)     # Cash, Bank, Client Receivables, ...
    class_account_type = db.Column(db.String(100), index=True)   # Main Cash, Operating Bank, ...
    channel = db.Column(db.String(30), index=True)               # cash/bank/digital_wallet/ledger_only/other
    # Channel-specific details (only the subset relevant to ``channel`` is used).
    cash_location = db.Column(db.String(120))
    cash_responsible = db.Column(db.String(120))
    wallet_provider = db.Column(db.String(100))
    wallet_number = db.Column(db.String(80))
    wallet_holder = db.Column(db.String(120))
    # Linked entity.  client/supplier resolve to FKs; partner/worker/vehicle/
    # party are stored as linked_party_name (+ linked_entity_type).
    linked_entity_type = db.Column(db.String(30), index=True)    # none/client/supplier/partner/worker/vehicle/party
    linked_client_id = db.Column(db.Integer, db.ForeignKey('client.id'), nullable=True, index=True)
    linked_supplier_id = db.Column(db.Integer, db.ForeignKey('supplier.id'), nullable=True, index=True)
    linked_party_name = db.Column(db.String(160))
    # Active / Inactive / Archived.  ``is_active`` stays in sync (True only for
    # 'active') so existing filters keep working.
    account_status = db.Column(db.String(20), default='active', index=True)
    __mapper_args__ = {'version_id_col': revision}


class LoanParty(db.Model):
    """A person or organization from whom the business borrows principal."""
    __tablename__ = 'loan_party'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    note = db.Column(db.String(500))
    opening_principal_minor = db.Column(db.BigInteger, nullable=False, default=0)
    opening_principal_date = db.Column(db.Date, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=pk_model_now, nullable=False, index=True)
    created_by = db.Column(db.String(80))
    __table_args__ = (CheckConstraint('opening_principal_minor >= 0', name='ck_loan_party_opening_nonnegative'),)


class LoanMovement(db.Model):
    """Append-only loan principal movement linked to the real cash/bank leg."""
    __tablename__ = 'loan_movement'
    id = db.Column(db.Integer, primary_key=True)
    loan_party_id = db.Column(db.Integer, db.ForeignKey('loan_party.id'), nullable=False, index=True)
    movement_type = db.Column(db.String(16), nullable=False, index=True)  # received | repaid
    amount_minor = db.Column(db.BigInteger, nullable=False)
    cash_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False, index=True)
    account_tx_id = db.Column(db.Integer, db.ForeignKey('account_transaction.id'), nullable=True, unique=True, index=True)
    date_posted = db.Column(db.DateTime, default=pk_model_now, nullable=False, index=True)
    reference = db.Column(db.String(100))
    note = db.Column(db.String(500))
    idempotency_key = db.Column(db.String(64), unique=True, nullable=True, index=True)
    created_by = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=pk_model_now, nullable=False, index=True)
    __table_args__ = (
        CheckConstraint("movement_type IN ('received', 'repaid')", name='ck_loan_movement_type'),
        CheckConstraint('amount_minor > 0', name='ck_loan_movement_amount_positive'),
    )

    loan_party = db.relationship('LoanParty', backref=db.backref('movements', lazy='dynamic'))
    cash_account = db.relationship('Account')
    account_transaction = db.relationship('AccountTransaction')


class AccountCategory(db.Model):
    """Business categories used to group accounts for receive/pay flows."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)
    note = db.Column(db.String(300))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)


class AccountTransaction(db.Model):
    """Immutable ledger movement between accounts (voided, never erased)."""
    id = db.Column(db.Integer, primary_key=True)
    from_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=True, index=True)
    to_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=True, index=True)
    amount = db.Column(db.Float, default=0)
    amount_minor = db.Column(db.BigInteger, nullable=True)  # authoritative paisa/cents
    description = db.Column(db.String(200))
    date_posted = db.Column(db.DateTime, default=pk_model_now, index=True)
    is_void = db.Column(db.Boolean, default=False, index=True)
    note = db.Column(db.String(500))
    transaction_type = db.Column(db.String(50), index=True)  # Transfer, Payment, Receipt, Expense
    source_type = db.Column(db.String(50), nullable=True, index=True)
    source_id = db.Column(db.Integer, nullable=True, index=True)
    reconciliation_id = db.Column(db.Integer, db.ForeignKey('account_reconciliation.id'), nullable=True, index=True)
    # Reason + idempotency key are used by balance-adjustment entries posted
    # from the Account Edit form so each adjustment is auditable and a retried
    # / double-clicked submission cannot post twice.
    reason = db.Column(db.String(300), nullable=True)
    idempotency_key = db.Column(db.String(64), nullable=True, index=True)
    created_by = db.Column(db.String(80))
    voided_by = db.Column(db.String(80))
    voided_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)
    # --- GRN / recipient attribution for Cash Flow (additive) --------------
    grn_id = db.Column(db.Integer, db.ForeignKey('grn.id'), nullable=True, index=True)
    party_type = db.Column(db.String(30), index=True)
    party_id = db.Column(db.Integer, index=True)
    party_name = db.Column(db.String(160), index=True)

    from_account = db.relationship('Account', foreign_keys=[from_account_id], backref='outgoing_transactions')
    to_account = db.relationship('Account', foreign_keys=[to_account_id], backref='incoming_transactions')


class CashFlowDifferenceAdjustment(db.Model):
    __tablename__ = 'cash_flow_difference_adjustment'
    id = db.Column(db.Integer, primary_key=True)
    adjustment_date = db.Column(db.Date, nullable=False, index=True)
    # Legacy fields (kept for backward compatibility)
    amount = db.Column(db.Float, default=0)  # Old workflow: user-entered difference
    note = db.Column(db.String(500))  # Old workflow: adjustment note
    # NEW FIELDS: Physical Cash Reconciliation Workflow
    physical_cash_available = db.Column(db.Float)  # NEW: actual cash in drawer (primary input)
    calculated_closing = db.Column(db.Float)  # NEW: system-calculated closing balance
    difference = db.Column(db.Float)  # NEW: physical_cash_available - calculated_closing (auto-computed)
    reason = db.Column(db.String(500))  # NEW: explanation for discrepancy
    # Audit trail fields
    old_physical_cash = db.Column(db.Float)  # Previous physical_cash when edited
    edited_by = db.Column(db.String(80))  # User who last edited
    edited_date = db.Column(db.DateTime)  # Last edit timestamp
    edit_count = db.Column(db.Integer, default=0)  # Number of edits
    # Standard fields
    created_by = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now, index=True)
    __table_args__ = (
        UniqueConstraint('adjustment_date', name='uq_cash_flow_difference_adjustment_date'),
    )

    def is_legacy(self):
        """Check if this is a legacy record (old difference-entry workflow)."""
        return self.physical_cash_available is None

    def get_opening_for_next_day(self, calculated_closing):
        """Return the opening balance that should be used for the next day."""
        if self.physical_cash_available is not None:
            # NEW WORKFLOW: Use physical cash as next day opening
            return self.physical_cash_available
        elif self.amount is not None:
            # LEGACY WORKFLOW: Use calculated closing minus difference
            return calculated_closing - self.amount
        else:
            # NO RECONCILIATION: Use calculated closing as-is
            return calculated_closing


class CashFlowCategory(db.Model):
    """User-managed cash-flow category. Names are configuration, not code."""
    __tablename__ = 'cash_flow_category'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    direction = db.Column(db.String(10), default='both', index=True)  # in | out | both
    is_active = db.Column(db.Boolean, default=True, index=True)
    sort_order = db.Column(db.Integer, default=0)
    notes = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=pk_model_now)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)


class CashFlowSubcategory(db.Model):
    __tablename__ = 'cash_flow_subcategory'
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('cash_flow_category.id'), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    is_active = db.Column(db.Boolean, default=True, index=True)
    notes = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=pk_model_now)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)
    category = db.relationship('CashFlowCategory', backref='subcategories')


class CashFlowParty(db.Model):
    """Reusable party names for manual cash-flow rows and GRN charge recipients."""
    __tablename__ = 'cash_flow_party'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    party_type = db.Column(db.String(40), default='person', index=True)
    phone = db.Column(db.String(40))
    note = db.Column(db.String(300))
    is_active = db.Column(db.Boolean, default=True, index=True)
    created_at = db.Column(db.DateTime, default=pk_model_now)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)
    # --- Recipient master for GRN charges (additive) -----------------------
    party_role = db.Column(db.String(30), default='other', index=True)  # transporter|loading_labour|other
    is_payee_active = db.Column(db.Boolean, default=True, index=True)
    opening_balance = db.Column(db.Float, default=0)
    opening_balance_date = db.Column(db.DateTime, nullable=True)
    created_by = db.Column(db.String(80))


class CashFlowEntry(db.Model):
    """Manual cash-flow transaction (received / spent / transfer)."""
    __tablename__ = 'cash_flow_entry'
    id = db.Column(db.Integer, primary_key=True)
    direction = db.Column(db.String(10), nullable=False, index=True)  # in | out | transfer
    amount = db.Column(db.Float, default=0)
    amount_minor = db.Column(db.BigInteger, nullable=True)
    account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=True, index=True)
    destination_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=True, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey('cash_flow_category.id'), nullable=True, index=True)
    subcategory_id = db.Column(db.Integer, db.ForeignKey('cash_flow_subcategory.id'), nullable=True, index=True)
    party_id = db.Column(db.Integer, db.ForeignKey('cash_flow_party.id'), nullable=True, index=True)
    party_name = db.Column(db.String(160), index=True)
    party_type = db.Column(db.String(40), index=True)
    description = db.Column(db.String(200))
    note = db.Column(db.String(500), index=True)
    reference = db.Column(db.String(80), index=True)
    date_posted = db.Column(db.DateTime, default=pk_model_now, index=True)
    created_by = db.Column(db.String(80), index=True)
    updated_by = db.Column(db.String(80))
    source_type = db.Column(db.String(50), default='MANUAL_CASH_FLOW', index=True)
    source_id = db.Column(db.Integer, nullable=True, index=True)
    account_tx_id = db.Column(db.Integer, db.ForeignKey('account_transaction.id'), nullable=True)
    is_void = db.Column(db.Boolean, default=False, index=True)
    voided_at = db.Column(db.DateTime, nullable=True)
    voided_by = db.Column(db.String(80))
    void_reason = db.Column(db.String(300))
    idempotency_key = db.Column(db.String(64), nullable=True, index=True)
    revision = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=pk_model_now)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)

    account = db.relationship('Account', foreign_keys=[account_id])
    destination_account = db.relationship('Account', foreign_keys=[destination_account_id])
    category = db.relationship('CashFlowCategory', foreign_keys=[category_id])
    subcategory = db.relationship('CashFlowSubcategory', foreign_keys=[subcategory_id])
    party = db.relationship('CashFlowParty', foreign_keys=[party_id])


class CashFlowEntryAudit(db.Model):
    """Created / edited / voided / restored history for manual cash-flow rows."""
    __tablename__ = 'cash_flow_entry_audit'
    id = db.Column(db.Integer, primary_key=True)
    entry_id = db.Column(db.Integer, db.ForeignKey('cash_flow_entry.id'), nullable=False, index=True)
    action = db.Column(db.String(20), nullable=False, index=True)
    before_json = db.Column(db.Text)
    after_json = db.Column(db.Text)
    reason = db.Column(db.String(300))
    changed_by = db.Column(db.String(80))
    changed_at = db.Column(db.DateTime, default=pk_model_now, index=True)
    entry = db.relationship('CashFlowEntry', foreign_keys=[entry_id], backref='audit_trail')


class AccountReconciliation(db.Model):
    """Immutable per-account closing snapshot and transparent adjustment.

    ``previous/final`` and period movement fields preserve the complete carry
    chain: previous final -> opening -> period movement -> expected -> actual ->
    adjustment -> final.  Existing legacy columns remain for compatibility.
    """
    __tablename__ = 'account_reconciliation'
    id = db.Column(db.Integer, primary_key=True)
    account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False, index=True)
    previous_reconciliation_id = db.Column(db.Integer, db.ForeignKey('account_reconciliation.id'), nullable=True, index=True)
    adjustment_transaction_id = db.Column(db.Integer, nullable=True, index=True)
    reconciliation_date = db.Column(db.Date, nullable=False, index=True)
    period_start_at = db.Column(db.DateTime, nullable=True)
    period_end_at = db.Column(db.DateTime, nullable=True)
    previous_balance = db.Column(db.Float, default=0)
    opening_balance = db.Column(db.Float, default=0)
    transaction_in = db.Column(db.Float, default=0)
    transaction_out = db.Column(db.Float, default=0)
    transaction_net = db.Column(db.Float, default=0)
    expected_balance = db.Column(db.Float, default=0)   # calculated closing before adjustment
    actual_balance = db.Column(db.Float, default=0)     # physically entered closing
    difference = db.Column(db.Float, default=0)         # actual - expected
    adjustment_amount = db.Column(db.Float, default=0)  # signed, same as difference
    final_reconciled_balance = db.Column(db.Float, default=0)
    previous_balance_minor = db.Column(db.BigInteger, nullable=True)
    opening_balance_minor = db.Column(db.BigInteger, nullable=True)
    transaction_in_minor = db.Column(db.BigInteger, nullable=True)
    transaction_out_minor = db.Column(db.BigInteger, nullable=True)
    transaction_net_minor = db.Column(db.BigInteger, nullable=True)
    expected_balance_minor = db.Column(db.BigInteger, nullable=True)
    actual_balance_minor = db.Column(db.BigInteger, nullable=True)
    difference_minor = db.Column(db.BigInteger, nullable=True)
    final_reconciled_balance_minor = db.Column(db.BigInteger, nullable=True)
    difference_type = db.Column(db.String(20), default='Matched', index=True)  # Matched | Loss | Excess
    status = db.Column(db.String(20), default='Reconciled', index=True)
    note = db.Column(db.String(500))
    created_by_id = db.Column(db.Integer, nullable=True)
    created_by = db.Column(db.String(80))
    created_ip = db.Column(db.String(80))
    session_id = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=pk_model_now, index=True)
    # Kept for legacy schema compatibility; immutable records are never updated.
    updated_at = db.Column(db.DateTime, default=pk_model_now, index=True)

    account = db.relationship('Account', foreign_keys=[account_id], backref='reconciliations')
    previous_reconciliation = db.relationship('AccountReconciliation', remote_side=[id], foreign_keys=[previous_reconciliation_id])


class CashFlowReconciliationAudit(db.Model):
    """Audit trail for all physical cash reconciliation changes."""
    __tablename__ = 'cash_flow_reconciliation_audit'
    id = db.Column(db.Integer, primary_key=True)
    reconciliation_id = db.Column(
        db.Integer,
        db.ForeignKey('cash_flow_difference_adjustment.id'),
        nullable=False,
        index=True
    )
    adjustment_date = db.Column(db.Date, nullable=False, index=True)
    change_type = db.Column(db.String(20), nullable=False)  # 'CREATE', 'EDIT', 'DELETE', 'MIGRATE'
    old_physical_cash = db.Column(db.Float)
    new_physical_cash = db.Column(db.Float)
    old_difference = db.Column(db.Float)
    new_difference = db.Column(db.Float)
    old_reason = db.Column(db.String(500))
    new_reason = db.Column(db.String(500))
    changed_by = db.Column(db.String(80))
    changed_at = db.Column(db.DateTime, default=pk_model_now, index=True)

    reconciliation = db.relationship(
        'CashFlowDifferenceAdjustment',
        backref='audit_trail',
        foreign_keys=[reconciliation_id]
    )


class CashDayLock(db.Model):
    """Day-level lock marker for the Daily Cash & Bank Reconciliation page.

    When a financial day is verified & locked, the counted total for that day
    becomes the authoritative figure and each account's counted closing is
    carried forward as the next day's opening position.
    """
    __tablename__ = 'cash_day_lock'
    id = db.Column(db.Integer, primary_key=True)
    lock_date = db.Column(db.Date, nullable=False, index=True)
    total_expected = db.Column(db.Float, default=0)
    total_counted = db.Column(db.Float, default=0)
    difference = db.Column(db.Float, default=0)
    posted_total = db.Column(db.Float, default=0)   # Σ differences posted to the counters
    note = db.Column(db.String(500))
    locked_by = db.Column(db.String(80))
    locked_at = db.Column(db.DateTime, default=pk_model_now)
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)
    __table_args__ = (
        UniqueConstraint('lock_date', name='uq_cash_day_lock_date'),
    )


class CashDayShiftClose(db.Model):
    """Immutable audit snapshot for a shift checkpoint on a financial day.

    A shift close is an auditable checkpoint; the day lock remains the final
    daily close and the authority for next-day opening carry-forward.
    """
    __tablename__ = 'cash_day_shift_close'
    id = db.Column(db.Integer, primary_key=True)
    close_date = db.Column(db.Date, nullable=False, index=True)
    shift_name = db.Column(db.String(80), nullable=False)
    closed_by = db.Column(db.String(80))
    closed_at = db.Column(db.DateTime, default=pk_model_now, nullable=False, index=True)
    note = db.Column(db.String(500))
    total_expected = db.Column(db.Float, default=0)
    total_counted = db.Column(db.Float, default=0)
    difference = db.Column(db.Float, default=0)
    positions = db.relationship(
        'CashDayShiftClosePosition', backref='shift_close',
        cascade='all, delete-orphan', order_by='CashDayShiftClosePosition.id',
    )


class CashDayShiftClosePosition(db.Model):
    """Per-account figures captured by an immutable shift-close checkpoint."""
    __tablename__ = 'cash_day_shift_close_position'
    id = db.Column(db.Integer, primary_key=True)
    shift_close_id = db.Column(
        db.Integer, db.ForeignKey('cash_day_shift_close.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    account_id = db.Column(db.Integer, nullable=False, index=True)
    account_name = db.Column(db.String(100))
    opening = db.Column(db.Float, default=0)
    amount_in = db.Column(db.Float, default=0)
    amount_out = db.Column(db.Float, default=0)
    expected_closing = db.Column(db.Float, default=0)
    counted = db.Column(db.Float, nullable=False)
    difference = db.Column(db.Float, default=0)


class CashDayAccountPosition(db.Model):
    """Per-account position for a financial day on the reconciliation page.

    Stores the ledger-computed movement columns plus the user's physical
    counted figure.  When ``is_locked`` is true the ``counted`` value is the
    authoritative closing for that account and rolls forward as the next
    day's opening.
    """
    __tablename__ = 'cash_day_account_position'
    id = db.Column(db.Integer, primary_key=True)
    position_date = db.Column(db.Date, nullable=False, index=True)
    account_id = db.Column(db.Integer, nullable=False, index=True)
    account_name = db.Column(db.String(100))
    opening = db.Column(db.Float, default=0)
    amount_in = db.Column(db.Float, default=0)
    amount_out = db.Column(db.Float, default=0)
    transfer_in = db.Column(db.Float, default=0)
    transfer_out = db.Column(db.Float, default=0)
    expected_closing = db.Column(db.Float, default=0)
    counted = db.Column(db.Float)          # NULL until edited / locked
    difference = db.Column(db.Float)
    is_locked = db.Column(db.Boolean, default=False, index=True)
    locked_by = db.Column(db.String(80))
    locked_at = db.Column(db.DateTime)
    updated_by = db.Column(db.String(80))
    updated_at = db.Column(db.DateTime, default=pk_model_now, onupdate=pk_model_now)
    __table_args__ = (
        UniqueConstraint('position_date', 'account_id', name='uq_cash_day_position'),
    )



class CashDayDifference(db.Model):
    """History of discrepancies in the daily board, and their postings.

    A discrepancy is *recorded* the moment a count differs from the expected
    closing. Nothing is written to the ledger then: a count can be corrected
    freely until the day is finalised.

    Finalising the day posts the difference as a **paired transfer** against a
    counter account (``recon_counter``): a shortage moves money from the counted
    account into the *Counter Less* account, an excess moves it from the
    *Counter Excess* account into the counted account. Both legs are real
    ``AccountTransaction`` rows, so the books stay balanced and Σ balances never
    changes — only the unexplained part is parked where it can be seen.

    The posting is linked here (``posted_out_tx_id`` / ``posted_in_tx_id``), and
    a difference is only ever closed by *posting the mirror entry* (resolve) or
    by removing the day's postings (unlock). Rows are never edited or deleted.
    """
    __tablename__ = 'cash_day_difference'
    id = db.Column(db.Integer, primary_key=True)
    position_date = db.Column(db.Date, nullable=False, index=True)
    account_id = db.Column(db.Integer, nullable=False, index=True)
    account_created_at = db.Column(db.DateTime)
    account_name = db.Column(db.String(100), nullable=False)
    kind = db.Column(db.String(10), nullable=False, index=True)  # less / excess
    expected = db.Column(db.Float, nullable=False)
    counted = db.Column(db.Float, nullable=False)
    difference = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(16), nullable=False, default='open', index=True)
    source = db.Column(db.String(16), nullable=False, default='live')
    recorded_by = db.Column(db.String(80))
    recorded_at = db.Column(db.DateTime, nullable=False, default=pk_model_now, index=True)
    closed_by = db.Column(db.String(80))
    closed_at = db.Column(db.DateTime)
    closed_expected = db.Column(db.Float)
    closed_counted = db.Column(db.Float)
    # --- Counter-account posting (daily close of a finalised day) ----------
    # pending  : recorded, nothing in the ledger yet (day not finalised)
    # posted   : paired transfer written at lock, counter account carries it
    # resolved : the pair was offset by a real explanation entry
    # reversed : the day was unlocked and the pair removed
    posted_status = db.Column(db.String(16), default='pending', index=True)
    posted_out_tx_id = db.Column(db.Integer, nullable=True, index=True)
    posted_in_tx_id = db.Column(db.Integer, nullable=True, index=True)
    posted_at = db.Column(db.DateTime)
    posted_by = db.Column(db.String(80))
    posted_expected = db.Column(db.Float)
    posted_counted = db.Column(db.Float)
    resolved_at = db.Column(db.DateTime)
    resolved_by = db.Column(db.String(80))
    resolution_kind = db.Column(db.String(24))   # recovered|written_off|corrected|income
    resolution_note = db.Column(db.String(500))
    resolution_out_tx_id = db.Column(db.Integer, nullable=True, index=True)
    resolution_in_tx_id = db.Column(db.Integer, nullable=True, index=True)
